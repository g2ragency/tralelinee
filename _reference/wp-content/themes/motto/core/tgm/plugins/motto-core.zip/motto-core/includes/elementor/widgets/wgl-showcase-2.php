<?php
/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/widgets/wgl-showcase-2.php`.
 */
namespace WGL_Extensions\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{
    Plugin,
    Widget_Base,
    Controls_Manager,
    Icons_Manager,
    Repeater,
    Group_Control_Border,
    Group_Control_Box_Shadow,
    Group_Control_Typography,
    Group_Control_Background
};

use WGL_Extensions\{
    WGL_Framework_Global_Variables as WGL_Globals
};

class WGL_Showcase_2 extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-showcase-2';
    }

    public function get_title()
    {
        return esc_html__('WGL Showcase 2', 'motto-core');
    }

    public function get_icon()
    {
        return 'wgl-showcase-2';
    }

    public function get_keywords()
    {
        return [ 'showcase 2', 'title', 'images' ];
    }

    public function get_script_depends()
    {
        return [
            'wgl-widgets',
        ];
    }


    public function get_categories()
    {
        return ['wgl-modules'];
    }

    protected function register_controls()
    {
        /**
         * CONTENT -> GENERAL
         */

        $this->start_controls_section(
            'content_general',
            ['label' => esc_html__('General', 'motto-core')]
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'motto-core'),
                'type' => Controls_Manager::URL,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => [ 'url' => '#' ],
            ]
        );
        $repeater->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => esc_html__('GREAT WORK!', 'motto-core'),
            ]
        );
        $repeater->add_control(
            'subtitle',
            [
                'label' => esc_html__('Subtitle', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
            ]
        );
        $repeater->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'motto-core'),
                'type' => Controls_Manager::WYSIWYG,
                'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar.', 'motto-core'),
            ]
        );
        $repeater->add_control(
            'link_active',
            [
                'label' => esc_html__( 'Active by Default', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );
        $this->add_control(
            'items',
            [
                'label' => esc_html__('Items', 'motto-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
                'default' => [
                    [
                        'title' => esc_html__( 'UI/UX', 'motto-core' ),
                        'subtitle' => esc_html__( '001', 'motto-core' ),
                    ],
                    [
                        'title' => esc_html__( 'BRANDING', 'motto-core' ),
                        'subtitle' => esc_html__( '002', 'motto-core' ),
                    ],
                    [
                        'title' => esc_html__( 'STRATEGY', 'motto-core' ),
                        'subtitle' => esc_html__( '003', 'motto-core' ),
                        'link_active' => 'yes'
                    ],
                    [
                        'title' => esc_html__( 'INTERFACE', 'motto-core' ),
                        'subtitle' => esc_html__( '004', 'motto-core' ),
                    ],
                    [
                        'title' => esc_html__( 'MOTION', 'motto-core' ),
                        'subtitle' => esc_html__( '005', 'motto-core' ),
                    ],
                ],
            ]
        );
        $this->add_responsive_control(
            'items_justify_content',
            [
                'label' => esc_html__( 'Justify Items', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => false,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-start-h',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-center-h',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-end-h',
                    ],
                    'space-between' => [
                        'title' => esc_html__( 'Space Between', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-space-between-h',
                    ],
                    'space-around' => [
                        'title' => esc_html__( 'Space Around', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-space-around-h',
                    ],
                    'space-evenly' => [
                        'title' => esc_html__( 'Space Evenly', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-space-evenly-h',
                    ],
                ],
                'default' => 'center',
                'mobile_default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item_inner' => 'justify-content: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'content_justify',
            [
                'label' => esc_html__( 'Justify Content', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => false,
                'options' => [
                    '0' => [
                        'title' => esc_html__( 'Default', 'motto-core' ),
                        'icon' => 'eicon-h-align-left',
                    ],
                    '0 auto' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-h-align-center',
                    ],
                ],
                'condition' => ['items_justify_content' => 'flex-start'],
                'default' => '0 auto',
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__content_wrapper' => 'margin: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'items_align_items',
            [
                'label' => esc_html__( 'Align Items', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => false,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-end-v',
                    ],
                    'stretch' => [
                        'title' => esc_html__( 'Stretch', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-stretch-v',
                    ],
                ],
                'default' => 'center',
                'tablet_default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item,
                     {{WRAPPER}} .showcase-2__item_inner' => 'align-items: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'alignment',
            [
                'label' => esc_html__('Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'tablet_default' => 'center',
                'mobile_default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item,
                     {{WRAPPER}} .showcase-2__content_wrapper' => 'text-align: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'content_visibility',
            [
                'label' => esc_html__('Content Animation', 'motto-core'),
                'description' => esc_html__('Show Content on Hover', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('True', 'motto-core'),
                'label_off' => esc_html__('False', 'motto-core'),
                'default' => 'yes',
            ]
        );
        $this->add_mobile_breakpoint();
        $this->end_controls_section();

        /**
         * CONTENT -> BUTTON
         */

        $this->start_controls_section(
            'section_style_link',
            [
                'label' => esc_html__('Link', 'motto-core'),
            ]
        );

        $this->add_control(
            'add_item_link',
            [
                'label' => esc_html__('Whole Item Link', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'default' => '',
            ]
        );

        $this->add_control(
            'add_read_more',
            [
                'label' => esc_html__('Button', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'read_more_type',
            [
                'label' => esc_html__('Type', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'icon' => esc_html__('Icon', 'motto-core'),
                    'btn' => esc_html__('Button', 'motto-core'),
                ],
                'condition' => ['add_read_more' => 'yes'],
                'default' => 'icon',
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label' => esc_html__('Button Text', 'motto-core'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [  'active' => true],
                'default' => esc_html__('Read More', 'motto-core'),
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_type' => 'btn'
                ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'read_more_icon_fontawesome',
            [
                'label' => esc_html__('Icon', 'motto-core'),
                'type' => Controls_Manager::ICONS,
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_type' => 'icon'
                ],
                'label_block' => true,
                'description' => esc_html__('Select icon from available libraries.', 'motto-core'),
                'default' => [
                    'library' => 'flaticon',
                    'value' => 'flaticon flaticon-down-arrow-1'
                ],
            ]
        );

        $this->add_responsive_control(
            'read_more_icon_size',
            [
                'label' => esc_html__('Icon Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_type' => 'icon',
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'range' => [
                    'px' => ['min' => 10, 'max' => 100 ],
                ],
                'default' => ['size' => 36 ],
                'mobile_default' => ['size' => 30 ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__button' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'read_more_icon_spacing',
            [
                'label' => esc_html__('Icon Wrapper Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_type' => 'icon',
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'range' => [
                    'px' => ['min' => 10, 'max' => 100 ],
                ],
                'default' => ['size' => 46 ],
                'mobile_default' => ['size' => 40 ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__button' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * STYLE -> ITEM CONTAINER
         */

        $this->start_controls_section(
            'style_item_container',
            [
                'label' => esc_html__('Item Container', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'item_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
            ]
        );
        $this->add_responsive_control(
            'item_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '1px',
                    'right' => '2.725%',
                    'bottom' => '4px',
                    'left' => '3.125%',
                    'unit' => 'custom',
                    'isLinked' => false
                ],
                'tablet_default' => [
                    'top' => '38px',
                    'right' => '4.3%',
                    'bottom' => '38px',
                    'left' => '4.65%',
                    'unit' => 'custom',
                    'isLinked' => false
                ],
                'mobile_default' => [
                    'top' => '20px',
                    'right' => '4.65%',
                    'bottom' => '22px',
                    'left' => '4.65%',
                    'unit' => 'custom',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'item_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'item_height',
            [
                'label' => esc_html__( 'Items Min Height', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', '%', 'vh', 'vw', 'custom'],
                'default' => ['size' => 150, 'unit' => 'px'],
                'tablet_default' => ['size' => 0, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'item_separator',
            [
                'label' => esc_html__( 'Separator Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [ 'px' => ['min' => 0, 'max' => 10] ],
                'default' => ['size' => 1, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2' => '--separator-width: {{SIZE}}px; --separator-opacity: 1;',
                ],
            ]
        );
        $this->add_control(
            'item_separator_color',
            [
                'label' => esc_html__('Separator Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(0.15),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2' => '--separator-color: {{VALUE}};'
                ],
            ]
        );
        $this->add_responsive_control(
            'item_z_index',
            [
                'label' => __( 'Z-Index', 'motto-core' ),
                'type' => Controls_Manager::NUMBER,
                'dynamic' => [  'active' => true],
                'min' => -5,
                'default' => 1,
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 ' => 'z-index: {{VALUE}};',
                ],
            ]
        );
        $this->start_controls_tabs( 'item_tabs' );
        $this->start_controls_tab(
            'item_idle_tab',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_bg_idle',
                'selector' => '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_border_idle',
                'selector' => '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_shadow_idle',
                'selector' => '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item',
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'item_hover_tab',
            ['label' => esc_html__('Hover/Active' , 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_bg_hover',
                'fields_options' => [
                    'background' => [ 'default' => 'classic' ],
                    'color' => [
                        'label' => esc_html__( 'Background Color', 'motto-core' ),
                        'default' => WGL_Globals::get_primary_color(),
                    ],
                ],
                'selector' => '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active,
                     {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover,
                     
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase-2 .showcase-2__item,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase-2 .showcase-2__item,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase-2 .showcase-2__item,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase-2 .showcase-2__item',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_border_hover',
                'selector' => '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active,
                     {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover,
                     
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase-2 .showcase-2__item,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase-2 .showcase-2__item,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase-2 .showcase-2__item,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase-2 .showcase-2__item',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_shadow_hover',
                'selector' => '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active,
                     {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover,
                     
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase-2 .showcase-2__item,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase-2 .showcase-2__item,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase-2 .showcase-2__item,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase-2 .showcase-2__item'
            ]
        );
        $this->add_control(
            'item_transition',
            [
                'label' => esc_html__('Transition', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.1],
                ],
                'default' => ['size' => 0.4],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item' => 'transition: {{SIZE}}s',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> Title
         */

        $this->start_controls_section(
            'style_title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'title_width',
            [
                'label' => esc_html__( 'Title Width', 'motto-core' ),
                'description' => esc_html__( 'Title Width has Priority', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem', '%', 'vw', 'custom'],
                'range' => [ 'px' => ['max' => 1200] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__title' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_align_self',
            [
                'label' => esc_html__( 'Align Self', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-end-v',
                    ],
                    'stretch' => [
                        'title' => esc_html__( 'Stretch', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-stretch-v',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__title' => 'align-self: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'div' => esc_html('‹div›'),
                    'span' => esc_html('‹span›'),
                ],
                'separator' => 'before',
                'default' => 'h3',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_font_title',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => ['size' => 'clamp(64px, 8vw, 150px)', 'unit' => 'custom'],
                        'mobile_default' => ['size' => 'clamp(24px, 7vw, 36px)', 'unit' => 'custom'],
                    ],
                    'line_height' => ['default' => ['size' => 1, 'unit' => 'em']],
                ],
                'selector' => '{{WRAPPER}} .wgl-showcase-2 .title',
            ]
        );
        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '2',
                    'bottom' => '0',
                    'left' => '2',
                    'unit' => 'vw',
                    'isLinked' => false
                ],
                'mobile_default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_stroke_size',
            [
                'label' => esc_html__('Stroke Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => ['px' => ['min' => 0, 'max' => 2, 'step' => 0.1]],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .title' => '-webkit-text-stroke-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->start_controls_tabs( 'title_tabs' );
        $this->start_controls_tab(
            'title_color_tab',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .title' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->add_control(
            'title_bg',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__title' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_stroke_color',
            [
                'label' => esc_html__('Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'title_stroke_size[size]!' => ['', 0] ],
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .title' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_skew',
            [
                'label' => esc_html__('Skew the title', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'deg' ],
                'range' => [
                    'deg' => ['min' => -45, 'max' => 45],
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item .title' => 'transform: skew({{SIZE}}deg)',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'title_hover_tab',
            ['label' => esc_html__('Hover/Active' , 'motto-core')]
        );
        $this->add_control(
            'title_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active .title,
                     {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover .title' => 'color: {{VALUE}};',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase-2 .showcase-2__item .title,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase-2 .showcase-2__item .title,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase-2 .showcase-2__item .title,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase-2 .showcase-2__item .title' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->add_control(
            'title_bg_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active .showcase-2__title,
                     {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover .showcase-2__title' => 'background-color: {{VALUE}};',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase-2 .showcase-2__item .showcase-2__title,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase-2 .showcase-2__item .showcase-2__title,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase-2 .showcase-2__item .showcase-2__title,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase-2 .showcase-2__item .showcase-2__title' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_stroke_color_hover',
            [
                'label' => esc_html__('Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'title_stroke_size[size]!' => ['', 0] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active .title,
                     {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover .title' => '-webkit-text-stroke-color: {{VALUE}};',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase-2 .showcase-2__item .title,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase-2 .showcase-2__item .title,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase-2 .showcase-2__item .title,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase-2 .showcase-2__item .title' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_hover_skew',
            [
                'label' => esc_html__('Skew the title', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'deg' ],
                'range' => [
                    'deg' => ['min' => -45, 'max' => 45],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active .title,
                     {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover .title' => 'transform: skew({{SIZE}}deg)',
                ],
            ]
        );
        $this->add_control(
            'title_transition',
            [
                'label' => esc_html__('Transition', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.1],
                ],
                'default' => ['size' => 0.4],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__title,
                     {{WRAPPER}} .wgl-showcase-2 .title' => 'transition: {{SIZE}}s',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();


        /**
         * STYLE -> Subtitle
         */

        $this->start_controls_section(
            'style_subtitle',
            [
                'label' => esc_html__('Subtitle', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'subtitle_position',
            [
                'label' => esc_html__('Subtitle Position', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__('Default', 'motto-core'),
                    'left_w' => esc_html__('Left of the Title Wrapper', 'motto-core'),
                    'right_w' => esc_html__('Right of the Title Wrapper', 'motto-core'),
                    'left' => esc_html__('Left of the Title', 'motto-core'),
                    'right' => esc_html__('Right of the Title', 'motto-core'),
                ],
                'default' => 'default',
            ]
        );
        $this->add_responsive_control(
            'subtitle_width',
            [
                'label' => esc_html__( 'Subtitle Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem', '%', 'vw', 'custom'],
                'range' => [ 'px' => ['max' => 1200] ],
                'default' => ['size' => 47, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_align_self',
                [
                'label' => esc_html__( 'Align Self', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-end-v',
                    ],
                    'stretch' => [
                        'title' => esc_html__( 'Stretch', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-stretch-v',
                    ],
                ],
                'default' => 'flex-end',
                'tablet_default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle' => 'align-self: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_alignment',
            [
                'label' => esc_html__('Self Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__subtitle' => 'text-align: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_font_subtitle',
                'separator' => 'before',
                'selector' => '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle',
            ]
        );
        $this->add_responsive_control(
            'subtitle_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '4',
                    'right' => '6',
                    'bottom' => '3',
                    'left' => '6',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '30',
                    'right' => '30',
                    'bottom' => '30',
                    'left' => '30',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_top_offset',
            [
                'label' => esc_html__('Top Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 100],
                    'px' => ['min' => -100, 'max' => 100, 'step' => 1],
                ],
                'default' => ['size' => -19, 'unit' => 'px'],
                'tablet_default' => ['size' => -17, 'unit' => 'px'],
                'mobile_default' => ['size' => -15, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle' => 'transform: translateY( {{SIZE}}{{UNIT}} );',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_offset',
            [
                'label' => esc_html__('Left Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', 'custom'],
                'range' => [
                    'px' => ['min' => -100, 'max' => 100, 'step' => 1],
                ],
                'condition' => [ 'subtitle_position' => 'right' ],
                'default' => ['size' => 21, 'unit' => 'px'],
                'tablet_default' => ['size' => 17, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_offset_right',
            [
                'label' => esc_html__('Right Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', 'custom'],
                'range' => [
                    'px' => ['min' => -100, 'max' => 100, 'step' => 1],
                ],
                'condition' => [ 'subtitle_position' => 'left' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'subtitle_border',
                'render_type' => 'template',
                'dynamic' => [  'active' => true],
                'fields_options' => [
                    'border' => [ 'default' => 'solid' ],
                    'width' => [
                        'label' => esc_html__( 'Border Width', 'motto-core' ),
                        'default' => [
                            'top' => 1,
                            'right' => 1,
                            'bottom' => 1,
                            'left' => 1,
                        ],
                    ],
                    'color' => ['type' => Controls_Manager::HIDDEN],
                ],
                'selector' => '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle',
            ]
        );
        $this->start_controls_tabs( 'subtitle_tabs' );
        $this->start_controls_tab(
            'subtitle_tab',
            ['label' => esc_html__('Idle' , 'motto-core')]
        );
        $this->add_control(
            'subtitle_color_idle',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->add_control(
            'subtitle_bg_color_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'subtitle_border_color_idle',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'subtitle_border_border!' => ['', 'none'] ],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__subtitle' => 'border-color: {{VALUE}}'
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'subtitle_hover_tab',
            ['label' => esc_html__('Hover/Active' , 'motto-core')]
        );
        $this->add_control(
            'subtitle_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active .showcase-2__subtitle,
                    {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover .showcase-2__subtitle' => 'color: {{VALUE}};',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->add_control(
            'subtitle_bg_color_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active .showcase-2__subtitle,
                    {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover .showcase-2__subtitle' => 'background-color: {{VALUE}}',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'subtitle_border_color_hover',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'subtitle_border_border!' => ['', 'none'] ],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active .showcase-2__subtitle,
                    {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover .showcase-2__subtitle' => 'border-color: {{VALUE}}',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase-2 .showcase-2__item .showcase-2__subtitle' => 'border-color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> CONTENT
         */

        $this->start_controls_section(
            'style_content',
            [
                'label' => esc_html__('Content', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'content_width',
            [
                'label' => esc_html__( 'Content Width', 'motto-core' ),
                'description' => esc_html__( 'Title Width has Priority', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem', '%', 'vw', 'custom'],
                'range' => [ 'px' => ['max' => 1200] ],
                'default' => ['size' => '550', 'unit' => 'px'],
                'tablet_default' => ['size' => '100', 'unit' => '%'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__content_wrapper,
                     {{WRAPPER}} .wgl-showcase-2 .showcase-2__content' => '--sc2-content-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'content_align_self',
            [
                'label' => esc_html__( 'Align Self', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-end-v',
                    ],
                    'stretch' => [
                        'title' => esc_html__( 'Stretch', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-stretch-v',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__content_wrapper' => 'align-self: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'content_alignment',
            [
                'label' => esc_html__('Self Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__content_wrapper' => 'text-align: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_content',
                'separator' => 'before',
                'selector' => '{{WRAPPER}} .wgl-showcase-2 .showcase-2__content_wrapper',
            ]
        );
        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'vw', 'custom'],
                'tablet_default' => [
                    'top' => '15',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->start_controls_tabs('content_color_tab');
        $this->start_controls_tab(
            'custom_content_color_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__content_wrapper' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'custom_content_color_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'content_color_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__item.active .showcase-2__content_wrapper,
                    {{WRAPPER}} .wgl-showcase-2 .showcase-2__item:hover .showcase-2__content_wrapper' => 'color: {{VALUE}};',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase-2 .showcase-2__item .showcase-2__content_wrapper,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase-2 .showcase-2__item .showcase-2__content_wrapper,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase-2 .showcase-2__item .showcase-2__content_wrapper,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase-2 .showcase-2__item .showcase-2__content_wrapper' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'content_transition',
            [
                'label' => esc_html__('Transition', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.1],
                ],
                'default' => ['size' => 0.8],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__content_wrapper' => 'transition: {{SIZE}}s',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> BUTTON
         */
        $this->start_controls_section(
            'button_style_section',
            [
                'label' => esc_html__('Button', 'nexis-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'button_align_self',
            [
                'label' => esc_html__( 'Align Self', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-end-v',
                    ],
                    'stretch' => [
                        'title' => esc_html__( 'Stretch', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-stretch-v',
                    ],
                ],
                'default' => 'flex-end',
                'tablet_default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase-2 .showcase-2__button_wrapper' => 'align-self: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_button',
                'separator' => 'before',
                'condition' => [
                    'read_more_type' => 'btn'
                ],
                'selector' => '{{WRAPPER}} .showcase-2__button span',
            ]
        );
        $this->add_responsive_control(
            'button_padding',
            [
                'label' => esc_html__('Padding', 'nexis-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_top_offset',
            [
                'label' => esc_html__('Top Offset', 'nexis-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => ['min' => -100, 'max' => 100],
                    '%' => ['min' => -100, 'max' => 100],
                ],
                'default' => [ 'size' => -4, 'unit' => 'px' ],
                'tablet_default' => [ 'size' => 0, 'unit' => 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__button_wrapper' => 'top: {{SIZE}}{{UNIT}};'
                ],
            ]
        );

        $this->add_responsive_control(
            'button_border_radius',
            [
                'label' => esc_html__('Border Radius', 'nexis-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0, 'max' => 50, 'step' => 1 ],
                ],
                'condition' => [ 'read_more_type' => 'icon' ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__button' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'render_type' => 'template',
                'condition' => [ 'read_more_type' => 'icon' ],
                'fields_options' => [
                    'color' => [ 'type' => Controls_Manager::HIDDEN ],
                    'width' => ['label' => esc_html__( 'Border Width', 'nexis-core' )],
                ],
                'selector' => '{{WRAPPER}} .showcase-2__button',
            ]
        );

        $this->start_controls_tabs(
            'button_color_tab',
            ['separator' => 'before']
        );

        $this->start_controls_tab(
            'tab_button_idle',
            ['label' => esc_html__('Idle' , 'nexis-core') ]
        );

        $this->add_control(
            'button_color_idle',
            [
                'label' => esc_html__('Color', 'nexis-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_content_secondary_color(),
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__button' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_bg_idle',
            [
                'label' => esc_html__('Background Color', 'nexis-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_border_color_idle',
            [
                'label' => esc_html__('Border Color', 'nexis-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [
                    'button_border_border!' => ['', 'none'],
                    'read_more_type' => 'icon'
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__button' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_color_idle',
                'selector' => '{{WRAPPER}} .showcase-2__button',

            ]
        );

        $this->add_control(
            'button_icon_rotate_idle',
            [
                'label' => esc_html__('Rotate', 'nexis-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'condition' => [ 'read_more_type' => 'icon' ],
                'default' => ['size' => -45, 'unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__button i' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_button_opacity_idle',
            [
                'label' => esc_html__('Opacity', 'nexis-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['%'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 1, 'step' => 0.02],
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__button' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_button_hover_item',
            [ 'label' => esc_html__( 'Hover Item', 'motto-core' ) ]
        );
        $this->add_control(
            'button_color_hover_item',
            [
                'label' => esc_html__('Color', 'nexis-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item.active .showcase-2__button,
                     {{WRAPPER}} .showcase-2__item:hover .showcase-2__button' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_bg_hover_hover_item',
            [
                'label' => esc_html__('Background Color', 'nexis-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item.active .showcase-2__button,
                     {{WRAPPER}} .showcase-2__item:hover .showcase-2__button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_border_color_hover_item',
            [
                'label' => esc_html__('Border Color', 'nexis-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [
                    'button_border_border!' => ['', 'none'],
                    'read_more_type' => 'icon'
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item.active .showcase-2__button,
                     {{WRAPPER}} .showcase-2__item:hover .showcase-2__button' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_color_hover_item',
                'selector' => '{{WRAPPER}} .showcase-2__item.active .showcase-2__button,
                     {{WRAPPER}} .showcase-2__item:hover .showcase-2__button',

            ]
        );

        $this->add_control(
            'button_icon_rotate_hover_item',
            [
                'label' => esc_html__('Rotate', 'nexis-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'condition' => [
                    'read_more_type' => 'icon'
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item.active .showcase-2__button i,
                     {{WRAPPER}} .showcase-2__item:hover .showcase-2__button i' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_button_opacity_hover_item',
            [
                'label' => esc_html__('Opacity', 'nexis-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['%'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 1, 'step' => 0.02],
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item.active .showcase-2__button,
                     {{WRAPPER}} .showcase-2__item:hover .showcase-2__button' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_button_hover_button',
            [ 'label' => esc_html__( 'Hover Button', 'motto-core' ) ]
        );
        $this->add_control(
            'button_color_hover_button',
            [
                'label' => esc_html__('Color', 'nexis-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item .showcase-2__button_wrapper .showcase-2__button:hover' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_bg_hover_hover_button',
            [
                'label' => esc_html__('Background Color', 'nexis-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item .showcase-2__button_wrapper .showcase-2__button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_border_color_hover_button',
            [
                'label' => esc_html__('Border Color', 'nexis-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [
                    'button_border_border!' => ['', 'none'],
                    'read_more_type' => 'icon'
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item .showcase-2__button_wrapper .showcase-2__button:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_color_hover_button',
                'selector' => '{{WRAPPER}} .showcase-2__item .showcase-2__button_wrapper .showcase-2__button:hover',

            ]
        );

        $this->add_control(
            'button_icon_rotate_hover_button',
            [
                'label' => esc_html__('Rotate', 'nexis-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'condition' => [
                    'read_more_type' => 'icon'
                ],
                'default' => ['size' => -90, 'unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item .showcase-2__button_wrapper .showcase-2__button:hover i' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_button_opacity_hover_button',
            [
                'label' => esc_html__('Opacity', 'nexis-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['%'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 1, 'step' => 0.02],
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase-2__item .showcase-2__button_wrapper .showcase-2__button:hover' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function add_mobile_breakpoint() {
        // The 'Hide On X' controls are displayed from largest to smallest, while the method returns smallest to largest.
        $active_devices = Plugin::$instance->breakpoints->get_active_devices_list( [ 'reverse' => true ] );
        $active_breakpoints = Plugin::$instance->breakpoints->get_active_breakpoints();

        $avaliable_breakpoints = [];
        foreach ( $active_devices as $breakpoint_key ) {
            $label = 'desktop' === $breakpoint_key ? esc_html__( 'Desktop', 'motto-core' ) : $active_breakpoints[ $breakpoint_key ]->get_label();
            $avaliable_breakpoints[$breakpoint_key] = $label;
        }

        $this->add_control(
            'wgl_mobile_breakpoint',
            [
                /* translators: %s: Device Name. */
                'label' => esc_html__( 'Set Mobile Template On:', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => $avaliable_breakpoints,
                'default' => 'tablet',
                'prefix_class' => 'breakpoint_on-'
            ]
        );
    }

    protected function render()
    {
        $_s = $this->get_settings_for_display();
        // Build structure

        $showcase_2__wrapper = '';
        foreach ($_s['items'] as $index => $item) {
            // Fields validation
            $title = $item['title'] ?? '';
            $subtitle = $item['subtitle'] ?? '';
            $link = $item['link'] ?? '';
            $content = $item['content'] ?? '';

            $has_link = !empty($link['url']);

            if ($has_link) {
                $link = $this->get_repeater_setting_key('link', 'items', $index);
                $this->add_link_attributes($link, $item['link']);
            }

            $showcase_2__item = $this->get_repeater_setting_key( 'item_link_active', 'items', $index );
            $this->add_render_attribute( $showcase_2__item, [
                'class' => [
                    'showcase-2__item',
                    $item[ 'link_active' ] ? 'active' : ''
                ],
            ] );

            $subtitle = !empty($subtitle) ? '<span class="showcase-2__subtitle">'. esc_html($subtitle) .'</span>' : '';
            $title = ('left_w' === $_s['subtitle_position'] ? $subtitle : '' )
                . '<' . esc_attr($_s['title_tag']) . ' class="showcase-2__title">'
                . ('left' === $_s['subtitle_position'] ? $subtitle : '' )
                . (!empty($title) ? '<span class="title">'. esc_html($title) .'</span>' : '')
                . ('right' === $_s['subtitle_position'] ? $subtitle : '' )
                . '</' . esc_attr($_s['title_tag']) . '>'
                . ('right_w' === $_s['subtitle_position'] ? $subtitle : '' );

            if (!empty($content)) {
                $content = '<div class="showcase-2__content_wrapper"><div class="showcase-2__content">' . $content . '</div></div>';
            }

            $showcase_2__wrapper .= '<div '. $this->get_render_attribute_string( $showcase_2__item ). '>';
                if ($_s['add_item_link'] && $has_link) {
                    $showcase_2__wrapper .= '<a class="showcase-2__link" ' . $this->get_render_attribute_string($link) . '></a>';
                }
                $showcase_2__wrapper .= 'default' === $_s['subtitle_position'] ? $subtitle : '';

                if (!!$title || !!$content) {
                    $showcase_2__wrapper .= '<div class="showcase-2__item_inner">';
                        $showcase_2__wrapper .= $title;
                        $showcase_2__wrapper .= $content;
                    $showcase_2__wrapper .= '</div>';
                }

                $showcase_2__wrapper .= $this->read_more_button($index, $has_link, $link, $_s);
            $showcase_2__wrapper .= '</div>';
        }

        $this->add_render_attribute( 'general', [
            'class' => [
                'wgl-showcase-2',
                $_s['content_visibility'] ? 'content_visibility-yes' : '',
            ],
        ] );

        if (!empty($_s['wgl_mobile_breakpoint'])){
            $active_breakpoints = Plugin::$instance->breakpoints->get_active_breakpoints();
            $this->add_render_attribute( 'general', [
                'data-breakpoint' => $active_breakpoints[ $_s['wgl_mobile_breakpoint'] ]->get_value()
            ] );
        }

        ?><div <?php echo $this->get_render_attribute_string('general') ?>><?php
            echo $showcase_2__wrapper;
        ?></div><?php
    }

    public function read_more_button($index, $has_link, $link_item, $_s)
    {
        $s_button = '';

        // Read more button
        if ($_s['add_read_more']) {
            $this->add_render_attribute('btn' . $index, 'class', ['showcase-2__button', 'icon' === $_s['read_more_type'] ? 'icon-read-more' : 'button-read-more']);

            $icon_font = $_s['read_more_icon_fontawesome'];

            $migrated = isset($this->get_settings_for_display('__fa4_migrated')['read_more_icon_fontawesome']);
            $is_new = Icons_Manager::is_migration_allowed();
            $icon_output = '';

            if ($is_new || $migrated) {
                ob_start();
                Icons_Manager::render_icon($icon_font, ['aria-hidden' => 'true']);
                $icon_output .= ob_get_clean();
            } else {
                $icon_output .= '<i class="icon ' . esc_attr($icon_font) . '"></i>';
            }

            if (!empty($icon_output) || $_s['read_more_text']) {
                $s_button = '<div class="showcase-2__button_wrapper">';
                    $s_button .= sprintf('<%s %s %s>',
                        !$has_link ? 'div' : 'a',
                        $has_link ? $this->get_render_attribute_string($link_item) : '',
                        $this->get_render_attribute_string('btn' . $index)
                    );

                    if ('icon' === $_s['read_more_type']) {
                        $s_button .= $icon_output;
                    } else {
                        $s_button .= $_s['read_more_text'] ? '<span>' . esc_html($_s['read_more_text']) . '</span>' : '';
                    }

                    $s_button .= !$has_link ? '</div>' : '</a>';
                $s_button .= '</div>';
            }
        }

        return $s_button;
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WGL_Extensions\Includes\WGL_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
