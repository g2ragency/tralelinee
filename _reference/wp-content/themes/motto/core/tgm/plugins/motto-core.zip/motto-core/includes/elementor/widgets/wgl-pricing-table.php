<?php
/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/widgets/wgl-pricing-table.php`.
 */
namespace WGL_Extensions\Widgets;

defined( 'ABSPATH' ) || exit; // Abort, if called directly.

use Elementor\{Control_Media,
    Utils,
    Widget_Base,
    Controls_Manager,
    Group_Control_Border,
    Group_Control_Typography,
    Group_Control_Background,
    Group_Control_Box_Shadow};
use WGL_Extensions\{
    WGL_Framework_Global_Variables as WGL_Globals,
    Includes\WGL_Icons,
    Templates\WGL_Button
};

class WGL_Pricing_Table extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-pricing-table';
    }

    public function get_title()
    {
        return esc_html__( 'WGL Pricing Table', 'motto-core' );
    }

    public function get_icon()
    {
        return 'wgl-pricing-table';
    }

    public function get_keywords()
    {
        return [ 'price', 'table' ];
    }

    public function get_categories()
    {
        return [ 'wgl-modules' ];
    }

    protected function register_controls()
    {
        /** CONTENT -> GENERAL */

        $this->start_controls_section(
            'content_general',
            [ 'label' => esc_html__( 'General', 'motto-core' ) ]
        );

        $this->add_responsive_control(
            'alignment',
            [
                'label' => esc_html__( 'Alignment', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'motto-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'motto-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'prefix_class' => 'a%s',
            ]
        );

        $this->add_control(
            'hover_animation',
            [
                'label' => esc_html__( 'Hover Animation', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__( 'Slide up the module.', 'motto-core' ),
            ]
        );

        $this->end_controls_section();

        /** CONTENT -> CONTENT */

        $this->start_controls_section(
            'content_content',
            [ 'label' => esc_html__( 'Content', 'motto-core' ) ]
        );

        WGL_Icons::init(
            $this,
            [
                'section' => false,
                'prefix' => 'thumb_',
                'media_types_options' => [
                    '' => [
                        'title' => esc_html__('None', 'motto-core'),
                        'icon' => 'eicon-ban',
                    ],
                    'image' => [
                        'title' => esc_html__('Thumbnail', 'motto-core'),
                        'icon' => 'far fa-image',
                    ],
                ],
                'default' => [
                    'media_type' => '',
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
		    'pretitle_text',
		    [
			    'label' => esc_html__('Pretitle', 'motto-core'),
			    'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
			    'label_block' => true,
                'placeholder' => esc_attr_x( 'ex: PER WEEK', 'WGL Pricing Table', 'motto-core' ),
                'default' => esc_html_x( 'PER WEEK', 'WGL Pricing Table', 'motto-core' ),
		    ]
	    );

        $this->add_control(
            'title_text',
            [
                'label' => esc_html__( 'Title', 'motto-core' ),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr_x( 'ex: Pricing Title', 'WGL Pricing Table', 'motto-core' ),
            ]
        );

        $this->add_control(
            'title_suffix_enabled',
            [
                'label' => esc_html__( 'Shatter Title Into Parts?', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'title_suffix_text',
            [
                'label' => esc_html__( 'Title Suffix', 'motto-core' ),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'title_suffix_enabled' => 'yes' ],
            ]
        );

        $this->add_control(
            'currency_text',
            [
                'label' => esc_html__( 'Currency Symbol', 'motto-core' ),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr_x( 'ex: USD, $, €', 'WGL Pricing Table', 'motto-core' ),
                'default' => esc_html_x( '$', 'WGL Pricing Table', 'motto-core' ),
            ]
        );

        $this->add_control(
            'price_text',
            [
                'label' => esc_html__( 'Price', 'motto-core' ),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr_x( 'ex: 179.99', 'WGL Pricing Table', 'motto-core' ),
                'default' => esc_html_x( '499', 'WGL Pricing Table', 'motto-core' ),
            ]
        );

        $this->add_control(
            'currency_right_text',
            [
                'label' => esc_html__( 'Currency Symbol at the End', 'motto-core' ),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr_x( 'ex: USD, $, €, /', 'WGL Pricing Table', 'motto-core' ),
            ]
        );

        $this->add_control(
            'period_text',
            [
                'label' => esc_html__( 'Period', 'motto-core' ),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr_x( 'ex: per month, /item', 'WGL Pricing Table', 'motto-core' ),
                'default' => _x( 'Standard <br />Plan', 'WGL Pricing Table', 'motto-core' ),
            ]
        );

        $this->add_control(
            'description_text',
            [
                'label' => esc_html__( 'Description', 'motto-core' ),
                'type' => Controls_Manager::TEXTAREA,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'rows' => 1,
            ]
        );

        $this->add_control(
            'bg_text',
            [
                'label' => esc_html__( 'Background Text', 'motto-core' ),
                'type' => Controls_Manager::TEXTAREA,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'rows' => 1,
                'placeholder' => esc_attr__('ex: 01', 'motto-core'),
            ]
        );

        $this->add_control(
            'content_wysiwyg',
            [
                'label' => esc_html__( 'Content', 'motto-core' ),
                'type' => Controls_Manager::WYSIWYG,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => esc_html__( 'Your content...', 'motto-core' ),
            ]
        );

        $this->end_controls_section();

        /** CONTENT -> BUTTON */

        $this->start_controls_section(
            'content_button',
            [ 'label' => esc_html__( 'Button', 'motto-core' ) ]
        );

        $this->add_control(
            'button_enabled',
            [
                'label' => esc_html__( 'Use button?', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'text',
            [
                'label' => esc_html__( 'Button Text', 'motto-core' ),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'button_enabled' => 'yes' ],
                'label_block' => true,
                'placeholder' => esc_attr_x( 'ex: Choose a Plan', 'WGL Pricing Table', 'motto-core' ),
                'default' => esc_html_x( 'CHOOSE PRICING PLAN', 'WGL Pricing Table', 'motto-core' ),
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => esc_html__( 'Button Link', 'motto-core' ),
                'type' => Controls_Manager::URL,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'button_enabled' => 'yes' ],
	            'default' => [ 'url' => '#' ],
                'label_block' => true,
            ]
        );

        $this->add_responsive_control(
            'button_alignment',
            [
                'label' => esc_html__( 'Alignment', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'condition' => [ 'button_enabled' => 'yes' ],
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'motto-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'motto-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__( 'Full Width', 'motto-core' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                    'space-between' => [
                        'title' => esc_html__( 'Space Between', 'motto-core' ),
                        'icon' => 'eicon-justify-space-between-h',
                    ],
                ],
                'default' => 'left',
                'prefix_class' => 'button-align%s-',
            ]
        );

        $this->add_responsive_control(
            'text_alignment',
            [
                'label' => esc_html__( 'Text Alignment', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start; text-align: left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center; text-align: center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end; text-align: right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .button__text' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_media_heading',
            [
                'label' => esc_html__( 'Button Media', 'motto-core' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [ 'button_enabled' => 'yes' ],
                'separator' => 'before',
            ]
        );

        $extra_controls[ 'img_size_string' ] = [
            'label' => esc_html__( 'Image Size', 'motto-core' ),
            'type' => Controls_Manager::SELECT,
            'condition' => [
                'icon_type' => 'image',
                'button_enabled' => 'yes',
            ],
            'options' => [
                '30' => esc_html__( '30x30', 'motto-core' ),
                '35' => esc_html__( '50x50', 'motto-core' ),
                '100' => esc_html__( '100x100', 'motto-core' ),
                'full' => esc_html__( 'Full', 'motto-core' ),
                'custom' => esc_html__( 'Custom', 'motto-core' ),
            ],
            'default' => 'full',
        ];

        $extra_controls[ 'img_size_array' ] = [
            'label' => esc_html__( 'Image Dimension', 'motto-core' ),
            'type' => Controls_Manager::IMAGE_DIMENSIONS,
            'condition' => [
                'img_size_string' => 'custom',
                'icon_type' => 'image',
                'button_enabled' => 'yes',
            ],
            'description' => esc_html__( 'Crop the original image to any custom size. You can also set a single value for width to keep the initial ratio.', 'motto-core' ),
            'default' => [
                'width' => '65',
                'height' => '65',
            ],
        ];

        $extra_controls[ 'img_aspect_ratio' ] = [
            'label' => esc_html__( 'Image Aspect Ratio', 'motto-core' ),
            'type' => Controls_Manager::SELECT,
            'condition' => [
                'img_size_string!' => 'custom',
                'icon_type' => 'image',
                'button_enabled' => 'yes',
            ],
            'options' => [
                '' => esc_html__( 'No Crop', 'motto-core' ),
                '1:1' => esc_html( '1:1' ),
                '3:2' => esc_html( '3:2' ),
                '4:3' => esc_html( '4:3' ),
                '6:5' => esc_html( '6:5' ),
                '9:16' => esc_html( '9:16' ),
                '16:9' => esc_html( '16:9' ),
                '21:9' => esc_html( '21:9' ),
            ],
            'default' => '',
        ];

        $extra_controls[ 'icon_align' ] = [
            'label' => esc_html__( 'Position', 'motto-core' ),
            'type' => Controls_Manager::SELECT,
            'condition' => [
                'icon_type!' => '',
                'button_enabled' => 'yes'
            ],
            'options' => [
                'left' => esc_html__( 'Before', 'motto-core' ),
                'right' => esc_html__( 'After', 'motto-core' ),
            ],
            'default' => 'right',
        ];

        $extra_controls[ 'icon_indent' ] = [
            'label' => esc_html__( 'Offset', 'motto-core' ),
            'type' => Controls_Manager::SLIDER,
            'dynamic' => [  'active' => true],
            'condition' => [
                'icon_type!' => '',
                'button_enabled' => 'yes',
            ],
            'size_units' => ['px'],
            'range' => [
                'px' => [ 'max' => 100 ],
            ],
            'selectors' => [
                '{{WRAPPER}} .wgl-button .button__content' => '--wgl-gap: {{SIZE}}{{UNIT}};',
            ],
        ];

        WGL_Icons::init(
            $this,
            [
                'output' => $extra_controls,
                'section' => false,
                'condition' => [ 'button_enabled' => 'yes' ],
                'use_group_control_image_size' => ! ( $extra_controls[ 'img_size_string' ] ?? null ),
                'default' => [
                    'media_type' => 'font',
                    'icon' => [
                        'library' => 'flaticon',
                        'value' => 'flaticon flaticon-down-right-arrow'
                    ],
                ],
            ]
        );

        $this->end_controls_section();

        /** CONTENT -> CREEPING LINE */

        $this->start_controls_section(
            'section_content_creeping_line',
            [ 'label' => esc_html__('Creeping Line', 'motto-core') ]
        );

        $this->add_control(
            'creeping_line_switch',
            [
                'label' => esc_html__('Use Creeping Line?', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'creeping_line_text',
            [
                'label' => esc_html__('Creeping Line Text', 'motto-core'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [  'active' => true],
                'condition' => [ 'creeping_line_switch' => 'yes' ],
                'label_block' => true,
                'default' => esc_html_x( 'Optimal Pricing Plan', 'WGL Pricing Table', 'motto-core' ),
            ]
        );

        $this->end_controls_section();

        /** STYLE -> CONTAINER */

        $this->start_controls_section(
            'style_container',
            [
                'label' => esc_html__( 'Container', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'container_max_width',
            [
                'label' => esc_html__( 'Max Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', 'vw', 'custom'],
                'range' => [
                    'px' => [ 'min' => 250, 'max' => 850 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-pricing_plan' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'container_overflow',
            [
                'label' => esc_html__('The overflow of Price Section is clipped?', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper' => 'overflow: hidden;',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_padding',
            [
                'label' => esc_html__( 'Padding', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '50',
                    'right' => '40',
                    'bottom' => '50',
                    'left' => '40',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'tablet_default' => [
                    'top' => '40',
                    'right' => '35',
                    'bottom' => '40',
                    'left' => '35',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'mobile_default' => [
                    'top' => '30',
                    'right' => '25',
                    'bottom' => '30',
                    'left' => '25',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'container_border',
                'fields_options' => [
                    'width' => [
                        'label' => esc_html__( 'Border Width', 'motto-core' ),
                    ],
                    'color' => [ 'type' => Controls_Manager::HIDDEN ],
                ],
                'selector' => '{{WRAPPER}} .pricing__wrapper',
            ]
        );

        $this->add_control(
            'container_radius',
            [
                'label' => esc_html__( 'Border Radius', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'container_shadow',
                'selector' => '{{WRAPPER}} .pricing__wrapper',
            ]
        );

        $this->start_controls_tabs('containers');
        $this->start_controls_tab(
            'container_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'container_bg_idle',
                'fields_options' => [
                    'background' => [ 'default' => 'classic' ],
                    'color' => [
                        'label' => esc_html__( 'Background Color', 'motto-core' ),
                        'default' => WGL_Globals::get_secondary_color(),
                    ],
                ],
                'selector' => '{{WRAPPER}} .pricing__wrapper',
            ]
        );
        $this->add_control(
            'container_border_idle',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'container_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'container_hover',
            ['label' => esc_html__('Item Hover', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'container_bg_hover',
                'selector' => '{{WRAPPER}} .pricing__wrapper:hover',
            ]
        );
        $this->add_control(
            'container_border_hover',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'container_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

	    /** STYLE -> PRICING THUMBNAIL */
	    $this->start_controls_section(
		    'style_pricing_thumbnail',
		    [
			    'label' => esc_html__( 'Thumbnail', 'motto-core' ),
			    'tab' => Controls_Manager::TAB_STYLE,
			    'condition' => [
			        'thumb_icon_type' => 'image',
			        'thumb_thumbnail[url]!' => ''
                ],
		    ]
	    );

        $this->add_responsive_control(
            'pricing_thumbnail_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'condition' => ['mask_image_animation' => ''],
                'selectors' => [
                    '{{WRAPPER}} .pricing__thumbnail' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'pricing_thumbnail_padding',
            [
                'label' => esc_html__( 'Padding', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__thumbnail' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'pricing_thumbnail_radius',
            [
                'label' => esc_html__( 'Border Radius', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'pricing_thumbnail_max_width',
            [
                'label' => esc_html__( 'Max Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 10, 'max' => 500 ],
                    '%' => ['min' => 10, 'max' => 100 ],
                ],
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .pricing__thumbnail img' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'mask_image_animation',
            [
                'label' => esc_html__( 'Mask Image Animation', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->start_controls_tabs('images');
        $this->start_controls_tab(
            'image_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'image_mask_color_idle',
            [
                'label' => esc_html__('Change Color for Image', 'wgl-extensions'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'render_type' => 'template',
                'condition' => ['mask_image_animation!' => ''],
                'selectors' => [
                    '{{WRAPPER}} .mask_image' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'image_opacity_idle',
            [
                'label' => esc_html__('Opacity', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.01 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-image-box_img' => 'opacity: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'image_hover',
            ['label' => esc_html__('Item Hover', 'motto-core')]
        );
        $this->add_control(
            'image_mask_color_hover',
            [
                'label' => esc_html__('Change Color for Image', 'wgl-extensions'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'render_type' => 'template',
                'condition' => ['mask_image_animation!' => ''],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .mask_image' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'image_opacity_hover',
            [
                'label' => esc_html__('Opacity', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.01 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .wgl-image-box_img' => 'opacity: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
	    /** STYLE -> PRETITLE */
	    $this->start_controls_section(
		    'style_pretitle',
		    [
			    'label' => esc_html__( 'Pretitle', 'motto-core' ),
			    'tab' => Controls_Manager::TAB_STYLE,
			    'condition' => [ 'pretitle_text!' => '' ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name' => 'pretitle_typography',
			    'selector' => '{{WRAPPER}} .pretitle',
		    ]
	    );
	    $this->add_responsive_control(
		    'pretitle_margin',
		    [
			    'label' => esc_html__( 'Margin', 'motto-core' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '10',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
			    'selectors' => [
				    '{{WRAPPER}} .pricing__pretitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control(
		    'pretitle_padding',
		    [
			    'label' => esc_html__( 'Padding', 'motto-core' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '4',
                    'right' => '10',
                    'bottom' => '3',
                    'left' => '10',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
			    'selectors' => [
				    '{{WRAPPER}} .pretitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name' => 'pretitle_border',
			    'fields_options' => [
                    'border' => [ 'default' => 'solid' ],
                    'width' => [
                        'label' => esc_html__( 'Border Width', 'motto-core' ),
                        'default' => [
                            'top' => 1,
                            'right' => 1,
                            'bottom' => 1,
                            'left' => 1,
                        ],
                    ],
				    'color' => [ 'type' => Controls_Manager::HIDDEN],
			    ],
			    'selector' => '{{WRAPPER}} .pretitle',
		    ]
	    );
	    $this->add_control(
		    'pretitle_radius',
		    [
			    'label' => esc_html__( 'Border Radius', 'motto-core' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
			    'selectors' => [
				    '{{WRAPPER}} .pretitle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->start_controls_tabs( 'pretitle' );
	    $this->start_controls_tab(
		    'pretitle_idle',
		    [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
	    );
	    $this->add_control(
		    'pretitle_color_idle',
		    [
			    'label' => esc_html__( 'Text Color', 'motto-core' ),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(),
			    'selectors' => [
				    '{{WRAPPER}} .pretitle' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'pretitle_border_color_idle',
		    [
			    'label' => esc_html__( 'Border Color', 'motto-core' ),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => [ 'pretitle_border_border!' => ['', 'none'] ],
                'default' => WGL_Globals::get_tertiary_color(),
			    'selectors' => [
				    '{{WRAPPER}} .pretitle' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'pretitle_bg_idle',
		    [
			    'label' => esc_html__( 'Background Color', 'motto-core' ),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'selectors' => [
				    '{{WRAPPER}} .pretitle::before' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->end_controls_tab();
	    $this->start_controls_tab(
		    'pretitle_hover',
		    [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
	    );
	    $this->add_control(
		    'pretitle_color_hover',
		    [
			    'label' => esc_html__( 'Text Color', 'motto-core' ),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'selectors' => [
				    '{{WRAPPER}} .pricing__wrapper:hover .pretitle' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'pretitle_border_color_hover',
		    [
			    'label' => esc_html__( 'Border Color', 'motto-core' ),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => [ 'pretitle_border_border!' => ['', 'none'] ],
			    'selectors' => [
				    '{{WRAPPER}} .pricing__wrapper:hover .pretitle' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'pretitle_bg_hover',
		    [
			    'label' => esc_html__( 'Background Color', 'motto-core' ),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'selectors' => [
				    '{{WRAPPER}} .pricing__wrapper:hover .pretitle' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->end_controls_tab();
	    $this->end_controls_tabs();
	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name' => 'pretitle_shadow',
			    'separator' => 'before',
			    'selector' => '{{WRAPPER}} .pretitle',
		    ]
	    );
	    $this->end_controls_section();

        /** STYLE -> TITLE */

        $this->start_controls_section(
            'style_title',
            [
                'label' => esc_html__( 'Title', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
	            'condition' => [ 'title_text!' => '' ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .pricing__title',
            ]
        );
        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '5',
                    'right' => '0',
                    'bottom' => '6',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'tablet_default' => [
                    'top' => '4',
                    'right' => '0',
                    'bottom' => '4',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'mobile_default' => [
                    'top' => '3',
                    'right' => '0',
                    'bottom' => '3',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__( 'Padding', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'title_border',
                'fields_options' => [
                    'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                    'color' => [ 'type' => Controls_Manager::HIDDEN],
                ],
                'selector' => '{{WRAPPER}} .pricing__title',
            ]
        );

        $this->add_control(
            'title_radius',
            [
                'label' => esc_html__( 'Border Radius', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'title' );

        $this->start_controls_tab(
            'title_idle',
            [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
        );

        $this->add_control(
            'title_color_idle',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .pricing__title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_border_color_idle',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'title_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__title' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_bg_idle',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'title_hover',
            [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .pricing__title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_border_color_hover',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'title_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .pricing__title' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_bg_hover',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .pricing__title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'title_shadow',
                'separator' => 'before',
                'selector' => '{{WRAPPER}} .pricing__title',
            ]
        );

        $this->end_controls_section();

        /** STYLE -> TITLE SUFFIX */

        $this->start_controls_section(
            'style_title_suffix',
            [
                'label' => esc_html__( 'Title Suffix', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                	'title_suffix_enabled' => 'yes',
                	'title_suffix_text!' => ''
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_suffix_typography',
                'selector' => '{{WRAPPER}} .title__suffix',
            ]
        );

        $this->add_responsive_control(
            'title_suffix_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'allowed_dimensions' => 'horizontal',
                'selectors' => [
                    '{{WRAPPER}} .title__suffix' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_suffix_padding',
            [
                'label' => esc_html__( 'Padding', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .title__suffix' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'title_suffix',
            [ 'separator' => 'before' ]
        );

        $this->start_controls_tab(
            'title_suffix_idle',
            [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
        );

        $this->add_control(
            'title_suffix_color_idle',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .title__suffix' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_suffix_bg_idle',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .title__suffix' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'title_suffix_hover',
            [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
        );

        $this->add_control(
            'title_suffix_color_hover',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
	            'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .title__suffix' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_suffix_bg_hover',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .title__suffix' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /** STYLE -> PRICE */

        $this->start_controls_section(
            'style_price',
            [
                'label' => esc_html__( 'Price', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
	            'condition' => [ 'price_text!' => '' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'price_typography',
                'selector' => '{{WRAPPER}} .pricing__price',
            ]
        );

        $this->add_responsive_control(
            'price_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__header' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'price_padding',
            [
                'label' => esc_html__( 'Padding', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'price_radius',
            [
                'label' => esc_html__( 'Border Radius', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__header' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'price_color',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .pricing__price' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'price_bg',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__header' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /** STYLE -> PAYMENT CURRENCY */

        $this->start_controls_section(
            'style_currency',
            [
                'label' => esc_html__( 'Currency Symbol', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
	            'condition' => [ 'currency_text!' => '' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'currency_typography',
                'selector' => '{{WRAPPER}} .price__currency',
            ]
        );

        $this->add_responsive_control(
            'currency_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'allowed_dimensions' => 'horizontal',
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '-18',
                    'right' => '5',
                    'bottom' => '18',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .price__currency' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'currency_color',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .price__currency' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /** STYLE -> PAYMENT CURRENCY */

        $this->start_controls_section(
            'style_currency_right',
            [
                'label' => esc_html__( 'Currency Symbol at the End', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
	            'condition' => [ 'currency_right_text!' => '' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'currency_right_typography',

                'selector' => '{{WRAPPER}} .price__currency_right',
            ]
        );

        $this->add_responsive_control(
            'currency_right_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'allowed_dimensions' => 'horizontal',
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '0',
                    'right' => '4',
                    'bottom' => '0',
                    'left' => '4',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .price__currency_right' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'currency_right_color',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .price__currency_right' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /** STYLE -> PAYMENT PERIOD */

        $this->start_controls_section(
            'style_period',
            [
                'label' => esc_html__( 'Payment Period', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
	            'condition' => [ 'period_text!' => '' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'period_typography',
                'selector' => '{{WRAPPER}} .price__period',
            ]
        );

        $this->add_control(
            'period_display_block',
            [
                'label' => esc_html__( 'Full Width Element', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
                'selectors' => [
                    '{{WRAPPER}} .price__period' => 'display: block; position: static;',
                ],
            ]
        );

        $this->add_responsive_control(
            'period_max_width',
            [
                'label' => esc_html__( 'Max Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 850 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .price__period' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'period_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom'=> '14',
                    'left' => '20',
	                'unit'  => 'px',
	                'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .price__period' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'period_padding',
            [
                'label' => esc_html__( 'Padding', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .price__period' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'period_radius',
            [
                'label' => esc_html__( 'Border Radius', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .price__period' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_period' );
        $this->start_controls_tab( 'period_idle',
            [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
        );
        $this->add_control(
            'period_color_idle',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .price__period' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'period_bg_idle',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .price__period' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'period_hover',
            [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'period_color_hover',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .price__period' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .price__period' => 'transition: .4s;',
                ],
            ]
        );
        $this->add_control(
            'period_bg_hover',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .price__period' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .price__period' => 'transition: .4s;',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /** STYLE -> CONTENT */

        $this->start_controls_section(
            'style_content',
            [
                'label' => esc_html__( 'Content', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
	            'condition' => [ 'content_wysiwyg!' => '' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'fields_options' => [
                    'typography' => [
                        'default' => 'yes',
                    ],
                    'font_weight' => [
                        'default' => 500,
                    ],
                ],
                'selector' => '{{WRAPPER}} .pricing__content',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .pricing__content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '21',
                    'right' => '0',
                    'bottom'=> '10',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'tablet_default' => [
                    'top' => '16',
                    'right' => '0',
                    'bottom' => '5',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'mobile_default' => [
                    'top' => '12',
                    'right' => '0',
                    'bottom' => '2',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__( 'Padding', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '47',
                    'right' => '0',
                    'bottom'=> '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'tablet_default' => [
                    'top' => '38',
                    'right' => '0',
                    'bottom'=> '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'mobile_default' => [
                    'top' => '30',
                    'right' => '0',
                    'bottom'=> '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'content_border',
                'fields_options' => [
                    'border' => [
                        'default' => 'solid',
                    ],
                    'width' => [
                        'label' => esc_html__( 'Border Width', 'motto-core' ),
                        'default' => [
                            'top' => 1,
                            'right' => 0,
                            'bottom' => 0,
                            'left' => 0,
                        ],
                    ],
                    'color' => [
                        'label' => esc_html__( 'Border Color', 'motto-core' ),
                        'default' => WGL_Globals::get_tertiary_color(0.2),
                    ],
                ],
                'selector' => '{{WRAPPER}} .pricing__content',
            ]
        );

        $this->end_controls_section();

        /** STYLE -> CREEPING LINE */

        $this->start_controls_section(
            'style_creeping_line',
            [
                'label' => esc_html__( 'Creeping Line', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
	            'condition' => [ 'creeping_line_switch!' => '' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'creeping_line_typography',
                'fields_options' => [
                    'typography' => [
                        'default' => 'yes',
                    ],
                    'font_weight' => [
                        'default' => 500,
                    ],
                ],
                'selector' => '{{WRAPPER}} .pricing__content',
            ]
        );

        $this->add_responsive_control(
            'creeping_line_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__creeping_line' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'creeping_line_padding',
            [
                'label' => esc_html__( 'Padding', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'allowed_dimensions' => 'horizontal',
                'default' => [
                    'top' => '',
                    'right' => '7',
                    'bottom'=> '',
                    'left' => '6',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__creeping_line' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'creeping_line_color',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .pricing__creeping_line' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'creeping_line_bg',
                'fields_options' => [
                    'background' => [ 'default' => 'classic' ],
                    'color' => [
                        'label' => esc_html__( 'Background Color', 'motto-core' ),
                        'default' => WGL_Globals::get_primary_color(),
                    ],
                ],
                'selector' => '{{WRAPPER}} .pricing__creeping_line',
            ]
        );

        $this->end_controls_section();

        /** STYLE -> BUTTON */

        $this->start_controls_section(
            'style_button',
            [
                'label' => esc_html__( 'Button', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'button_enabled' => 'yes' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .wgl-button',
            ]
        );

        $this->add_responsive_control(
            'button_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '30',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'tablet_default' => [
                    'top' => '26',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'mobile_default' => [
                    'top' => '23',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => esc_html__( 'Padding', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button' => '--button-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name' => 'button_border',
                'condition' => [ 'animation_style!' => 'clip_animation' ],
			    'fields_options' => [
				    'color' => [ 'type' => Controls_Manager::HIDDEN ],
                    'border' => [ 'default' => 'solid' ],
                    'width' => [
                        'label' => esc_html__( 'Border Width', 'motto-core' ),
                        'default' => [
                            'top' => 1,
                            'right' => 1,
                            'bottom' => 1,
                            'left' => 1,
                        ],
                    ],
			    ],
                'selector' => '{{WRAPPER}} .wgl-button',
		    ]
	    );

        $this->add_control(
            'button_radius',
            [
                'label' => esc_html__( 'Border Radius', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button' => '--button-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'button' );
        $this->start_controls_tab(
            'button_idle',
            [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
        );
        $this->add_control(
            'button_color_idle',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-button' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_idle',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(0),
                'selectors' => [
                    '{{WRAPPER}}:not(.has-bg_animation) .wgl-button' => 'background-color: {{VALUE}};',

                    '{{WRAPPER}}.has-bg_animation .wgl-button::after' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.has-bg_animation .wgl-button' => 'background-color: transparent !important;',
                ],
            ]
        );
        $this->add_control(
            'button_border_color_idle',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'conditions' => [
                    'relation' => 'or',
                    'terms' => [
                        [
                            'name' => 'button_border_border',
                            'operator' => '!in',
                            'value' => ['', 'none'],
                        ], [
                            'name' => 'animation_style',
                            'operator' => '!==',
                            'value' => '',
                        ],
                    ],
                ],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-button' => '--border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_idle',
                'condition' => [ 'animation_style' => '' ],
                'selector' => '{{WRAPPER}} .wgl-button',
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'button_item_hover',
            [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'button_color_item_hover',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .wgl-button' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_item_hover',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .wgl-button' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.has-bg_animation .pricing__wrapper:hover .wgl-button::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_border_color_item_hover',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [
                    'button_border_border!' => ['', 'none'],
                    'animation_style!' => 'clip_animation'
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .wgl-button' => '--border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_item_hover',
                'condition' => [ 'button_clip_animation' => '' ],
                'selector' => '{{WRAPPER}} .pricing__wrapper:hover .wgl-button',
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'button_hover',
            [ 'label' => esc_html__( 'Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'button_color_hover',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_secondary_color(),
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_hover',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus' => 'background-color: {{VALUE}};',

                    '{{WRAPPER}}.has-bg_animation .pricing__wrapper .wgl-button:hover::after,
                     {{WRAPPER}}.has-bg_animation .pricing__wrapper .wgl-button:focus::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_border_color_hover',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [
                    'button_border_border!' => ['', 'none'],
                    'animation_style!' => 'clip_animation'
                ],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus' => '--border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_hover',
                'condition' => [ 'button_clip_animation' => '' ],
                'selector' => '{{WRAPPER}} .pricing__wrapper .wgl-button:hover'
                            . '{{WRAPPER}} .pricing__wrapper .wgl-button:focus',
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'button_active',
            [ 'label' => esc_html__( 'Active', 'motto-core' ) ]
        );
        $this->add_control(
            'button_color_active',
            [
                'label' => esc_html__( 'Text Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_active',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active,
                     {{WRAPPER}}.has-bg_animation .pricing__wrapper .wgl-button:active::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_border_color_active',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'button_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active' => '--border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_active',
                'condition' => [ 'animation_style' => '' ],
                'selector' => '{{WRAPPER}} .pricing__wrapper .wgl-button:active',
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_control(
            'btn_media_heading',
            [
                'label' => esc_html__( 'Button Media (icon/image)', 'motto-core' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [ 'icon_type!' => '' ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'btn_icon_typography',
                'condition' => [ 'icon_type' => 'font' ],
                'exclude' => [ 'font_family', 'text_transform', 'font_style', 'text_decoration', 'letter_spacing' ],
                'selector' => '{{WRAPPER}} .elementor-icon',
            ]
        );

        $this->add_responsive_control(
            'media_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [ 'icon_type!' => '' ],
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_size',
            [
                'label' => esc_html__( 'Icon Size', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'icon_type' => 'font' ],
                'size_units' => [ 'px', 'em', 'rem', 'vw', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-icon' => '--icon-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->start_controls_tabs(
            'tabs_icon', [
                'condition' => [ 'icon_type' => 'font' ]
            ]
        );
        $this->start_controls_tab(
            'icon_idle',
            [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_color_idle',
            [
                'label' => esc_html__( 'Icon Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_secondary_color(),
                'selectors' => [
                    '{{WRAPPER}} .elementor-icon' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_color_idle',
            [
                'label' => esc_html__( 'Icon Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .elementor-icon,
                     {{WRAPPER}}.has-icon_size_animation .wgl-icon::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_rotation_idle',
            [
                'label' => esc_html__( 'Rotation', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'icon_type' => 'font' ],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'px' => [ 'max' => 360 ],
                ],
                'default' => [ 'size' => -45, 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-icon' => '--icon-rotate: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'icon_item_hover',
            [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_color_item_hover',
            [
                'label' => esc_html__( 'Icon Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .elementor-icon' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_color_item_hover',
            [
                'label' => esc_html__( 'Icon Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .elementor-icon,
                     {{WRAPPER}}.has-icon_size_animation .pricing__wrapper:hover .wgl-icon::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_rotation_item_hover',
            [
                'label' => esc_html__( 'Rotation', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'icon_type' => 'font' ],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'px' => [ 'max' => 360 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .elementor-icon' => '--icon-rotate: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'icon_hover',
            [ 'label' => esc_html__( 'Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_color_hover',
            [
                'label' => esc_html__( 'Icon Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_tertiary_color(),
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover .elementor-icon,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus .elementor-icon' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_color_hover',
            [
                'label' => esc_html__( 'Icon Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_secondary_color(),
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover .elementor-icon,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus .elementor-icon,
                     {{WRAPPER}}.has-icon_size_animation .pricing__wrapper .wgl-button:hover .wgl-icon::before,
                     {{WRAPPER}}.has-icon_size_animation .pricing__wrapper .wgl-button:focus .wgl-icon::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_rotation_hover',
            [
                'label' => esc_html__( 'Rotation', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'icon_type' => 'font' ],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'px' => [ 'max' => 360 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover .elementor-icon,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus .elementor-icon' => '--icon-rotate: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'icon_active',
            [ 'label' => esc_html__( 'Active', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_color_active',
            [
                'label' => esc_html__( 'Icon Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active .elementor-icon' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_color_active',
            [
                'label' => esc_html__( 'Icon Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active .elementor-icon,
                     {{WRAPPER}}.has-icon_size_animation .pricing__wrapper .wgl-button:active .wgl-icon::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_rotation_active',
            [
                'label' => esc_html__( 'Rotation', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'icon_type' => 'font' ],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'px' => [ 'max' => 360 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active .elementor-icon' => '--icon-rotate: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /** STYLE -> BUTTON ANIMATION */

        $this->start_controls_section(
            'style_animation',
            [
                'label' => esc_html__( 'Button Animation', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'animation_style',
            [
                'label' => esc_html__('Animation Style', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'render_type' => 'template',
                'options' => [
                    '' => esc_html__('None', 'motto-core'),
                    'highlight_animation' => esc_html__('Highlight Animation', 'motto-core'),
                    'clip_animation' => esc_html__('Clipping Animation', 'motto-core'),
                    'bg_animation' => esc_html__('Background Animation ', 'motto-core'),
                    'border_animation' => esc_html__('Border Animation', 'motto-core'),
                    'magnetic' => esc_html__('Magnetic', 'motto-core'),
                    'icon_size_animation' => esc_html__('Icon Size Animation', 'motto-core'),
                    'icon_visibility' => esc_html__('Icon Visibility', 'motto-core'),
                ],
                'prefix_class' => 'has-',
                'default' => '',
            ]
        );

        /** Highlight Animation */
        $this->add_control(
            'stroke_highlight_color_normal',
            [
                'label' => esc_html__( 'Stroke Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(),
                'condition' => [ 'animation_style' => 'highlight_animation' ],
                'selectors' => [
                    '{{WRAPPER}} .highlight_svg path' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'stroke_highlight_width_normal',
            [
                'label' => esc_html__( 'Stroke Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'vw', 'custom'],
                'condition' => [ 'animation_style' => 'highlight_animation' ],
                'range' => [
                    'px' => [ 'min' => 0.1, 'max' => 10 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .highlight_svg path' => 'stroke-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        /** Clipping Animation */
        $this->add_responsive_control(
            'button_clip_border',
            [
                'label' => esc_html__( 'Border Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 50 ] ],
                'condition' => [ 'animation_style' => 'clip_animation' ],
                'default' => [ 'size' => 2 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button' => '--border-size:{{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_clip_size',
            [
                'label' => esc_html__( 'Clipping Size', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
                'condition' => [ 'animation_style' => 'clip_animation' ],
                'default' => [ 'size' => 14 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button' => '--corner-size:{{SIZE}}{{UNIT}};',
                ],
            ]
        );

        /** Background Animation */
        $this->start_controls_tabs( 'button_animation', [
            'condition' => [ 'animation_style' => 'bg_animation' ],
        ] );
        $this->start_controls_tab(
            'button_animation_idle',
            [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
        );
        $this->add_responsive_control(
            'button_bg_top_offset_idle',
            [
                'label' => esc_html__( 'Background Top Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button::after' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_bg_left_offset_idle',
            [
                'label' => esc_html__( 'Background Left Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button::after' => 'left:{{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_bg_size',
            [
                'label' => esc_html__('Background Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 200 ],
                    '%' => [ 'min' => 0, 'max' => 100 ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button::after' => '--bg-size: {{SIZE}}{{UNIT}};',
                ]
            ]
        );

        $this->add_control(
            'button_bg_border_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                    'unit' => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_animation_item_hover',
            [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
        );
        $this->add_responsive_control(
            'button_bg_top_offset_item_hover',
            [
                'label' => esc_html__( 'Background Top Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .wgl-button::after' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_bg_left_offset_item_hover',
            [
                'label' => esc_html__( 'Background Left Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .wgl-button::after' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_bg_size_item_hover',
            [
                'label' => esc_html__('Background Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'custom' ],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'render_type' => 'template',
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 2000 ],
                    '%' => [ 'min' => 0, 'max' => 100 ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .wgl-button::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_bg_border_radius_item_hover',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '32',
                    'right' => '32',
                    'bottom' => '32',
                    'left' => '32',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .wgl-button::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_animation_hover',
            [ 'label' => esc_html__( 'Hover', 'motto-core' ) ]
        );
        $this->add_responsive_control(
            'button_bg_top_offset_hover',
            [
                'label' => esc_html__( 'Background Top Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover::after,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus::after' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_bg_left_offset_hover',
            [
                'label' => esc_html__( 'Background Left Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover::after,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus::after' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_bg_size_hover',
            [
                'label' => esc_html__('Background Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'custom' ],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'render_type' => 'template',
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 2000 ],
                    '%' => [ 'min' => 0, 'max' => 100 ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'default' => [ 'size' => 100, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover::after,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_bg_border_radius_hover',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '32',
                    'right' => '32',
                    'bottom' => '32',
                    'left' => '32',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover::after,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_animation_active',
            [ 'label' => esc_html__( 'Active', 'motto-core' ) ]
        );
        $this->add_responsive_control(
            'button_bg_top_offset_active',
            [
                'label' => esc_html__( 'Background Top Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active::after' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_bg_left_offset_active',
            [
                'label' => esc_html__( 'Background Left Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active::after' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_bg_size_active',
            [
                'label' => esc_html__('Background Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'custom' ],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 2000 ],
                    '%' => [ 'min' => 0, 'max' => 100 ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'default' => [ 'size' => 100, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'render_type' => 'template',
            ]
        );

        $this->add_control(
            'button_bg_border_radius_active',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '32',
                    'right' => '32',
                    'bottom' => '32',
                    'left' => '32',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        /** Border Animation */
        $this->add_control(
            'button_border_animation_revers',
            [
                'label' => esc_html__( 'Revers This Animation', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'revers',
                'prefix_class' => '',
                'condition' => [ 'animation_style' => 'border_animation' ],
            ]
        );

        $this->add_control(
            'button_border_animation_color',
            [
                'label' => esc_html__( 'Animation Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'border_animation' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button' => '--ab-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_border_animation_offset',
            [
                'label' => esc_html__('Animation Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 20, 'step' => 1],
                ],
                'condition' => [ 'animation_style' => 'border_animation' ],
                'default' => ['size' => 6],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button' => '--ab-offset: {{SIZE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_border_animation_width',
            [
                'label' => esc_html__('Animation Border Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 10, 'step' => 1],
                ],
                'condition' => [ 'animation_style' => 'border_animation' ],
                'default' => ['size' => 1],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button' => '--ab-width: {{SIZE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_border_animation_extend',
            [
                'label' => esc_html__('Mow Much to Extend the Border', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 50, 'step' => 1],
                ],
                'condition' => [ 'animation_style' => 'border_animation' ],
                'default' => ['size' => 4],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button' => '--ab-extend: {{SIZE}};',
                ],
            ]
        );

        /** Magnetic Threshold */

        $this->add_control(
            'button_magnetic_threshold',
            [
                'label' => esc_html__('Magnetic Threshold', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'render_type' => 'template',
                'style_transfer' => true,
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 10, 'max' => 1920, 'step' => 1],
                ],
                'condition' => [ 'animation_style' => 'magnetic' ],
                'default' => ['size' => 500],
            ]
        );

        $this->add_control(
            'button_magnetic_strong',
            [
                'label' => esc_html__('Magnetic Strong', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'render_type' => 'template',
                'style_transfer' => true,
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 0.05, 'max' => 1, 'step' => 0.05],
                ],
                'condition' => [ 'animation_style' => 'magnetic' ],
                'default' => ['size' => 0.2],
            ]
        );

        /** Icon Size Animation */
        $this->start_controls_tabs(
            'icon_size_animation_tabs',
            [
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
            ]
        );
        $this->start_controls_tab(
            'icon_size_animation_tab_idle',
            [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_size_animation_idle',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_animation_idle',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'default' => ['size' => 8, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'icon_size_animation_tab_item_hover',
            [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_size_animation_item_hover',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .wgl-button .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_animation_item_hover',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper:hover .wgl-button .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'icon_size_animation_tab_hover',
            [ 'label' => esc_html__( 'Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_size_animation_hover',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover .wgl-icon,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_animation_hover',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'default' => ['size' => 12, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:hover .wgl-icon,
                     {{WRAPPER}} .pricing__wrapper .wgl-button:focus .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'icon_size_animation_tab_active',
            [ 'label' => esc_html__( 'Active', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_size_animation_active',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_animation_active',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'default' => ['size' => 12, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .pricing__wrapper .wgl-button:active .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        /** Icon Visibility */
        $this->add_control(
            'icon_visibility',
                [
                'label' => esc_html__( 'Icon Visibility', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [ 'animation_style' => 'icon_visibility' ],
                'options' => [
                    'default' => esc_html__( 'Default', 'motto-core' ),
                    'revert' => esc_html__( 'Revert', 'motto-core' ),
                ],
                'default' => 'default',
                'prefix_class' => 'icon-visibility-'
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $wrapper_classes = $this->get_settings_for_display( 'hover_animation' ) ? ' hover-animation' : '';

        echo '<div class="wgl-pricing_plan', $wrapper_classes, '">',
            '<div class="pricing__wrapper">',

                $this->get_creeping_line(),
                $this->get_bg_text(),
                $this->get_pricing_thumbnail(),

                '<div class="pricing__pretitle">',
                    $this->get_pricing_pretitle(),
                '</div>',

                $this->get_pricing_title(),

                '<div class="pricing__header">',
                    '<div class="pricing__price">',
                        $this->get_currency(),
                        $this->get_price_value(),
                        $this->get_currency_right(),
                        $this->get_period(),
                        $this->get_description(),
                    '</div>',
                '</div>',

                '<div class="pricing__content">',
                    $this->get_settings_for_display( 'content_wysiwyg' ),
                '</div>',

                '<div class="pricing__button">',
                    $this->get_button(),
                '</div>',

            '</div>',
        '</div>';
    }

    protected function get_pricing_title()
    {
        $title = $this->get_settings_for_display( 'title_text' );
        $suffix = $this->get_settings_for_display( 'title_suffix_text' );

        if ( ! $title && ! $suffix ) return;

        $suffix = $suffix ? '<span class="title__suffix">' . $suffix  . '</span>' : '';

        return '<div class="pricing__title">'
                . '<h4 class="title">'
                    . wp_kses( $title, self::get_kses_allowed_html() )
                    . $suffix
                . '</h4>'
            . '</div>';
    }

    protected function get_pricing_thumbnail()
    {
        $_s = $this->get_settings_for_display();
        $this->add_render_attribute('thumbnail', 'class', 'pricing__thumbnail');

        $url_image = $_s['thumb_thumbnail']['url'] ?? false;
        $has_mask = $_s['mask_image_animation'] === 'yes' && !empty($_s['image_mask_color_idle']) && !!$url_image;
        if ($has_mask) {
            $this->add_render_attribute(
                'thumbnail',
                [
                    'class' => 'mask_image',
                    'style' => '-webkit-mask-image: url('.esc_url($url_image).');'
                ]
            );
        }

        $icons = new WGL_Icons;
        return '<div '.$this->get_render_attribute_string('thumbnail').'>'.$icons->build($this, $_s, 'thumb_').'</div>';
    }

    protected function get_pricing_pretitle()
    {
        $pretitle = $this->get_settings_for_display( 'pretitle_text' );
        if ( !$pretitle ) return;

        return '<h6 class="pretitle">'
                . wp_kses( $pretitle, self::get_kses_allowed_html() )
            . '</h6>';
    }

    protected function get_currency()
    {
        $currency = $this->get_settings_for_display( 'currency_text' );
        if ( !$currency ) return;

        return '<span class="price__currency">'
                . esc_html( $currency )
            . '</span>';
    }

    protected function get_currency_right()
    {
        $currency = $this->get_settings_for_display( 'currency_right_text' );
        if ( !$currency ) return;

        return '<span class="price__currency_right">'
                . esc_html( $currency )
            . '</span>';
    }

    protected function get_period()
    {
        $period = $this->get_settings_for_display( 'period_text' );
        if ( !$period ) return;

        return '<span class="price__period">'
                . wp_kses( $period, self::get_kses_allowed_html() )
            . '</span>';
    }

    protected function get_description()
    {
        $description = $this->get_settings_for_display( 'description_text' );
        if ( !$description ) return;

        return '<div class="pricing__description">'
                . wp_kses( trim( $description ), self::get_kses_allowed_html() )
            . '</div>';
    }

    protected function get_bg_text()
    {
        $bg_text = $this->get_settings_for_display( 'bg_text' );
        if ( !$bg_text ) return;

        return '<div class="pricing__bg_text">'
                . wp_kses(  $bg_text, self::get_kses_allowed_html() )
            . '</div>';
    }

    protected function get_creeping_line()
    {
        $creeping_line_text = $this->get_settings_for_display( 'creeping_line_text' );
        if ( !$creeping_line_text ) return;

        $render = '<span>' . wp_kses(  $creeping_line_text, self::get_kses_allowed_html() ) . '</span>';

        return '<div class="pricing__creeping_line">'.
            '<div class="pricing__creeping_line__inner">' . str_repeat($render,10) . '</div>'.
            '<div class="pricing__creeping_line__inner">' . str_repeat($render,10) . '</div>'.
        '</div>';
    }

    protected function get_price_value()
    {
        $price = esc_html( $this->get_settings_for_display( 'price_text' ));
        if ( !$price ) return;

        preg_match( '/(.+)(\.| |,)(\d+)$/', $price, $matches, PREG_OFFSET_CAPTURE );
        if ( isset( $matches[ 0 ] ) ) {
            $price = esc_html( $matches[ 1 ][ 0 ] )
                . '<span class="price_decimal">'
                    . '<span class="price_decimal_sep">'.esc_html( $matches[ 2 ][ 0 ] ) . '</span>'
                    . esc_html( $matches[ 3 ][ 0 ] )
                . '</span>';
        }

        return '<span class="price__value">'
                . $price
            . '</span>';
    }

    protected function get_button()
    {
        $_s = $this->get_settings_for_display();
        if ( !$_s['button_enabled'] ) return;

        ob_start();
            ( new WGL_Button() )->render( $this, $_s );

        return ob_get_clean();
    }

    protected static function get_kses_allowed_html()
    {
        $allowed_attributes = [
            'id' => true,
            'class' => true,
            'style' => true,
        ];

        return [
            'a' => $allowed_attributes + [
                'href' => true,
                'title' => true,
                'rel' => true,
                'target' => true,
            ],
            'br' => $allowed_attributes,
            'b' => $allowed_attributes,
            'strong' => $allowed_attributes,
            'em' => $allowed_attributes,
            'i' => $allowed_attributes,
            'small' => $allowed_attributes,
            'sup' => $allowed_attributes,
            'sub' => $allowed_attributes,
            'span' => $allowed_attributes,
            'p' => $allowed_attributes,
            'ul' => $allowed_attributes,
            'ol' => $allowed_attributes,
            'li' => $allowed_attributes,
        ];
    }

    public function wpml_support_module()
    {
        add_filter( 'wpml_elementor_widgets_to_translate',  [ $this, 'wpml_widgets_to_translate_filter' ] );
    }

    public function wpml_widgets_to_translate_filter( $widgets )
    {
        return \WGL_Extensions\Includes\WGL_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
