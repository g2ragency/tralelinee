<?php
/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/widgets/wgl-service-1.php`.
 */
namespace WGL_Extensions\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{Group_Control_Border,
    Plugin,
    Widget_Base,
    Controls_Manager,
    Icons_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Background,
    Group_Control_Css_Filter};

use WGL_Extensions\{
    Includes\WGL_Icons,
    Includes\WGL_Cursor,
    WGL_Framework_Global_Variables as WGL_Globals,
};

class WGL_Service_1 extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-service-1';
    }

    public function get_title()
    {
        return esc_html__('WGL Service', 'motto-core');
    }

    public function get_icon()
    {
        return 'wgl-services';
    }

    public function get_keywords()
    {
        return [ 'service', 'info', 'box', 'animation' ];
    }

    public function get_categories()
    {
        return ['wgl-modules'];
    }

    protected function register_controls()
    {
        /**
         * CONTENT -> SERVICE CONTENT
         */

        $this->start_controls_section(
            'wgl_service_content',
            ['label' => esc_html__('Service Content', 'motto-core')]
        );

        $this->add_control(
            's_title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'type' => Controls_Manager::TEXTAREA,
			    'dynamic' => [  'active' => true],
                'rows' => 1,
                'default' => esc_html__('Service Title', 'motto-core'),
            ]
        );

        $this->add_control(
            's_subtitle',
            [
                'label' => esc_html__('Subtitle', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
            ]
        );

        $this->add_control(
            's_bg_text',
            [
                'label' => esc_html__('Background Text', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr__('ex: 01', 'motto-core'),
            ]
        );

        $this->add_control(
            's_description',
            [
                'label' => esc_html__('Description', 'motto-core'),
                'type' => Controls_Manager::TEXTAREA,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'alignment',
            [
                'label' => esc_html__('Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'prefix_class' => 'a',
                'toggle' => true,
            ]
        );

        $this->add_control(
            'full_height',
            [
                'label' => esc_html__('Full Height Column', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'return_value' => 'full',
                'prefix_class' => 'height_',
                'default' => 'full',
            ]
        );

        $this->add_control(
            'toggling_image',
            [
                'label' => esc_html__('Toggle Image Visibility', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'return_value' => 'image',
                'prefix_class' => 'toggling_',
            ]
        );
        $this->add_control(
            'toggling_content',
            [
                'label' => esc_html__('Toggle Content Visibility', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'return_value' => 'content',
                'prefix_class' => 'toggling_',
                'default' => 'content',
            ]
        );

        $this->add_responsive_control(
            'container_height',
            [
                'label' => esc_html__('Set Minimum Height', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 50, 'max' => 1000],
                    'vw' => ['min' => 10, 'max' => 70],
                ],
                'default' => ['size' => 530, 'unit' => 'px'],
                'mobile_default' => ['size' => 400, 'unit' => 'px'],
                'conditions' => [
                    'relation' => 'or',
                    'terms' => [
                        [
                            'name' => 'toggling_content',
                            'operator' => '!==',
                            'value' => '',
                        ], [
                            'name' => 'toggling_image',
                            'operator' => '!==',
                            'value' => '',
                        ],
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service-1 ' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'hover_transition',
            [
                'label' => esc_html__('Transition Duration', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'conditions' => [
                    'relation' => 'or',
                    'terms' => [
                        [
                            'name' => 'toggling_content',
                            'operator' => '!==',
                            'value' => '',
                        ], [
                            'name' => 'toggling_image',
                            'operator' => '!==',
                            'value' => '',
                        ],
                    ],
                ],
                'range' => [
                    'px' => ['min' => 0.1, 'max' => 2, 'step' => 0.1],
                ],
                'default' => ['size' => 0.6 ],
                'selectors' => [
                    '{{WRAPPER}}.toggling_content .wgl-service_description,
                    {{WRAPPER}}.toggling_image .wgl-service_media' => '--dur: {{SIZE}}s;',
                ],
            ]
        );

        $this->add_mobile_breakpoint();

        $this->end_controls_section();

        /**
         * CONTENT -> ICON/IMAGE
         */

        $output = [];

        $output['view'] = [
            'label' => esc_html__('View', 'motto-core'),
            'type' => Controls_Manager::SELECT,
            'condition' => ['icon_type' => 'font'],
            'options' => [
                'default' => esc_html__('Default', 'motto-core'),
                'stacked' => esc_html__('Stacked', 'motto-core'),
                'framed'  => esc_html__('Framed', 'motto-core'),
            ],
            'default' => 'stacked',
            'prefix_class' => 'elementor-view-',
        ];

        $output['shape'] = [
            'label' => esc_html__('Shape', 'motto-core'),
            'type' => Controls_Manager::SELECT,
            'condition' => [
                'icon_type' => 'font',
                'view!' => 'default',
            ],
            'options' => [
                'circle' => esc_html__('Circle', 'motto-core'),
                'square' => esc_html__('Square', 'motto-core'),
            ],
            'default' => 'circle',
            'prefix_class' => 'elementor-shape-',
        ];

        WGL_Icons::init(
            $this,
            [
                'output' => $output,
                'section' => true,
                'default' => [
                    'icon' => [
                        'library' => 'flaticon',
                        'value' => 'flaticon flaticon-down-right-arrow'
                    ],
                ],
            ]
        );

        /**
         * CONTENT -> BUTTON
         */

        $this->start_controls_section(
            'section_style_link',
            ['label' => esc_html__('Link', 'motto-core') ]
        );

        $this->add_control(
            'item_link',
            [
                'label' => esc_html__('Link', 'motto-core'),
                'type' => Controls_Manager::URL,
			    'dynamic' => [  'active' => true],
                'conditions' => [
                    'relation' => 'or',
                    'terms' => [
                        [
                            'name' => 'add_item_link',
                            'operator' => '!=',
                            'value' => '',
                        ],
                        [
                            'name' => 'add_read_more',
                            'operator' => '!=',
                            'value' => '',
                        ],
                    ],
                ],
                'default' => [ 'url' => '#' ],
            ]
        );

        $this->add_control(
            'add_item_link',
            [
                'label' => esc_html__('Whole Item Link', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'add_read_more',
            [
                'label' => esc_html__('\'Read More\' Button', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Use', 'motto-core'),
                'label_off' => esc_html__('Hide', 'motto-core'),
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'read_more_alignment',
            [
                'label' => esc_html__('Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'condition' => ['add_read_more' => 'yes'],
                'toggle' => true,
                'prefix_class' => 'read_more_alignment-',
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button-wrapper' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label' => esc_html__('Button Text', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'add_read_more' => 'yes' ],
                'label_block' => true,
                'placeholder' => esc_html__('Learn more', 'motto-core'),
            ]
        );

        $this->add_control(
            'read_more_icon_fontawesome',
            [
                'label' => esc_html__('Icon', 'motto-core'),
                'type' => Controls_Manager::ICONS,
                'condition' => [ 'add_read_more' => 'yes' ],
                'label_block' => true,
                'description' => esc_html__('Select icon from available libraries.', 'motto-core'),
                'default' => [
                    'library' => 'flaticon',
                    'value' => 'flaticon flaticon-down-right-arrow'
                ],
            ]
        );

        $this->add_responsive_control(
            'read_more_icon_size',
            [
                'label' => esc_html__('Icon Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'range' => [
                    'px' => ['min' => 10, 'max' => 100 ],
                ],
                'default' => ['size' => 36],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button .read-more-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'read_more_icon_position',
            [
                'label' => esc_html__('Position', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'options' => [
                    'left' => esc_html__( 'Before', 'motto-core' ),
                    'right' => esc_html__( 'After', 'motto-core' ),
                ],
                'default' => 'right',
            ]
        );

        $this->add_responsive_control(
            'read_more_icon_stroke_size',
            [
                'label' => esc_html__('SVG Stroke Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 300],
                ],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_fontawesome[library]' => 'svg'
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button .read-more-icon path' => 'stroke-width: {{SIZE}}{{UNIT}};'
                ],
            ]
        );

        $this->add_control(
            'read_more_icon_indent',
            [
                'label' => esc_html__( 'Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'range' => [
                    'px' => [ 'max' => 250 ],
                ],
                'default' => ['size' => 20, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'read_more_icon_rotate',
            [
                'label' => esc_html__('Icon Rotate', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'default' => ['unit' => 'deg'],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button .read-more-icon' => 'transform: rotate({{SIZE}}{{UNIT}}); display: inline-block;',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * CONTENT -> CURSOR
         */

        WGL_Cursor::init(
            $this,
            [
                'section' => true,
            ]
        );

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'general_style_section',
            [
                'label' => esc_html__('General', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'general_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '5',
                    'right' => '4',
                    'bottom' => '0',
                    'left' => '4',
                    'unit'  => '%',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service-1 ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_background');

        $this->start_controls_tab(
            'tab_bg_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'general_border_radius_idle',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service-1 ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_idle',
                'types' => ['classic', 'gradient'],
                'fields_options' => [
                    'background' => [ 'default' => 'classic' ],
                    'color' => [ 'default' => WGL_Globals::get_secondary_color(0.8) ],
                    'image' => [ 'label' => esc_html__( 'Background Image', 'motto-core' ) ],
                ],
                'selector' => '{{WRAPPER}} .wgl-service-1',
            ]
        );

        $this->add_control(
            'backdrop_filter',
            [
                'label' => esc_html__('Blur', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 30, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service-1::before' => 'backdrop-filter: blur({{SIZE}}px);-webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_bg_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );

        $this->add_control(
            'general_border_radius_hover',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_hover',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .wgl-service-1:hover,
                     {{WRAPPER}} .wgl-service_link:hover ~ .wgl-service-1',
            ]
        );

        $this->add_control(
            'backdrop_filter_hover',
            [
                'label' => esc_html__('Blur', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 30, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service-1:hover::before,
                     {{WRAPPER}} .wgl-service_link:hover ~ .wgl-service-1::before' => 'backdrop-filter: blur({{SIZE}}px);-webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );

        $this->add_control(
            'item_bg_transition',
            [
                'label' => esc_html__('Transition Delay', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'separator' => 'before',
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.1],
                ],
                'default' => ['size' => 0.4],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service-1' => 'transition: {{SIZE}}s',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_bg_responsive',
            ['label' => esc_html__('Responsive', 'motto-core')]
        );
        $this->add_control(
            'general_border_radius_responsive',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'custom' ],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .wgl-service-1.breakpoint_on-widescreen,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .wgl-service-1.breakpoint_on-desktop,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .wgl-service-1.breakpoint_on-tablet_extra,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .wgl-service-1.breakpoint_on-tablet,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .wgl-service-1.breakpoint_on-mobile_extra,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .wgl-service-1.breakpoint_on-mobile' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_responsive',
                'types' => ['classic', 'gradient'],
                'fields_options' => [
                    'background' => [ 'default' => 'classic' ],
                    'color' => [ 'default' => WGL_Globals::get_h_font_color(0.3) ],
                    'image' => [ 'label' => esc_html__( 'Background Image', 'motto-core' ) ],
                ],
                'selector' => 'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .wgl-service-1.breakpoint_on-widescreen,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .wgl-service-1.breakpoint_on-desktop,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .wgl-service-1.breakpoint_on-tablet_extra,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .wgl-service-1.breakpoint_on-tablet,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .wgl-service-1.breakpoint_on-mobile_extra,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .wgl-service-1.breakpoint_on-mobile',
            ]
        );

        $this->add_control(
            'backdrop_filter_responsive',
            [
                'label' => esc_html__('Blur', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 30, 'step' => 0.5],
                ],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .wgl-service-1.breakpoint_on-widescreen::before,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .wgl-service-1.breakpoint_on-desktop::before,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .wgl-service-1.breakpoint_on-tablet_extra::before,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .wgl-service-1.breakpoint_on-tablet::before,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .wgl-service-1.breakpoint_on-mobile_extra::before,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .wgl-service-1.breakpoint_on-mobile::before' => 'backdrop-filter: blur({{SIZE}}px);-webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> ICON/Image
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_icon_image',
            [
                'label' => esc_html__('Icon/Image', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['icon_type' => 'font'],
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__('Font Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 6, 'max' => 300],
                ],
                'default' => ['size' => 20],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_rotate',
            [
                'label' => esc_html__('Rotate', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_control(
            'icon_position',
            [
                'label' => esc_html__('Button Position', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'static' => esc_html__('Default', 'motto-core'),
                    'absolute' => esc_html__('Absolute', 'motto-core'),
                ],
                'default' => 'absolute',
                'render_type' => 'template',
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_media' => 'position: {{VALUE}}; top: 0; right: 0; left: 0',
                ],
            ]
        );

        $this->add_control(
            'icon_alignment',
            [
                'label' => esc_html__('Icon Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'condition' => ['icon_position' => 'absolute'],
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_media' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'separator' => 'before',
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '40',
                    'right' => '40',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'border_width',
            [
                'label' => esc_html__('Border Width', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => ['view' => 'framed'],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'border_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => ['view!' => 'default'],
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'tabs_icons',
            ['separator' => 'before']
        );
        $this->start_controls_tab(
            'tab_icon_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'icon_primary_color_idle',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-stacked .elementor-icon' => 'fill: {{VALUE}};color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-framed .elementor-icon,
                     {{WRAPPER}}.elementor-view-default .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_secondary_color_idle',
            [
                'label' => esc_html__('Additional Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['view!' => 'default'],
                'default' => WGL_Globals::get_primary_color(),
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-framed .elementor-icon,
				    {{WRAPPER}}.elementor-view-stacked .elementor-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icon_idle',
                'fields_options' => [
                    'box_shadow_type' => [
                        'default' => 'yes'
                    ],
                    'box_shadow' => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical' => 0,
                            'blur' => 0,
                            'spread' => 0,
                            'color' => WGL_Globals::get_primary_color()
                        ]
                    ]
                ],
                'selector' => '{{WRAPPER}} .elementor-icon',
            ]
        );
        $this->add_control(
            'icon_scale_idle',
            [
                'label' => esc_html__( 'Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'x' ],
                'range' => [
                    'x' => [ 'min' => 0.5, 'max' => 2, 'step' => 0.01 ],
                ],
                'default' => [ 'unit' => 'x' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-icon' => 'transform: scale( {{SIZE}} );',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_icon_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'icon_primary_color_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-stacked:hover .elementor-icon' => 'background-color: {{VALUE}};',

                    '{{WRAPPER}}.elementor-view-framed:hover .elementor-icon,
                     {{WRAPPER}}.elementor-view-default:hover .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_secondary_color_hover',
            [
                'label' => esc_html__('Additional Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['view!' => 'default'],
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-framed:hover .elementor-icon' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-stacked:hover .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icon_hover',
                'fields_options' => [
                    'box_shadow_type' => [
                        'default' => 'yes'
                    ],
                    'box_shadow' => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical' => 0,
                            'blur' => 0,
                            'spread' => 10,
                            'color' => WGL_Globals::get_primary_color()
                        ]
                    ]
                ],
                'selector' => '{{WRAPPER}} .elementor-widget-container:hover .elementor-icon',
            ]
        );
        $this->add_control(
            'icon_scale_hover',
            [
                'label' => esc_html__( 'Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'x' ],
                'range' => [
                    'x' => [ 'min' => 0.5, 'max' => 2, 'step' => 0.01 ],
                ],
                'default' => [ 'unit' => 'x' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .elementor-icon' => 'transform: scale( {{SIZE}} );',
                ],
            ]
        );
        $this->add_control(
            'icon_hover_transition',
            [
                'label' => esc_html__('Transition Duration', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'default' => ['size' => 0.6],
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.1],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-icon' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_icon_responsive',
            ['label' => esc_html__('Responsive', 'motto-core')]
        );
        $this->add_control(
            'icon_primary_color_responsive',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-widescreen .elementor-icon,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-desktop .elementor-icon,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-tablet_extra .elementor-icon,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-tablet .elementor-icon,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-mobile_extra .elementor-icon,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-mobile .elementor-icon' => 'background-color: {{VALUE}};',

                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}}:is(.elementor-view-framed,.elementor-view-default) .breakpoint_on-widescreen .elementor-icon,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}}:is(.elementor-view-framed, .elementor-view-default) .breakpoint_on-desktop .elementor-icon,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}:is(.elementor-view-framed, .elementor-view-default) .breakpoint_on-tablet_extra .elementor-icon,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}:is(.elementor-view-framed, .elementor-view-default) .breakpoint_on-tablet .elementor-icon,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}:is(.elementor-view-framed, .elementor-view-default) .breakpoint_on-mobile_extra .elementor-icon,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}:is(.elementor-view-framed, .elementor-view-default) .breakpoint_on-mobile .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_secondary_color_responsive',
            [
                'label' => esc_html__('Additional Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['view!' => 'default'],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}}.elementor-view-framed .breakpoint_on-widescreen .elementor-icon,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}}.elementor-view-framed .breakpoint_on-desktop .elementor-icon,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.elementor-view-framed .breakpoint_on-tablet_extra .elementor-icon,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.elementor-view-framed .breakpoint_on-tablet .elementor-icon,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.elementor-view-framed .breakpoint_on-mobile_extra .elementor-icon,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.elementor-view-framed .breakpoint_on-mobile .elementor-icon' => 'background-color: {{VALUE}};',

                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-widescreen .elementor-icon,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-desktop .elementor-icon,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-tablet_extra .elementor-icon,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-tablet .elementor-icon,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-mobile_extra .elementor-icon,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.elementor-view-stacked .breakpoint_on-mobile .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icon_responsive',
                'fields_options' => [
                    'box_shadow_type' => [
                        'default' => 'yes'
                    ],
                    'box_shadow' => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical' => 0,
                            'blur' => 0,
                            'spread' => 10,
                            'color' => WGL_Globals::get_primary_color()
                        ]
                    ]
                ],
                'selector' => 'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .elementor-icon,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .elementor-icon,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .elementor-icon,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .elementor-icon,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .elementor-icon,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .elementor-icon',
            ]
        );
        $this->add_control(
            'icon_scale_responsive',
            [
                'label' => esc_html__( 'Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'x' ],
                'range' => [
                    'x' => [ 'min' => 0.5, 'max' => 2, 'step' => 0.01 ],
                ],
                'default' => [ 'unit' => 'x' ],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .elementor-icon,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .elementor-icon,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .elementor-icon,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .elementor-icon,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .elementor-icon,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .elementor-icon' => 'transform: scale( {{SIZE}} );',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> Icon/IMAGE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_image_icon',
            [
                'label' => esc_html__('Icon/Image', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['icon_type' => 'image'],
            ]
        );

        $this->add_responsive_control(
            'image_space',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'left' => '0',
                    'right' => '0',
                    'bottom' => '39',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_media .wgl-image-box_img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_size',
            [
                'label' => esc_html__('Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', '%', 'custom'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 800],
                    '%' => ['min' => 5, 'max' => 100],
                ],
                'default' => ['size' => 100, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-image-box_img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'hover_animation_image',
            [
                'label' => esc_html__('Hover Animation', 'motto-core'),
                'type' => Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->start_controls_tabs('image_effects');
        $this->start_controls_tab(
            'image_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'css_filters',
                'selector' => '{{WRAPPER}} .wgl-image-box_img img',
            ]
        );
        $this->add_control(
            'image_opacity',
            [
                'label' => esc_html__('Opacity', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0.10, 'max' => 1, 'step' => 0.01],
                ],
                'default' => ['size' => 0],
                'selectors' => [
                    '{{WRAPPER}} .wgl-image-box_img img' => 'opacity: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'background_hover_transition',
            [
                'label' => esc_html__('Transition Duration', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'default' => ['size' => 0.3],
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.1],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-image-box_img img' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'image_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'css_filters_hover',
                'selector' => '{{WRAPPER}} .elementor-widget-container:hover .wgl-image-box_img img',
            ]
        );
        $this->add_control(
            'image_opacity_hover',
            [
                'label' => esc_html__('Opacity', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0.10, 'max' => 1, 'step' => 0.01],
                ],
                'default' => ['size' => 1],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-image-box_img img' => 'opacity: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'image_responsive',
            ['label' => esc_html__('Responsive', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'css_filters_responsive',
                'selector' => 'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-image-box_img img,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-image-box_img img,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-image-box_img img,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-image-box_img img,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-image-box_img img,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-image-box_img img',
            ]
        );
        $this->add_control(
            'image_opacity_responsive',
            [
                'label' => esc_html__('Opacity', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0.10, 'max' => 1, 'step' => 0.01],
                ],
                'default' => ['size' => 1],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-image-box_img img,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-image-box_img img,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-image-box_img img,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-image-box_img img,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-image-box_img img,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-image-box_img img' => 'opacity: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> TITLE
         */

        $this->start_controls_section(
            'title_style_section',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'condition' => [ 's_title!' => '' ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML Tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html__('‹h1›', 'motto-core'),
                    'h2' => esc_html__('‹h2›', 'motto-core'),
                    'h3' => esc_html__('‹h3›', 'motto-core'),
                    'h4' => esc_html__('‹h4›', 'motto-core'),
                    'h5' => esc_html__('‹h5›', 'motto-core'),
                    'h6' => esc_html__('‹h6›', 'motto-core'),
                    'div' => esc_html__('‹div›', 'motto-core'),
                    'span' => esc_html__('‹span›', 'motto-core'),
                ],
                'default' => 'h3',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_title',
                'label' => esc_html__('Typography', 'motto-core'),
                'selector' => '{{WRAPPER}} .wgl-service_title',
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '50',
                    'right' => '0',
                    'bottom' => '38',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_margin_hover',
            [
                'label' => esc_html__('Margin on Hover', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '50',
                    'right' => '0',
                    'bottom' => '17',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-service_title,
                     body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_title,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_title,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_title,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_title,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_title,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'separator' => 'after',
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'service_color_tab_title' );
        $this->start_controls_tab(
            'custom_service_color_idle',
            ['label' => esc_html__('Idle' , 'motto-core')]
        );
        $this->add_control(
            'service_color_1',
            [
                'label' => esc_html__('Title Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_title' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'custom_service_color_hover',
            ['label' => esc_html__('Hover' , 'motto-core')]
        );
        $this->add_control(
            'service_color_1_hover',
            [
                'label' => esc_html__('Title Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-service_title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'custom_service_color_responsive',
            ['label' => esc_html__('Responsive', 'motto-core')]
        );
        $this->add_control(
            'service_color_1_responsive',
            [
                'label' => esc_html__('Title Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_title,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_title,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_title,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_title,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_title,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> SUBTITLE
         */

        $this->start_controls_section(
            'subtitle_style_section',
            [
                'label' => esc_html__('Subtitle', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['s_subtitle!' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_custom_fonts',
                'selector' => '{{WRAPPER}} .wgl-service_subtitle',
            ]
        );

        $this->add_responsive_control(
            'subtitle_margin',
            [
                'label' => esc_html__('Subtitle Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '2',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'subtitle_rotation',
            [
                'label' => esc_html__( 'Rotation', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'px' => [ 'max' => 360 ],
                    'turn' => [ 'max' => 1, 'step' => 0.05 ],
                ],
                'default' => [ 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_subtitle' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_responsive_control(
            'subtitle_top_offset',
            [
                'label' => esc_html__('Top Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 100],
                    'px' => ['min' => -2000, 'max' => 1000, 'step' => 1],
                ],
                'default' => ['size' => 0, 'unit' => '%'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_subtitle' => 'top: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'subtitle_left_offset',
            [
                'label' => esc_html__('Left Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 100],
                    'px' => ['min' => -2000, 'max' => 1000, 'step' => 1],
                ],
                'default' => ['size' => 0, 'unit' => '%'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_subtitle' => 'left: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'hover_stroke',
            [
                'label' => esc_html__('Animation Text', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'return_value' => 'stroke',
                'prefix_class' => 'animation_',
            ]
        );

        $this->start_controls_tabs( 'service_color_tab_subtitle' );
        $this->start_controls_tab(
            'custom_service_color_subtitle_idle',
            [
                'label' => esc_html__('Idle' , 'motto-core'),
            ]
        );
        $this->add_control(
            'service_color_subtitle',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'service_color_stroke_subtitle',
            [
                'label' => esc_html__('Stroke', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['hover_stroke' => 'stroke'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_subtitle' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'custom_service_color_subtitle_hover',
            [
                'label' => esc_html__('Hover' , 'motto-core'),
            ]
        );
        $this->add_control(
            'service_color_subtitle_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-service_subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'service_color_stroke_subtitle_hover',
            [
                'label' => esc_html__('Stroke', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['hover_stroke' => 'stroke'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-service_subtitle' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'custom_service_color_subtitle_responsive',
            ['label' => esc_html__('Responsive', 'motto-core')]
        );
        $this->add_control(
            'service_color_subtitle_responsive',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_subtitle,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_subtitle,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_subtitle,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_subtitle,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_subtitle,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'service_color_stroke_subtitle_responsive',
            [
                'label' => esc_html__('Stroke', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['hover_stroke' => 'stroke'],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_subtitle,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_subtitle,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_subtitle,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_subtitle,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_subtitle,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_subtitle' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> BG Text
         */

        $this->start_controls_section(
            'background_text',
            [
                'label' => esc_html__('Background Text', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['s_bg_text!' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'bg_text_custom_fonts',
                'selector' => '{{WRAPPER}} .wgl-service_bg_text',
            ]
        );

        $this->add_responsive_control(
            'bg_text_wrapper_size',
            [
                'label' => esc_html__('Wrapper Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => ['min' => 6, 'max' => 300],
                    'em' => ['min' => 1, 'max' => 20],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_bg_text' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bg_text_stroke_size',
            [
                'label' => esc_html__('Stroke Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 2, 'step' => 0.1],
                ],
                'default' => [ 'unit' => 'px', 'size' => 0.5 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_bg_text' => '-webkit-text-stroke-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bg_text_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '9',
                    'right' => '0',
                    'bottom'=> '0',
                    'left' => '9',
                    'unit'  => '%',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_bg_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bg_text_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_bg_text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bg_text_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_bg_text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bg_text_z_index',
            [
                'label' => __( 'Z-Index', 'motto-core' ),
                'type' => Controls_Manager::NUMBER,
			    'dynamic' => [  'active' => true],
                'min' => -5,
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_bg_text' => 'z-index: {{VALUE}};',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_bg_text_styles');

        $this->start_controls_tab(
            'tab_bg_text',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'bg_text_color_idle',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => 'rgba(255,255,255,0)',
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_bg_text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bg_text_bg_color_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_bg_text' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bg_text_stroke_idle',
            [
                'label' => esc_html__('Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['bg_text_stroke_size!' => ''],
                'default' => 'rgba(255,255,255,1)',
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_bg_text' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_bg_text_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );

        $this->add_control(
            'bg_text_color_hover',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => 'rgba(255,255,255,1)',
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-service_bg_text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bg_text_bg_color_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-service_bg_text' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bg_text_stroke_hover',
            [
                'label' => esc_html__('Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['bg_text_stroke_size!' => ''],
                'default' => 'rgba(255,255,255,0)',
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-service_bg_text' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_bg_text_responsive',
            ['label' => esc_html__('Responsive', 'motto-core')]
        );
        $this->add_control(
            'bg_text_color_responsive',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => 'rgba(255,255,255,1)',
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_bg_text,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_bg_text,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_bg_text,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_bg_text,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_bg_text,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_bg_text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bg_text_bg_color_responsive',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_bg_text,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_bg_text,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_bg_text,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_bg_text,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_bg_text,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_bg_text' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bg_text_stroke_responsive',
            [
                'label' => esc_html__('Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['bg_text_stroke_size!' => ''],
                'default' => 'rgba(255,255,255,0)',
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_bg_text,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_bg_text,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_bg_text,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_bg_text,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_bg_text,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_bg_text' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> DESCRIPTION
         */

        $this->start_controls_section(
            'descr_style_section',
            [
                'label' => esc_html__('Description', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['s_description!' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'descr_custom_fonts',
                'selector' => '{{WRAPPER}} .wgl-service_description',
            ]
        );

        $this->add_responsive_control(
            'descr_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_wrapper_description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'descr_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '1',
                    'right' => '0',
                    'bottom' => '25',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('service_color_tab_descr');
        $this->start_controls_tab(
            'custom_service_color_normal_descr',
            ['label' => esc_html__('Idle' , 'motto-core')]
        );
        $this->add_control(
            'service_color_descr',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_description' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'custom_service_color_descr_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'service_color_descr_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-service_description' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'custom_service_color_descr_responsive',
            ['label' => esc_html__('Responsive', 'motto-core')]
        );
        $this->add_control(
            'service_color_descr_responsive',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_description,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_description,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_description,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_description,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_description,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_description' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> BUTTON
         */

        $this->start_controls_section(
            'button_style_section',
            [
                'label' => esc_html__('Button', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['add_read_more!' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_button',
                'selector' => '{{WRAPPER}} .wgl-service_button',
            ]
        );

        $this->add_responsive_control(
            'button_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_inner_padding',
            [
                'label' => esc_html__('Inner Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '20',
                    'right' => '50',
                    'bottom' => '13',
                    'left' => '50',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_border_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '140',
                    'right' => '140',
                    'bottom' => '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'render_type' => 'template',
                'fields_options' => [
                    'border' => [ 'default' => 'solid' ],
                    'width' => [
                        'label' => esc_html__( 'Border Width', 'motto-core' ),
                        'default' => [
                            'top' => '1',
                            'right' => '1',
                            'bottom' => '0',
                            'left' => '1',
                        ],
                    ],
                    'color' => ['type' => Controls_Manager::HIDDEN],
                ],
                'selector' => '{{WRAPPER}} .wgl-service_button',
            ]
        );

        $this->add_control(
            'read_more_button_width',
            [
                'label' => esc_html__( 'Button Min-Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'size_units' => ['px', 'em', 'rem', '%', 'custom'],
                'range' => [
                    'px' => ['max' => 500],
                    '%' => ['max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .button-read-more' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'button_color_tab' );
        $this->start_controls_tab(
            'tab_button_idle',
            ['label' => esc_html__('Idle' , 'motto-core') ]
        );
        $this->add_control(
            'button_color_idle',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .wgl-service_button .read-more-icon' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_color_idle',
                'selector' => '{{WRAPPER}} .wgl-service_button',
            ]
        );
        $this->add_control(
            'button_border_color_idle',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'button_border_border!' => ['', 'none'] ],
                'default' => 'rgba(255,255,255,0.5)',
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_rotate_idle',
            [
                'label' => esc_html__('Rotate', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button .read-more-icon::before' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_button_hover_item',
            [
                'label' => esc_html__('Hover' , 'motto-core'),
            ]
        );
        $this->add_control(
            'button_color_hover_item',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button:hover,
				     {{WRAPPER}} .wgl-service_link ~ .wgl-service-1 .wgl-service_button ,
				     {{WRAPPER}}.animation_toggling .wgl-service_link ~ .wgl-service-1 .wgl-service_button,
				     {{WRAPPER}}.animation_toggling .wgl-service_button' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_hover_item',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_color_hover',
                'selector' => '{{WRAPPER}} .wgl-service_link:hover ~ .wgl-service-1 .wgl-service_button,
                     {{WRAPPER}} .wgl-service_button:hover',
            ]
        );
        $this->add_control(
            'button_border_color_hover',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'button_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_link:hover ~ .wgl-service-1 .wgl-service_button,
				     {{WRAPPER}} .wgl-service_button:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_rotate_hover_item',
            [
                'label' => esc_html__('Rotate', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-service_link:hover ~ .wgl-service-1 .read-more-icon::before,
				     {{WRAPPER}} .wgl-service_button:hover .read-more-icon::before' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_button_item_responsive',
            ['label' => esc_html__('Responsive', 'motto-core')]
        );
        $this->add_control(
            'button_color_item_responsive',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_button,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_button,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_button,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_button,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_button,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_button' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_item_responsive',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_button,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_button,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_button,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_button,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_button,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_button' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_color_responsive',
                'selector' => 'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_button,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_button,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_button,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_button,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_button,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_button',
            ]
        );
        $this->add_control(
            'button_border_color_responsive',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'button_border_border!' => ['', 'none'] ],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .wgl-service_button,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .wgl-service_button,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .wgl-service_button,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .wgl-service_button,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .wgl-service_button,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .wgl-service_button' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_rotate_item_responsive',
            [
                'label' => esc_html__('Rotate', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .breakpoint_on-widescreen .read-more-icon::before,
                     body[data-elementor-device-mode="desktop"] {{WRAPPER}} .breakpoint_on-desktop .read-more-icon::before,
                     body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .breakpoint_on-tablet_extra .read-more-icon::before,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}} .breakpoint_on-tablet .read-more-icon::before,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .breakpoint_on-mobile_extra .read-more-icon::before,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}} .breakpoint_on-mobile .read-more-icon::before' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function add_mobile_breakpoint() {
        // The 'Hide On X' controls are displayed from largest to smallest, while the method returns smallest to largest.
        $active_devices = Plugin::$instance->breakpoints->get_active_devices_list( [ 'reverse' => true ] );
        $active_breakpoints = Plugin::$instance->breakpoints->get_active_breakpoints();

        $avaliable_breakpoints = [];
        foreach ( $active_devices as $breakpoint_key ) {
            $label = 'desktop' === $breakpoint_key ? esc_html__( 'Desktop', 'motto-core' ) : $active_breakpoints[ $breakpoint_key ]->get_label();
            $avaliable_breakpoints[$breakpoint_key] = $label;
        }
        $this->add_control(
            'wgl_mobile_breakpoint',
            [
                /* translators: %s: Device Name. */
                'label' => esc_html__( 'Set Mobile Template On:', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => $avaliable_breakpoints,
                'default' => 'tablet',
            ]
        );
    }

    public function render()
    {
        $_s = $this->get_settings_for_display();

        if (isset($_s['cursor_tooltip']) && '' != $_s['cursor_tooltip']) {
            add_filter( 'wgl/motto_module_cursor', function () { return true; });
        }

        $kses_allowed_html = [
            'a' => [
                'id' => true, 'class' => true, 'style' => true,
                'href' => true, 'title' => true,
                'rel' => true, 'target' => true,
            ],
            'br' => ['id' => true, 'class' => true, 'style' => true],
            'em' => ['id' => true, 'class' => true, 'style' => true],
            'strong' => ['id' => true, 'class' => true, 'style' => true],
            'i' => ['id' => true, 'class' => true, 'style' => true],
            'span' => ['id' => true, 'class' => true, 'style' => true],
            'p' => ['id' => true, 'class' => true, 'style' => true],
            'small' => ['id' => true, 'class' => true, 'style' => true],
            'ul' => ['id' => true, 'class' => true, 'style' => true],
            'ol' => ['id' => true, 'class' => true, 'style' => true],
            'li' => ['id' => true, 'class' => true, 'style' => true],
        ];

        $cursor_data = '';

        if(isset($_s['cursor_tooltip']) && $_s['cursor_tooltip']){
            $cursor = new WGL_Cursor;
            $cursor_data = $cursor->build($this, $_s);
        }

        $this->add_render_attribute(
            'service',
            [
                'class' => [
                    'wgl-service-1',
                    isset($_s['cursor_tooltip']) && $_s['cursor_tooltip'] ? 'wgl-cursor-text additional-cursor' : '',
                ]
            ]
        );

        // The 'Hide On X' controls are displayed from largest to smallest, while the method returns smallest to largest.
        $active_devices = Plugin::$instance->breakpoints->get_active_devices_list( [ 'reverse' => true ] );
        $key = array_search($_s['wgl_mobile_breakpoint'], $active_devices);
        $all_breakpoints = array_slice($active_devices, $key);
        foreach($all_breakpoints as $breakpoint){
            $this->add_render_attribute( 'service', [ 'class' => [ 'breakpoint_on-' . $breakpoint ] ] );
        }

        // Link
        if (!empty($_s['item_link']['url'])) {
            $this->add_link_attributes('link', $_s['item_link']);
        }

        // BG Text
        $service_bg_text = !empty($_s['s_bg_text']) ? '<div class="wgl-service_bg_text">' . wp_kses($_s['s_bg_text'], $kses_allowed_html) . '</div>' : '';

        // Media
        if (!empty($_s['icon_type'])) {
            $media = new WGL_Icons;
            $ib_media = $media->build($this, $_s, []);
        }

        // Read more button
        if ($_s['add_read_more']) {
            $this->add_render_attribute( 'btn', 'class',
                [
                    'align-icon-' . esc_attr($_s['read_more_icon_position']),
                    'wgl-service_button',
                ]
            );

            $icon_font = $_s['read_more_icon_fontawesome'];
            $migrated = isset($_s['__fa4_migrated']['read_more_icon_fontawesome']);
            $is_new = Icons_Manager::is_migration_allowed();
            $icon_output = '';

            if ( $is_new || $migrated ) {
                ob_start();
                Icons_Manager::render_icon(
                    $_s['read_more_icon_fontawesome'],
                    [
                        'class' => 'read-more-icon',
                        'aria-hidden' => 'true',
                    ]
                );
                $icon_output .= ob_get_clean();
            } else {
                $icon_output .= '<i class="icon read-more-icon '.esc_attr($icon_font).'"></i>';
            }

            if (!empty($icon_output) || $_s['read_more_text']){
                $s_button = '<div class="wgl-service_button-wrapper">';
                $s_button .= sprintf('<%s %s %s>',
                    $_s['add_item_link'] ? 'div' : 'a',
                    $_s['add_item_link'] ? '' : $this->get_render_attribute_string('link'),
                    $this->get_render_attribute_string('btn')
                );

                $s_button .= $_s['read_more_icon_fontawesome']['value'] && 'left' === $_s['read_more_icon_position'] ? $icon_output : '';
                $s_button .= $_s['read_more_text'] ? '<span>' . esc_html($_s['read_more_text']) . '</span>' : '';
                $s_button .= $_s['read_more_icon_fontawesome']['value'] && 'left' !== $_s['read_more_icon_position'] ? $icon_output : '';

                $s_button .= $_s['add_item_link'] ? '</div>' : '</a>';
                $s_button .= '</div>';
            }
        }

        // Render
        if ($_s['add_item_link'] && !empty($_s['item_link']['url'])) { ?>
        <a class="wgl-service_link" <?php echo $this->get_render_attribute_string('link'); ?>></a><?php
        }?>
        <div <?php echo $this->get_render_attribute_string('service') , $cursor_data; ?>><?php

        echo $service_bg_text;

        if (!empty($ib_media)) { ?>
            <div class="wgl-service_media"><?php
            echo $ib_media;?>
            </div><?php
        }

        if (!empty($_s['s_subtitle'])) { ?>
            <div class="wgl-service_subtitle"><?php echo wp_kses($_s['s_subtitle'], $kses_allowed_html); ?></div><?php
        }

        if (!empty($_s['s_title'])) {
            echo '<'. $_s['title_tag']. ' class="wgl-service_title">';
                echo '<span class="service_title">'. wp_kses($_s['s_title'], $kses_allowed_html).'</span>';
            echo '</'. $_s['title_tag']. '>';
        }

        if (!empty( $_s['s_description'] ) || !empty($s_button) ) {
            echo '<div class="wgl-service_wrapper_description">';
            if (!empty($_s['s_description'])) {
                    echo '<div class="wgl-service_description">';
                        echo wp_kses($_s['s_description'], $kses_allowed_html);
                    echo '</div>';
                }
                if (!empty($s_button)) {
                    echo $s_button;
                }
            echo '</div>';
        }?>
        </div><?php
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WGL_Extensions\Includes\WGL_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
