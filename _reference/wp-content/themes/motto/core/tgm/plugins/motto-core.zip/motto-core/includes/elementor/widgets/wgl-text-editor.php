<?php
/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/widgets/wgl-text-editor.php`.
 */
namespace WGL_Extensions\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{Group_Control_Background,
    Widget_Base,
    Controls_Manager,
    Repeater,
    Group_Control_Typography,
    Group_Control_Border,
    Group_Control_Box_Shadow};
use WGL_Extensions\{
    WGL_Framework_Global_Variables as WGL_Globals,
    Includes\WGL_Cursor
};

class WGL_Text_Editor extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-text-editor';
    }

    public function get_title()
    {
        return esc_html__('WGL Text Editor', 'motto-core');
    }

    public function get_icon()
    {
        return 'wgl-text-editor';
    }

    public function get_keywords()
    {
        return [ 'editor', 'heading', 'title', 'text' ];
    }

    public function get_categories()
    {
        return ['wgl-modules'];
    }

    protected function register_controls()
    {
        /**
         * CONTENT -> GENERAL
         */

        $this->start_controls_section(
            'content_general',
            ['label' => esc_html__('General', 'motto-core')]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'type' => Controls_Manager::TEXT,

                'dynamic' => [ 'active' => true ],
                'placeholder' => esc_attr__('Title', 'motto-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'motto-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [ 'active' => true ],
                'label_block' => true,
                'placeholder' => esc_attr__('https://your-link.com', 'motto-core'),
                'default' => ['is_external' => 'true'],
            ]
        );

        $repeater->add_control(
            'customize_item_switch',
            [
                'label' => esc_html__('Customize Item', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $repeater->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'text_typo',
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
                'condition' => ['customize_item_switch!' => '']
            ]
        );

        $repeater->add_control(
            'text_color',
            [
                'label' => esc_html__('Color Palette', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__('Default', 'motto-core'),
                    'custom' => esc_html__('Custom', 'motto-core'),
                ],
                'default' => 'default',
                'separator' => 'before',
                'condition' => ['customize_item_switch!' => '']
            ]
        );

        $repeater->start_controls_tabs(
            'tabs_text_color',
            [
                'condition' => [
                    'text_color' => 'custom',
                    'customize_item_switch!' => ''
                ]
            ]
        );

        $repeater->start_controls_tab(
            'tab_text_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $repeater->add_control(
            'text_color_idle',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper {{CURRENT_ITEM}}' => 'color: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_control(
            'text_bg_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper {{CURRENT_ITEM}}' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_control(
            'text_border_idle',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'condition' => [ 'border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper {{CURRENT_ITEM}}' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $repeater->end_controls_tab();

        $repeater->start_controls_tab(
            'tab_text_hover',
            ['label' => esc_html__('Hover', 'motto-core') ]
        );

        $repeater->add_control(
            'text_color_hover',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper {{CURRENT_ITEM}}:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_control(
            'text_bg_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper {{CURRENT_ITEM}}:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_control(
            'text_border_hover',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'condition' => [ 'border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper {{CURRENT_ITEM}}:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $repeater->end_controls_tab();
        $repeater->end_controls_tabs();

        WGL_Cursor::init(
            $repeater,
            [
                'section' => false,
                'repeater' => true,
                'condition' => ['customize_item_switch!' => '']
            ]
        );

        $this->add_control(
            'text_editor_list',
            [
                'label' => esc_html__('Text', 'motto-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'title' => esc_html__('Title 1', 'motto-core'),
                    ],
                    [
                        'title' => esc_html__('Title 2', 'motto-core'),
                    ],
                    [
                        'title' => esc_html__('Title 3', 'motto-core'),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->add_responsive_control(
            'alignment',
            [
                'label' => esc_html__('Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'separator' => 'before',
                'toggle' => false,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'prefix_class' => 'a%s',
                'default' => 'left',
            ]
        );

        $this->end_controls_section();

        /**
         * STYLES -> GENERAL
         */

        $this->start_controls_section(
            'style_title',
            [
                'label' => esc_html__('Text Styles', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'text_typo_all',
                'selector' => '{{WRAPPER}} .text-editor_wrapper',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML Tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'span' => esc_html('‹span›'),
                    'div' => esc_html('‹div›'),
                ],
                'default' => 'h3',
            ]
        );

        $this->add_responsive_control(
            'titles_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .text-editor_wrapper a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'fields_options' => [
                    'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                    'color' => [ 'type' => Controls_Manager::HIDDEN ],
                ],
                'selector' => '{{WRAPPER}} .text-editor_wrapper span, {{WRAPPER}} .text-editor_wrapper a',
            ]
        );

        $this->add_responsive_control(
            'titles_radius',
            [
                'label' => esc_html__( 'Border Radius', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .text-editor_wrapper a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'tabs_text_all_color'
        );

        $this->start_controls_tab(
            'tab_text_all_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'text_color_all_idle',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper span' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .text-editor_wrapper a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'text_bg_all_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper span' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .text-editor_wrapper a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'text_border_all_idle',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'condition' => [ 'border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper span' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .text-editor_wrapper a' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_text_all_hover',
            ['label' => esc_html__('Hover', 'motto-core') ]
        );

        $this->add_control(
            'text_color_all_hover',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper span:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .text-editor_wrapper a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'text_bg_all_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper span:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .text-editor_wrapper a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'text_border_all_hover',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [ 'active' => true ],
                'condition' => [ 'border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .text-editor_wrapper span:hover' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .text-editor_wrapper a:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLES -> MASK EFFECT
         */

        $this->start_controls_section(
            'mask_effect',
            [
                'label' => esc_html__('Text Mask Effect Cursor', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'loop_animation_switch' => '',
                    'text_parallax_switch' => ''
                ]
            ]
        );

        $this->add_control(
            'mask_effect_switch',
            [
                'label' => esc_html__('Text Mask Effect Cursor', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_responsive_control(
            'mask_size',
            [
                'label' => esc_html__('Circle Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [ 'active' => true ],
                'range' => [
                    'px' => [ 'min' => 10, 'max' => 1000 ],
                ],
                'default' => [ 'size' => 344 ],
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-text-editor.mask_effect' => '--circle-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => ['mask_effect_switch!' => '']
            ]
        );

        $this->add_responsive_control(
            'mask_point_top',
            [
                'label' => esc_html__('Start Mask Point Top (px)', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [ 'active' => true ],
                'range' => [
                    'px' => [ 'min' => 10, 'max' => 1000 ],
                ],
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-text-editor.mask_effect' => '--start-circle-point-top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => ['mask_effect_switch!' => '']
            ]
        );

        $this->add_responsive_control(
            'mask_point_left',
            [
                'label' => esc_html__('Start Mask Point Left (px)', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [ 'active' => true ],
                'range' => [
                    'px' => [ 'min' => 10, 'max' => 1000 ],
                ],
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-text-editor.mask_effect' => '--start-circle-point-left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => ['mask_effect_switch!' => '']
            ]
        );

        $this->add_control(
            'mask_visibility',
            [
                'label' => esc_html__('Parallax Direction', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'always' => esc_html__('Always', 'motto-core'),
                    'on_hover' => esc_html__('On Hover', 'motto-core'),
                ],
                'default' => 'always',
                'condition' => ['mask_effect_switch!' => ''],
                'prefix_class' => 'visibility-',
            ]
        );

        $this->add_control(
			'mask_color_switch',
			[
				'label' => esc_html__('Custom Mask Color', 'motto-core'),
				'type' => Controls_Manager::SWITCHER,
                'condition' => ['mask_effect_switch!' => '']
			]
		);

        $this->start_controls_tabs(
            'tabs_mask_color',
            [
                'condition' => [
                    'mask_color_switch!' => '',
                    'mask_effect_switch!' => ''
                ],
            ]
        );

        $this->start_controls_tab(
            'tabs_mask_color_text',
            ['label' => esc_html__('Text', 'motto-core')]
        );

        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'mask_text_color',
				'label' => esc_html__('Background', 'motto-core'),
				'types' => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .text-editor_wrapper-clone',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tabs_mask_color_bg',
            ['label' => esc_html__('Background', 'motto-core')]
        );

        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'mask_text_bg',
				'label' => esc_html__('Background', 'motto-core'),
				'types' => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .text-editor_outer-clone',
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLES -> LOOP ANIMATION
         */

        $this->start_controls_section(
            'loop_animation',
            [
                'label' => esc_html__('Inline Loop Animation', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'mask_effect_switch' => '',
                    'text_parallax_switch' => ''
                ]
            ]
        );

        $this->add_control(
            'loop_animation_switch',
            [
                'label' => esc_html__('Inline Loop Animation', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_responsive_control(
            'loop_animation_gap',
            [
                'label' => esc_html__('Gap', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [ 'active' => true ],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 400 ],
                ],
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .loop_animation' => '--wgl-loop-animation-gap: {{SIZE}}{{UNIT}};',
                ],
                'condition' => ['loop_animation_switch!' => '']
            ]
        );

        $this->add_responsive_control(
            'loop_animation_duration',
            [
                'label' => esc_html__('Animation Duration (sec)', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [ 'active' => true ],
                'range' => [
                    'px' => [ 'min' => 100, 'max' => 1000 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .loop_animation' => '--wgl-loop-animation-duration: {{SIZE}}s;',
                ],
                'condition' => ['loop_animation_switch!' => '']
            ]
        );

        $this->add_control(
            'loop_animation_clone_count',
            [
                'label' => esc_html__('Count of Cloned Text', 'motto-core'),
                'type' => Controls_Manager::NUMBER,
                'dynamic' => [ 'active' => true ],
                'condition' => ['loop_animation_switch!' => '']
            ]
        );

        $this->add_control(
            'loop_animation_reverse',
            [
                'label' => esc_html__('Animation Reverse', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => ['loop_animation_switch!' => '']
            ]
        );

        $this->add_control(
            'loop_animation_hover_stop',
            [
                'label' => esc_html__('Animation Stop on Hover', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => ['loop_animation_switch!' => '']
            ]
        );

        $this->end_controls_section();

        /**
         * STYLES -> PARALLAX ANIMATION
         */

        $this->start_controls_section(
            'text_parallax',
            [
                'label' => esc_html__('Text Parallax', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'mask_effect_switch' => '',
                    'loop_animation_switch' => ''
                ]
            ]
        );

        $this->add_control(
            'text_parallax_switch',
            [
                'label' => esc_html__('Text Parallax', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'text_parallax_dir',
            [
                'label' => esc_html__('Parallax Direction', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'vertical' => esc_html__('Vertical', 'motto-core'),
                    'horizontal' => esc_html__('Horizontal', 'motto-core'),
                ],
                'default' => 'vertical',
                'condition' => ['text_parallax_switch!' => '']
            ]
        );

        $this->add_responsive_control(
            'text_parallax_factor',
            [
                'label' => esc_html__('Parallax Factor', 'motto-core'),
                'type' => Controls_Manager::NUMBER,
                'dynamic' => [ 'active' => true ],
                'description' => esc_html__('Set elements offset and speed. It can be positive (0.3) or negative (-0.3). Less means slower.', 'motto-core'),
                'min' => -3,
                'max' => 3,
                'step' => 0.01,
                'default' => 0.15,
                'condition' => ['text_parallax_switch!' => '']
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $_s = $this->get_settings_for_display();
        $items_text = $wrapper_class = $items_text_html_clone = '';
        $loop_animation_clone_count = $_s['loop_animation_clone_count'] ? $_s['loop_animation_clone_count'] : 5;
        $wrapper_class .= $_s['loop_animation_switch'] ? ' loop_animation' : '';
        $wrapper_class .= $_s['text_parallax_switch'] ? ' text_parallax' : '';
        $wrapper_class .= $_s['loop_animation_reverse'] ? ' reverse' : '';
        $wrapper_class .= $_s['loop_animation_hover_stop'] ? ' hover_stop' : '';
        $wrapper_class .= $_s['mask_effect_switch'] ? ' mask_effect' : '';
        $wrapper_data = '';

        if ($_s['text_parallax_switch']) {
            wp_enqueue_script( 'jquery-paroller', get_template_directory_uri() . '/js/jquery.paroller.min.js' );
            $wrapper_data .= ' data-paroller-direction="' . $_s['text_parallax_dir'] . '"';
            $wrapper_data .= !empty($_s['text_parallax_factor']) ? ' data-paroller-factor="' . $_s['text_parallax_factor'] . '"' : '';
            $wrapper_data .= !empty($_s['text_parallax_factor_tablet']) ? ' data-paroller-factor-lg="' . $_s['text_parallax_factor_tablet'] . '" data-paroller-factor-md="' . $_s['text_parallax_factor_tablet'] . '"' : '';
            $wrapper_data .= !empty($_s['text_parallax_factor_mobile']) ? ' data-paroller-factor-sm="' . $_s['text_parallax_factor_mobile'] . '" data-paroller-factor-xs="' . $_s['text_parallax_factor_mobile'] . '"' : '';
        }

        foreach ($_s['text_editor_list'] as $index => $item) {
            $item_class = '';
            if (isset($item['cursor_tooltip']) && '' != $item['cursor_tooltip']) {
                add_filter( 'wgl/motto_module_cursor', function () { return true; });
                $item_class .= ' wgl-cursor-text';
            }
            $cursor = new WGL_Cursor;
            $cursor_data = $cursor->build($this, $item, $item['_id']);

            $text = $item['title'] ?? '';
            $link = $item['link'] ?? '';

            $has_link = !empty($link['url']);

            if ($has_link) {
                $link = $this->get_repeater_setting_key('link', 'items', $index);
                $this->add_link_attributes($link, $item['link']);
                $text_tag = 'a ' . $this->get_render_attribute_string($link);
                $text_tag_close = 'a';
            } else {
                $text_tag = $text_tag_close = 'span';
            }

            if ($item['customize_item_switch']) {
                $item_class .= ' elementor-repeater-item-' . $item['_id'];
            }

            $item_class = !empty($item_class) ? ' class="' . $item_class . '"' : '';

            $items_text .= '<' . $text_tag . $item_class . $cursor_data . '>'
                . $text
                . '</' . $text_tag_close . '>';
        }

        if ($_s['mask_effect_switch']) {
            $items_text_html_clone = '<div class="text-editor_wrapper text-editor_wrapper-clone">' . $items_text . '</div>';
        }

        if ($_s['loop_animation_switch']) {
            $items_text_html_clone = str_repeat($items_text,$loop_animation_clone_count);
            $items_text_html_clone = '<div class="text-editor_wrapper text-editor_wrapper-clone">' . $items_text_html_clone . '</div>';
            $items_text_html_clone = str_repeat($items_text_html_clone,2);
        }

        $items_text_html = '<' . $_s['title_tag'] . ' class="text-editor_wrapper">' . $items_text . '</' . $_s['title_tag'] . '>';

        echo '<div class="wgl-text-editor' . $wrapper_class . '"' . $wrapper_data . '>',
            $items_text_html,
            $items_text_html_clone,
        '</div>';
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WGL_Extensions\Includes\WGL_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
