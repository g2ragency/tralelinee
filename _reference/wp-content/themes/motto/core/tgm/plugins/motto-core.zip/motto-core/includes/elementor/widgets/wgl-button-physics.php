<?php

/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/widgets/wgl-button-physics.php`.
 */

namespace WGL_Extensions\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{
    Widget_Base,
    Repeater,
    Group_Control_Typography,
    Group_Control_Background,
    Group_Control_Border,
    Group_Control_Box_Shadow,
    Controls_Manager
};

class WGL_Button_Physics extends Widget_Base
{

    public function get_name()
    {
        return 'wgl-button-physics';
    }

    public function get_title()
    {
        return esc_html__('WGL Button Physics', 'motto-core');
    }

    public function get_icon()
    {
        return 'wgl-button-physics';
    }

    public function get_keywords()
    {
        return ['link', 'button', 'canvas', 'matter', 'physics'];
    }

    public function get_categories()
    {
        return ['wgl-modules'];
    }

    public function get_script_depends()
    {
        return ['wgl-widgets', 'matter'];
    }

    protected function register_controls()
    {
        /** CONTENT -> GENERAL */

        $this->start_controls_section(
            'content_general',
            ['label' => esc_html__('General', 'motto-core')]
        );

        $this->add_control(
            'title_text',
            [
                'label' => esc_html__( 'Title', 'motto-core' ),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => esc_html__( 'We Create World-Class Digital Products', 'motto-core' ),
            ]
        );

        $this->add_responsive_control(
            'item_min_height',
            [
                'label' => esc_html__('Items Min Height', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 200, 'max' => 1000],
                ],
                'default' => ['size' => 800],
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_matter' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'items_restitution',
            [
                'label' => esc_html__('Restitution', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.01],
                ],
                'description' => esc_html__('A Number that defines the restitution (elasticity) of the body', 'motto-core'),
                'default' => ['size' => 0.5 ],
            ]
        );

        $this->add_control(
            'items_friction',
            [
                'label' => esc_html__('Friction', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.01],
                ],
                'description' => esc_html__('A Number that specifies a thin boundary around the body where it is allowed to slightly sink into other bodies.', 'motto-core'),
                'default' => ['size' => 0 ],
            ]
        );
        
        $this->add_control(
            'items_density',
            [
                'label' => esc_html__('Density', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.01],
                ],
                'description' => esc_html__('A Number that defines the density of the body', 'motto-core'),
                'default' => ['size' => 0.01 ],
            ]
        );
        $repeater = new Repeater();

        $repeater->add_control(
            'button_title',
            [
                'label' => esc_html__('Button Title', 'motto-core'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => ['active' => true],
                'label_block' => true,
            ]
        );

        $repeater->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_fonts',
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item',
            ]
        );

        // Loop requires a re-render so no 'render_type = none'
        $repeater->add_responsive_control(
            'button_width',
            [
                'label' => esc_html__('Circle Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 1, 'max' => 1000],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'], 
                'render_type' => 'template',       
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item' => '--size-circle: {{SIZE}};width: calc({{SIZE}}{{UNIT}} * 2); height: calc({{SIZE}}{{UNIT}} * 2);',
                ],
                
                'frontend_available' => true,
            ]
        );

        $repeater->add_responsive_control(
            'button_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $repeater->start_controls_tabs(
            'button',
            ['separator' => 'before']
        );

        $repeater->start_controls_tab(
            'custom_button_color_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $repeater->add_control(
            'button_color',
            [
                'label' => esc_html__( 'Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item' => 'color: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'button_bg',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item',
            ]
        );

        $repeater->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item',
            ]
        );

        $repeater->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item',
            ]
        );

        $repeater->end_controls_tab();

        $repeater->start_controls_tab(
            'custom_button_color_active',
            ['label' => esc_html__('Active', 'motto-core')]
        );

        $repeater->add_control(
            'button_color_active',
            [
                'label' => esc_html__( 'Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item.active' => 'color: {{VALUE}};',
                ],
            ]
        );

        $repeater->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'button_bg_active',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item.active',
            ]
        );

        $repeater->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border_active',
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item.active',
            ]
        );

        $repeater->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_active',
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}.wgl-physics_item.active',
            ]
        );

        $repeater->end_controls_tab();
        $repeater->end_controls_tabs();

        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'motto-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => ['active' => true],
                'label_block' => true,
                'default' => ['url' => '#'],
            ]
        );

        $this->add_control(
            'items',
            [
                'label' => esc_html__('Button', 'motto-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{button_title}}',
                'default' => [
                    [
                        'button_title' => esc_html__('Circuit Title 1', 'motto-core'),
                    ],
                    [
                        'button_title' => esc_html__('Circuit Title 2', 'motto-core'),
                    ],
                    [
                        'button_title' => esc_html__('Circuit Title 3', 'motto-core'),
                    ],
                ],
            ]
        );

        $this->end_controls_section();

        /** CONTENT -> CONTENT */

        /**
         * STYLES -> General
         */

         $this->start_controls_section(
            'section_style_general',
            [
                'label' => esc_html__('General', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'matter_bg_idle',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .wgl-physics_matter',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'matter_border',
                'render_type' => 'template',
                'selector' => '{{WRAPPER}} .wgl-physics_matter',
            ]
        );

        $this->add_responsive_control(
            'matter_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'unit' => 'px',
                    'isLinked' => true
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_matter' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'general_shadow',
                'selector' => '{{WRAPPER}} .wgl-physics_matter',
            ]
        );

        $this->end_controls_section();

         /**
         * STYLES -> ITEMS
         */

         $this->start_controls_section(
            'section_style_items',
            [
                'label' => esc_html__('Items', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'items_fonts',
                'selector' => '{{WRAPPER}} .wgl-physics_item',
            ]
        );

        // Loop requires a re-render so no 'render_type = none'
        $this->add_responsive_control(
            'items_width',
            [
                'label' => esc_html__('Circles Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 1, 'max' => 1000],
                ],
                'default' => ['size' => 70],
                'devices' => ['desktop', 'tablet', 'mobile'], 
                'render_type' => 'template',       
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_item' => '--size-circle: {{SIZE}};width: calc({{SIZE}}{{UNIT}} * 2); height: calc({{SIZE}}{{UNIT}} * 2);',
                ],
                
                'frontend_available' => true,
            ]
        );

        $this->add_responsive_control(
            'items_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_heading',
            [
                'label' => esc_html__('Animation', 'motto-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'items_increase_active',
            [
                'label' => esc_html__('Increase Active', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'items_transition',
            [
                'label' => esc_html__('Visibility Delay', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.01],
                ],
                'default' => ['size' => 0.45],
            ]
        );

        $this->start_controls_tabs(
            'tabs_items',
            ['separator' => 'before']
        );
        $this->start_controls_tab(
            'tab_item_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'item_color_idle',
            [
                'label' => esc_html__( 'Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_item' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_bg_idle',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .wgl-physics_item',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_border_idle',
                'selector' => '{{WRAPPER}} .wgl-physics_item',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_shadow_idle',
                'selector' => '{{WRAPPER}} .wgl-physics_item',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_item_active',
            ['label' => esc_html__('Active', 'motto-core')]
        );
        
        $this->add_control(
            'item_color_active',
            [
                'label' => esc_html__( 'Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_item.active' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_bg_active',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .wgl-physics_item.active',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_border_active',
                'selector' => '{{WRAPPER}} .wgl-physics_item.active',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_shadow_active',
                'selector' => '{{WRAPPER}} .wgl-physics_item.active',
            ]
        );
        
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /** STYLE -> TITLE */

        $this->start_controls_section(
            'style_title',
            [
                'label' => esc_html__( 'Title', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'title_text!' => '' ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .wgl-physics_title',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__( 'HTML Tag', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html( '‹h1›' ),
                    'h2' => esc_html( '‹h2›' ),
                    'h3' => esc_html( '‹h3›' ),
                    'h4' => esc_html( '‹h4›' ),
                    'h5' => esc_html( '‹h5›' ),
                    'h6' => esc_html( '‹h6›' ),
                    'div' => esc_html( '‹div›' ),
                ],
                'default' => 'h4',
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__( 'Margin', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__( 'Padding', 'motto-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'title_position',
			[
				'label' => esc_html__( 'Position', 'motto-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'fixed',
				'options' => [
                    'relative' => esc_html__( 'Relative', 'motto-core' ),
					'absolute' => esc_html__( 'Absolute', 'motto-core' ),
					'fixed' => esc_html__( 'Default', 'motto-core' ),
				],
				'selectors' => [
					'{{WRAPPER}} .wgl-physics_title' => 'position: {{VALUE}};',
				],
			]
		);

        $this->add_responsive_control(
            'title_position_top',
            [
                'label' => esc_html__( 'Top Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 1200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_title' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_position_left',
            [
                'label' => esc_html__( 'Left Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -1200, 'max' => 1200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_title' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-physics_title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render()
    {
        $this->add_render_attribute('button_physics', 'class', 'wgl-button_physics');
        $this->add_render_attribute( 'button_elements', [
            'class' => [
                'wgl-physics_elements',
            ],
            'data-increase-active' => esc_attr($this->get_settings_for_display( 'items_increase_active' )),
            'data-delay' => esc_attr($this->get_settings_for_display( 'items_transition' )['size'] ?? '0.45'),
            'data-restitution' => esc_attr($this->get_settings_for_display( 'items_restitution' )['size'] ?? '0.5'),
            'data-friction' => esc_attr($this->get_settings_for_display( 'items_friction' )['size'] ?? '0'),
            'data-density' => esc_attr($this->get_settings_for_display( 'items_density' )['size'] ?? '0.01'),
        ] );
        // Render
        echo '<div ', $this->get_render_attribute_string('button_physics'), '>';
            echo '<div class="wgl-physics_matter">';
                echo '<div class="wgl-physics_canvas">';
                echo '</div>';
                echo '<div ', $this->get_render_attribute_string('button_elements'), '>';
                    echo $this->get_canvas_item_html();
                echo '</div>';
                if ( $title = $this->get_settings_for_display( 'title_text' ) ) {
                    echo '<', $this->get_settings_for_display( 'title_tag' ), ' class="wgl-physics_title">',
                    esc_html( $title ),
                    '</', $this->get_settings_for_display( 'title_tag' ), '>';
                }
            echo '</div>';
        echo '</div>';
    }

    protected function get_canvas_item_html()
    {
        $_s = $this->get_settings_for_display();

        $content = $link = '';

        foreach ($_s['items'] as $index => $item) {

            // Link
            $has_link = !empty($item['link']['url']);
            if ($has_link) {
                $link = $this->get_repeater_setting_key('link', 'items', $index);
                $this->add_link_attributes($link, $item['link']);
            }

            ob_start();

            echo '<div class="wgl-physics_item elementor-repeater-item-' . $item['_id'] . '" data-item-id="' . $item['_id'] . '">';

            echo $has_link ? '<a class="wgl-button_physics_link" ' . $this->get_render_attribute_string($link) . '></a>' : '';

            if (!empty($item['button_title'])) {
                echo '<span class="wgl-button_physics_title">' . $item['button_title'] . '</span>';
            }

            echo '</div>';

            $content .= ob_get_clean();
        }

        return $content;
    }

    public function wpml_support_module()
    {
        add_filter('wpml_elementor_widgets_to_translate', [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter($widgets)
    {
        return \WGL_Extensions\Includes\WGL_WPML_Settings::get_translate(
            $this,
            $widgets
        );
    }
}
