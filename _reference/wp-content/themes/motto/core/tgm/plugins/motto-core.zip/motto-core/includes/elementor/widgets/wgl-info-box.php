<?php
/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/widgets/wgl-info-box.php`.
 */
namespace WGL_Extensions\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{
	Group_Control_Border,
	Widget_Base,
	Controls_Manager,
    Utils,
	Group_Control_Typography,
	Group_Control_Box_Shadow,
	Group_Control_Background,
	Group_Control_Css_Filter};
use WGL_Extensions\{
	WGL_Framework_Global_Variables as WGL_Globals,
    Includes\WGL_Icons,
    Templates\WGLInfoBoxes,
    Includes\WGL_Cursor
};

class WGL_Info_Box extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-info-box';
    }

    public function get_title()
    {
        return esc_html__('WGL Info Box', 'motto-core');
    }

    public function get_icon()
    {
        return 'wgl-info-box';
    }

    public function get_categories()
    {
        return ['wgl-modules'];
    }

    public function get_keywords() {
        return ['info', 'box', 'infobox', 'icon', 'button'];
    }

    protected function register_controls()
    {
        /**
         * CONTENT -> GENERAL
         */

        $this->start_controls_section(
            'content_general',
            ['label' => esc_html__('General', 'motto-core')]
        );

        $this->add_control(
            'layout',
            [
                'label' => esc_html__('Layout', 'motto-core'),
                'type' => 'wgl-radio-image',
                'condition' => ['icon_type!' => ''],
                'options' => [
                    'top' => [
                        'title' => esc_html__('Top', 'motto-core'),
                        'image' => WGL_EXTENSIONS_ELEMENTOR_URL . 'assets/img/wgl_elementor_addon/icons/style_def.png',
                    ],
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'image' => WGL_EXTENSIONS_ELEMENTOR_URL . 'assets/img/wgl_elementor_addon/icons/style_left.png',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'image' => WGL_EXTENSIONS_ELEMENTOR_URL . 'assets/img/wgl_elementor_addon/icons/style_right.png',
                    ],
                ],
                'default' => 'top',
            ]
        );

        $this->add_responsive_control(
            'alignment',
            [
                'label' => esc_html__('Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => true,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'prefix_class' => 'a%s',
            ]
        );

        $this->add_responsive_control(
            'container_min_height',
            [
                'label' => esc_html__('General Min Height', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'separator' => 'before',
                'range' => [
                    'px' => ['min' => 50, 'max' => 1000],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_wrapper' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_v_alignment',
            [
                'label' => esc_html__('General Vertical Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'container_min_height[size]',
                            'operator' => '>',
                            'value' => '0'
                        ],
                    ]
                ],
                'toggle' => false,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Top', 'motto-core'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Bottom', 'motto-core'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'flex-end',
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_wrapper' => 'justify-content: {{VALUE}}; align-items: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_min_height',
            [
                'label' => esc_html__('Content Min Height', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'separator' => 'before',
                'range' => [
                    'px' => ['min' => 50, 'max' => 1000],
                ],
                'selectors' => [
                    '{{WRAPPER}} .content_wrapper' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_v_alignment',
            [
                'label' => esc_html__('Content Vertical Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'content_min_height[size]',
                            'operator' => '>',
                            'value' => '0'
                        ],
                    ]
                ],
                'toggle' => false,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Top', 'motto-core'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Bottom', 'motto-core'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'flex-end',
                'selectors' => [
                    '{{WRAPPER}} .content_wrapper' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * CONTENT -> ICON/IMAGE
         */

        $output = [];

        $output['view'] = [
            'label' => esc_html__('View', 'motto-core'),
            'type' => Controls_Manager::SELECT,
            'condition' => ['icon_type' => ['font', 'number', 'image']],
            'options' => [
                'default' => esc_html__('Default', 'motto-core'),
                'stacked' => esc_html__('Stacked', 'motto-core'),
                'framed'  => esc_html__('Framed', 'motto-core'),
                'bubble'   => esc_html__('Bubble', 'motto-core'),
            ],
            'default' => 'default',
            'prefix_class' => 'elementor-view-',
        ];

        $output['shape'] = [
            'label' => esc_html__('Shape', 'motto-core'),
            'type' => Controls_Manager::SELECT,
            'condition' => [
                'icon_type' => ['font', 'number'],
                'view!' => ['default', 'bubble'],
            ],
            'options' => [
                'circle' => esc_html__('Circle', 'motto-core'),
                'square' => esc_html__('Square', 'motto-core'),
            ],
            'default' => 'square',
            'prefix_class' => 'elementor-shape-',
        ];

        WGL_Icons::init(
            $this,
            [
                'output' => $output,
                'section' => true,
	            'default' => [
		            'media_type' => 'font',
		            'icon' => [
			            'library' => 'solid',
			            'value' => 'fas fa-icons'
		            ],
	            ],
                'media_types_options' => [
                    '' => [
                        'title' => esc_html__('None', 'motto-core'),
                        'icon' => 'eicon-ban',
                    ],
                    'number' => [
                        'title' => esc_html__('Number', 'motto-core'),
                        'icon' => 'fa fa-list-ol',
                    ],
                    'font' => [
                        'title' => esc_html__('Icon', 'motto-core'),
                        'icon' => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => esc_html__('Image', 'motto-core'),
                        'icon' => 'far fa-image',
                    ],
                ],
            ]
        );

        /**
         * CONTENT -> CONTENT
         */

        $this->start_controls_section(
            'content_content',
            ['label' => esc_html__('Content', 'motto-core')]
        );

        $this->add_control(
            'ib_title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'type' => Controls_Manager::TEXT,

			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => esc_html__('Info Box Title', 'motto-core'),
            ]
        );

        $this->add_control(
            'ib_subtitle',
            [
                'label' => esc_html__('Subtitle', 'motto-core'),
                'type' => Controls_Manager::TEXT,

			    'dynamic' => [  'active' => true],
                'label_block' => true,
            ]
        );

	    $this->add_control(
		    'ib_bg_text',
		    [
			    'label' => esc_html__('Background Text', 'motto-core'),
			    'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
			    'label_block' => true,
                'placeholder' => esc_attr__('ex: 01', 'motto-core'),
		    ]
	    );

        $this->add_control(
            'ib_content',
            [
                'label' => esc_html__('Content', 'motto-core'),
                'type' => Controls_Manager::WYSIWYG,
			    'dynamic' => [  'active' => true],
                'placeholder' => esc_attr__('Description Text', 'motto-core'),
                'label_block' => true,
                'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'motto-core'),
            ]
        );

        $this->end_controls_section();

        /**
         * CONTENT -> LINK
         */

        $this->start_controls_section(
            'content_link',
            ['label' => esc_html__('Link', 'motto-core')]
        );

        $this->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'motto-core'),
                'type' => Controls_Manager::URL,
			    'dynamic' => [  'active' => true],
                'conditions' => [
                    'relation' => 'or',
                    'terms' => [
                        [
                            'name' => 'module_link',
                            'operator' => '!=',
                            'value' => '',
                        ],
                        [
                            'name' => 'add_read_more',
                            'operator' => '!=',
                            'value' => '',
                        ],
                    ],
                ],
                'label_block' => true,
	            'default' => [ 'url' => '#' ],
            ]
        );

        $this->add_control(
            'module_link',
            [
                'label' => esc_html__('Whole Module Link', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

	    $this->add_control(
            'add_read_more',
            [
                'label' => esc_html__('\'Read More\' Button', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Use', 'motto-core'),
                'label_off' => esc_html__('Hide', 'motto-core'),
                'default' => 'yes',
            ]
        );

	    $this->add_control(
            'read_more_inline',
            [
                'label' => esc_html__('Inline Button', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [
                    'layout' => ['left', 'right'],
                    'add_read_more!' => ''
                ],
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label' => esc_html__('Button Text', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'conditions' => [
                    'relation' => 'or',
                    'terms' => [
                        [
                            'terms' => [
                                [
                                    'name' => 'layout',
                                    'operator' => '=',
                                    'value' => 'top',
                                ], [
                                    'name' => 'add_read_more',
                                    'operator' => '!=',
                                    'value' => '',
                                ]
                            ]
                        ],
                        [
                            'terms' => [
                                [
                                    'name' => 'layout',
                                    'operator' => 'in',
                                    'value' => ['left', 'right'],
                                ], [
                                    'name' => 'add_read_more',
                                    'operator' => '!=',
                                    'value' => '',
                                ], [
                                    'name' => 'read_more_inline',
                                    'operator' => '=',
                                    'value' => '',
                                ]
                            ]
                        ],
                    ],
                ],
                'label_block' => true,
                'default' => esc_html__('Read More', 'motto-core'),
            ]
        );

        $this->add_control(
            'button_type',
            [
                'label' => esc_html__( 'Button Type', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'style_transfer' => true,
                'options' => [
                    'wgl-button' => esc_html__( 'Default Button Style', 'motto-core' ),
                    'button-read-more' => esc_html__( 'Read More Style', 'motto-core' ),
                ],
                'condition' => [ 'add_read_more' => 'yes' ],
                'default' => 'button-read-more',
            ]
        );

        $this->add_control(
            'read_more_icon_type',
            [
                'label' => esc_html__('Icon Type', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'separator' => 'before',
                'label_block' => false,
                'condition' => [ 'add_read_more' => 'yes' ],
                'toggle' => false,
                'options' => [
                    '' => [
                        'title' => esc_html__('None', 'motto-core'),
                        'icon' => 'eicon-ban',
                    ],
                    'font' => [
                        'title' => esc_html__('Icon', 'motto-core'),
                        'icon' => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => esc_html__('Image', 'motto-core'),
                        'icon' => 'far fa-image',
                    ]
                ],
                'default' => 'font',
            ]
        );

	    $this->add_control(
		    'read_more_icon_fontawesome',
		    [
			    'label' => esc_html__('Button Icon', 'motto-core'),
			    'type' => Controls_Manager::ICONS,
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_type' => 'font'
                ],
			    'description' => esc_html__('Select icon from available libraries.', 'motto-core'),
			    'label_block' => true,
                'default' => [
                    'library' => 'flaticon',
                    'value' => 'flaticon flaticon-down-right-arrow'
				],
		    ]
	    );

        $this->add_control(
            'read_more_icon_thumbnail',
            [
                'label' => esc_html__('Image', 'motto-core'),
                'type' => Controls_Manager::MEDIA,
			    'dynamic' => [  'active' => true],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_type' => 'image'
                ],
                'label_block' => true,
                'default' => ['url' => Utils::get_placeholder_image_src()],
            ]
        );

        $this->add_control(
            'read_more_icon_align',
            [
                'label' => esc_html__( 'Position', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_type!' => ''
                ],
                'options' => [
                    'row' => esc_html__( 'Before', 'motto-core' ),
                    'row-reverse' => esc_html__( 'After', 'motto-core' ),
                ],
                'default' => 'row-reverse',
                'selectors' => [
                    '{{WRAPPER}} .button-read-more,
                     {{WRAPPER}} .wgl-button .button__content' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'read_more_icon_indent',
            [
                'label' => esc_html__( 'Icon/Image Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
	            'condition' => [
		            'add_read_more' => 'yes',
		            'read_more_text!' => '',
                    'read_more_icon_type' => ['font','image'],
	            ],
                'range' => [
                    'px' => [ 'max' => 250 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'gap: {{SIZE}}{{UNIT}}; --wgl-gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_icon_top',
            [
                'label' => esc_html__('Icon/Image Top Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem', 'custom'],
                'range' => [
                    'px' => ['min' => -50, 'max' => 50],
                ],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_text!' => '',
                    'read_more_icon_type' => ['font','image'],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button .read-more-icon' => '--icon-translate-y: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .wgl-infobox_button .wgl-infobox_button__media img' => 'top: {{SIZE}}{{UNIT}};'
                ],
            ]
        );

        $this->add_responsive_control(
            'button_icon_size',
            [
                'label' => esc_html__('Icon Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'custom'],
                'range' => [
                    'px' => ['min' => 6, 'max' => 300],
                ],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_type' => 'font',
                    'read_more_icon_fontawesome[value]!' => ''
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button .elementor-icon,
                     {{WRAPPER}} .wgl-infobox_button .read-more-icon' => '--icon-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_image_size',
            [
                'label' => esc_html__('Image Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'custom'],
                'range' => [
                    'px' => ['min' => 6, 'max' => 200],
                ],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_type' => 'image',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button .wgl-infobox_button__media img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_icon_stroke_size',
            [
                'label' => esc_html__('SVG Stroke Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 300],
                ],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_fontawesome[library]' => 'svg'
                ],
                'selectors' => [
                    '{{WRAPPER}} .read-more-icon path' => 'stroke-width: {{SIZE}}{{UNIT}};'
                ],
            ]
        );

	    $this->end_controls_section();

        /**
         * CONTENT -> CURSOR
         */

        WGL_Cursor::init(
            $this,
            [
                'section' => true,
            ]
        );

        /**
         * STYLE -> ICON
         */

        $this->start_controls_section(
            'style_icon',
            [
                'label' => esc_html__('Icon', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['icon_type' => 'font'],
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__('Icon Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 6, 'max' => 300],
                ],
                'default' => ['size' => 80],
                'tablet_default' => ['size' => 60],
                'mobile_default' => ['size' => 50],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_rotate',
            [
                'label' => esc_html__('Icon Rotate', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

	    $this->add_responsive_control(
            'icon_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'separator' => 'before',
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
		            'top' => '0',
		            'right' => '0',
		            'bottom' => '4',
		            'left' => '0',
		            'unit'  => 'px',
		            'isLinked' => false
	            ],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'border_width',
            [
                'label' => esc_html__('Border Width', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => ['view' => 'framed'],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_border_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => ['view!' => 'default'],
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper .elementor-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'tabs_icons',
            ['separator' => 'before']
        );

        $this->start_controls_tab(
            'tab_icon_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'icon_primary_color_idle',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-stacked .elementor-icon' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-framed .elementor-icon,
                     {{WRAPPER}}.elementor-view-default .elementor-icon,
                     {{WRAPPER}}.elementor-view-bubble .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_secondary_color_idle',
            [
                'label' => esc_html__('Additional Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['view!' => ['default','bubble']],
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-framed .elementor-icon' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-stacked .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icon_idle',
                'selector' => '{{WRAPPER}} .elementor-icon',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_icon_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );

        $this->add_control(
            'icon_primary_color_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-stacked:hover .elementor-icon' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-framed:hover .elementor-icon,
                     {{WRAPPER}}.elementor-view-default:hover .elementor-icon,
                     {{WRAPPER}}.elementor-view-bubble:hover .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_secondary_color_hover',
            [
                'label' => esc_html__('Additional Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['view!' => ['default','bubble']],
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-framed:hover .elementor-icon' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-stacked:hover .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icon_hover',
                'selector' => '{{WRAPPER}}:hover .elementor-icon',
            ]
        );

        $this->add_control(
            'hover_animation_icon',
            [
                'label' => esc_html__('Hover Animation', 'motto-core'),
                'type' => Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> Number
         */

		$this->start_controls_section(
			'section_style_number',
			[
				'label' => esc_html__('Number', 'motto-core'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [ 'icon_type'  => 'number' ],
			]
		);

		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'number_typo',
                'selector' => '{{WRAPPER}} .wgl-number',
            ]
        );

        $this->add_control(
			'number_view',
			[
				'label' => esc_html__( 'Layout', 'motto-core' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'inline-block' => [
						'title' => esc_html__( 'Default', 'motto-core' ),
						'icon' => 'eicon-ellipsis-h',
					],
					'block; width: auto' => [
						'title' => esc_html__( 'Block', 'motto-core' ),
						'icon' => 'eicon-editor-list-ul',
					],
				],
                'condition' => [ 'layout' => ['top'] ],
                'default' => 'inline-block',
                'selectors' => [
					'{{WRAPPER}} .wgl-number' => 'display: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'number_space',
			[
				'label' => esc_html__('Margin', 'motto-core'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
		            'top' => '0',
		            'right' => '0',
		            'bottom' => '27',
		            'left' => '0',
		            'unit'  => 'px',
		            'isLinked' => false
	            ],
				'selectors' => [
					'{{WRAPPER}} .wgl-number' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'number_padding',
			[
				'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wgl-number' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'number_border_width',
			[
				'label' => esc_html__('Border Width', 'motto-core'),
				'type' => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} .wgl-number' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; border-style: solid;',
				],
			]
		);

		$this->add_responsive_control(
			'number_border_radius',
			[
				'label' => esc_html__('Border Radius', 'motto-core'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wgl-number' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
            'number_z_index',
            [
                'label' => __( 'Z-Index', 'motto-core' ),
                'type' => Controls_Manager::NUMBER,
			    'dynamic' => [  'active' => true],
                'min' => -5,
                'selectors' => [
                    '{{WRAPPER}} .wgl-number' => 'z-index: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'number_separator',
		    [
			    'label' => esc_html__('Show Separator?', 'motto-core'),
			    'type' => Controls_Manager::SWITCHER,
			    'separator' => 'before',
                'default' => 'yes',
                'selectors' => [
                    '{{WRAPPER}} .number-wrapper::after' => 'display: block;',
                ],
		    ]
	    );

	    $this->add_responsive_control(
		    'number_separator_margin',
		    [
			    'label' => esc_html__('Margin Separator', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', 'em', '%', 'rem' ],
			    'condition' => [ 'number_separator!' => '' ],
			    'selectors' => [
				    '{{WRAPPER}} .number-wrapper::after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'number_separator_width',
		    [
			    'label' => esc_html__('Width Separator', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'size_units' => ['px', '%', 'custom'],
			    'range' => [
				    'px' => ['min' => 1, 'max' => 800],
				    '%' => ['min' => .1, 'max' => 100],
			    ],
                'condition' => [ 'number_separator!' => '' ],
                'selectors' => [
				    '{{WRAPPER}} .number-wrapper::after' => 'width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'number_separator_height',
		    [
			    'label' => esc_html__('Height Separator', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'size_units' => ['px', '%', 'custom'],
			    'range' => [
				    'px' => ['min' => 1, 'max' => 800],
				    '%' => ['min' => .1, 'max' => 100],
			    ],
                'condition' => [ 'number_separator!' => '' ],
			    'selectors' => [
				    '{{WRAPPER}} .number-wrapper::after' => 'height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'number_separator_color',
		    [
			    'label' => esc_html__('Separator Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'number_separator!' => '' ],
			    'default' => WGL_Globals::get_primary_color(),
			    'selectors' => [
				    '{{WRAPPER}} .number-wrapper::after' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->start_controls_tabs( 'number_colors' );
        $this->start_controls_tab(
            'number_colors_idle',
            [ 'label' => esc_html__('Idle', 'motto-core') ]
        );
        $this->add_control(
            'primary_number_color',
            [
                'label' => esc_html__('Number Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(),
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-stacked .wgl-number' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-framed .wgl-number,
                     {{WRAPPER}}.elementor-view-default .wgl-number' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_number_border',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-number' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'secondary_number_color',
            [
                'label' => esc_html__('Additional Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'view!' => 'default' ],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-framed .wgl-number' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-stacked .wgl-number' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'number_shadow',
                'selector' => '{{WRAPPER}} .wgl-number',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'number_colors_hover',
            [ 'label' => esc_html__('Hover', 'motto-core') ]
        );

        $this->add_control(
            'number_primary_color_hover',
            [
                'label' => esc_html__('Number Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-stacked:hover .wgl-number' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-framed:hover .wgl-number,
                     {{WRAPPER}}.elementor-view-default:hover .wgl-number' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'number_primary_border_hover',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}}:hover .wgl-number' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'number_secondary_color_hover',
            [
                'label' => esc_html__('Additional Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'view!' => 'default' ],
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-framed:hover .wgl-number' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-stacked:hover .wgl-number' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'number_hover_shadow',
                'selector' =>  '{{WRAPPER}}:hover .wgl-number',
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
		$this->end_controls_section();

        /**
         * STYLE -> IMAGE
         */

        $this->start_controls_section(
            'style_image',
            [
                'label' => esc_html__('Image', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['icon_type' => 'image'],
            ]
        );

        $this->add_responsive_control(
            'image_alignment',
            [
                'label' => esc_html__('Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => true,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} figure.wgl-image-box_img' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_space',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '12',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .media-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} figure.wgl-image-box_img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_size',
            [
                'label' => esc_html__('Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', '%', 'custom'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 800],
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'default' => ['size' => 100, 'unit' => '%'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-image-box_img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'image_border_radius',
		    [
			    'label' => esc_html__('Border Radius', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'custom'],
			    'selectors' => [
				    '{{WRAPPER}} .media-wrapper .wgl-image-box_img,
				     {{WRAPPER}} .media-wrapper .wgl-image-box_img img,
				     {{WRAPPER}} .media-wrapper .wgl-image-box_img::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'image_z_index',
            [
                'label' => __( 'Z-Index', 'motto-core' ),
                'type' => Controls_Manager::NUMBER,
			    'dynamic' => [  'active' => true],
                'min' => -5,
                'selectors' => [
                    '{{WRAPPER}} .wgl-image-box_img img' => 'z-index: {{VALUE}}; position: relative;',
                ],
            ]
        );

	    $this->start_controls_tabs('image_effects');

        $this->start_controls_tab(
            'Idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

	    $this->add_control(
		    'image_bg_color_idle',
		    [
			    'label' => esc_html__('Image BG Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-image-box_img' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'css_filters',
                'selector' => '{{WRAPPER}} .wgl-image-box_img img',
            ]
        );

        $this->add_control(
            'image_opacity',
            [
                'label' => esc_html__('Opacity', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0.10, 'max' => 1, 'step' => 0.01],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-image-box_img img' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name' => 'image_shadow_idle',
			    'selector' => '{{WRAPPER}} .wgl-image-box_img img',
		    ]
	    );

        $this->add_control(
            'background_hover_transition',
            [
                'label' => esc_html__('Transition Duration', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'default' => ['size' => 0.5],
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.1],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-image-box_img img' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );

	    $this->add_control(
		    'image_bg_color_hover',
		    [
			    'label' => esc_html__('Image BG Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-image-box_img' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'css_filters_hover',
                'selector' => '{{WRAPPER}} .elementor-widget-container:hover .wgl-image-box_img img',
            ]
        );

        $this->add_control(
            'image_opacity_hover',
            [
                'label' => esc_html__('Opacity', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0.10, 'max' => 1, 'step' => 0.01],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-image-box_img img' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name' => 'image_shadow_hover',
			    'selector' => '{{WRAPPER}} .elementor-widget-container:hover .wgl-image-box_img img',
		    ]
	    );

        $this->add_control(
            'hover_animation_image_scale',
            [
                'label' => esc_html__('Scale Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0.8, 'max' => 1.2, 'step' => 0.01],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .media-wrapper img' => 'transform: scale({{SIZE}});',
                ],
            ]
        );

	    $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> Bubble
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_bubble',
            [
                'label' => esc_html__('Bubble', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'icon_type' => ['font', 'number', 'image'],
                    'view' => 'bubble',
                ],
            ]
        );

        $this->add_responsive_control(
            'bubble_top_offset',
            [
                'label' => esc_html__('Top Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -200, 'max' => 200],
                    'px' => ['min' => -200, 'max' => 1000, 'step' => 1],
                ],
                'default' => ['size' => -12, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-icon .elementor-icon::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-number.elementor-icon .number::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-image-box_img::after' => 'top: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'bubble_left_offset',
            [
                'label' => esc_html__('Left Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -200, 'max' => 200],
                    'px' => ['min' => -200, 'max' => 1000, 'step' => 1],
                ],
                'default' => ['size' => -12, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-icon .elementor-icon::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-number.elementor-icon .number::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-image-box_img::after' => 'left: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'bubble_size',
            [
                'label' => esc_html__('Bubble Diameter', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', 'custom' ],
                'range' => [
                    'px' => ['max' => 700],
                ],
                'default' => ['size' => 60, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-icon .elementor-icon::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-number.elementor-icon .number::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-image-box_img::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
		    'icon_animation',
		    [
			    'label' => esc_html__('Bubble Animation', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [
                    'icon_type' => ['font', 'number', 'image'],
                    'view' => 'bubble',
                ],
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'return_value' => 'bubble',
                'prefix_class' => 'animation_',
                'default' => 'bubble'
		    ]
	    );

        $this->add_responsive_control(
            'bubble_animation_top_offset',
            [
                'label' => esc_html__('Top Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 100],
                    'px' => ['min' => -200, 'max' => 1000, 'step' => 1],
                ],
                'condition' => [
                    'icon_animation' => 'bubble',
                ],
                'default' => ['size' => -59, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-icon .elementor-icon::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-number.elementor-icon .number::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-image-box_img::after' => 'top: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'bubble_animation_left_offset',
            [
                'label' => esc_html__('Left Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 100],
                    'px' => ['min' => -200, 'max' => 1000, 'step' => 1],
                ],
                'default' => ['size' => -59, 'unit' => 'px'],
                'condition' => [
                    'icon_animation' => 'bubble',
                ],
                'selectors' => [
                    '{{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-icon .elementor-icon::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-number.elementor-icon .number::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-image-box_img::after' => 'left: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'bubble_animation_size',
            [
                'label' => esc_html__('Bubble Diameter', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', 'custom' ],
                'range' => [
                    'px' => ['max' => 700],
                ],
                'condition' => [
                    'icon_animation' => 'bubble',
                ],
                'default' => ['size' => 154, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-icon .elementor-icon::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-number.elementor-icon .number::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-image-box_img::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->start_controls_tabs(
            'tabs_bubble_styles',
            [ 'separator' => 'before' ]
        );

        $this->start_controls_tab(
            'tab_bubble_idle',
            [ 'label' => esc_html__('Idle', 'motto-core') ]
        );

        $this->add_control(
            'bubble_bg_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_secondary_color(0),
                'selectors' => [
                    '{{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-icon .elementor-icon::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-number.elementor-icon .number::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble .wgl-image-box_img::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_bubble_hover',
            [ 'label' => esc_html__('Hover', 'motto-core') ]
        );

        $this->add_control(
            'bubble_bg_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_secondary_color(0.15),
                'selectors' => [
                    '{{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-icon .elementor-icon::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-number.elementor-icon .number::after,
                     {{WRAPPER}}.elementor-widget-wgl-info-box.elementor-view-bubble:hover .wgl-image-box_img::after' => 'background-color: {{VALUE}};'
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> TITLE
         */

        $this->start_controls_section(
            'style_title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['ib_title!' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_title',
                'selector' => '{{WRAPPER}} .wgl-infobox_title',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML Tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'div' => esc_html('‹div›'),
                    'span' => esc_html('‹span›'),
                ],
                'default' => 'h3',
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '8',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox-title_wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name' => 'title_border',
			    'render_type' => 'template',
			    'dynamic' => [  'active' => true],
			    'selector' => '{{WRAPPER}} .wgl-infobox_title',
		    ]
	    );

        $this->add_control(
            'title_view',
            [
                'label' => esc_html__( 'Layout', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'inline-block' => [
                        'title' => esc_html__( 'Inline-Block', 'motto-core' ),
                        'icon' => 'eicon-ellipsis-h',
                    ],
                    'block' => [
                        'title' => esc_html__( 'Block', 'motto-core' ),
                        'icon' => 'eicon-editor-list-ul',
                    ],
                ],
                'default' => 'block',
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title' => 'display: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_width',
            [
                'label' => esc_html__('Title Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', '%', 'vw', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_z_index',
            [
                'label' => __( 'Z-Index', 'motto-core' ),
                'type' => Controls_Manager::NUMBER,
			    'dynamic' => [  'active' => true],
                'min' => -5,
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title' => 'z-index: {{VALUE}}; position: relative;',
                ],
            ]
        );

        $this->add_control(
            'title_separator',
            [
                'label' => esc_html__('Show Separator?', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'separator' => 'before',
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title::after' => 'display: inline-block;',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_separator_position',
            [
                'label' => esc_html__('Separator Position', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => true,
                'condition' => ['title_separator!' => ''],
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-align-start-h',
                    ],
                    'bottom' => [
                        'title' => esc_html__('Bottom', 'motto-core'),
                        'icon' => 'eicon-justify-end-v',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-align-end-h',
                    ],
                ],
                'selectors_dictionary' => [
                    'left' => 'position: absolute; left: 0; top: 0;',
                    'bottom' => 'position: static;',
                    'right' => 'position: absolute; right: 0; top: 0;',
                ],
                'default' => 'bottom',
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title::after' => '{{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_separator_margin',
            [
                'label' => esc_html__('Margin Separator', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'rem', 'custom' ],
                'default' => [
                    'top' => '0',
                    'right' => '-50',
                    'bottom' => '0',
                    'left' => '-50',
	                'unit'  => '%',
	                'isLinked' => false
                ],
                'condition' => ['title_separator!' => ''],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title::after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_separator_width',
            [
                'label' => esc_html__('Width Separator', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', '%', 'custom'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 800],
                    '%' => ['min' => .1, 'max' => 100],
                ],
                'condition' => ['title_separator!' => ''],
                'default' => ['size' => 200, 'unit' => '%'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title::after' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_separator_height',
            [
                'label' => esc_html__('Height Separator', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', '%', 'custom'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 800],
                    '%' => ['min' => .1, 'max' => 100],
                ],
                'condition' => ['title_separator!' => ''],
                'default' => ['size' => 1, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title::after' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->start_controls_tabs(
            'title',
            [ 'separator' => 'before' ]
        );

        $this->start_controls_tab(
            'title_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'title_color_idle',
            [
                'label' => esc_html__('Title Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_bg_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name' => 'title_shadow_idle',
			    'selector' => '{{WRAPPER}} .wgl-infobox_title',
		    ]
	    );

        $this->add_control(
            'separator_color_idle',
            [
                'label' => esc_html__('Separator Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['title_separator!' => ''],
                'default' => WGL_Globals::get_secondary_color(0.15),
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title::after' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_border_color_idle',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
	            'condition' => [
	            	'title_border_border!' => ['', 'none']
	            ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_bg_blur_idle',
            [
                'label' => esc_html__('Backdrop Filter', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 100, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title' => 'backdrop-filter: blur({{SIZE}}px); -webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'title_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'title_color_hover',
            [
                'label' => esc_html__('Title Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_bg_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_title' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
		    'title_hover_shift',
		    [
			    'label' => esc_html__('Lift up the title', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'size_units' => [ 'px', 'custom' ],
			    'selectors' => [
				    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_title' => 'transform: translateY({{SIZE}}{{UNIT}})',
			    ],
		    ]
	    );
        $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name' => 'title_shadow_hover',
			    'selector' => '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_title',
		    ]
	    );
	    $this->add_control(
		    'separator_color_hover',
		    [
			    'label' => esc_html__('Separator Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => ['title_separator!' => ''],
                'default' => WGL_Globals::get_secondary_color(),
			    'selectors' => [
				    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_title::after' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
        $this->add_control(
            'title_border_color_hover',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
	            'condition' => [
	            	'title_border_border!' => ['', 'none']
	            ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_title' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_bg_blur_hover',
            [
                'label' => esc_html__('Backdrop Filter', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 100, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_title' => 'backdrop-filter: blur({{SIZE}}px); -webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> SUBTITLE
         */

        $this->start_controls_section(
            'style_subtitle',
            [
                'label' => esc_html__('Subtitle', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['ib_subtitle!' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'selector' => '{{WRAPPER}} .wgl-infobox_subtitle',
            ]
        );

        $this->add_responsive_control(
            'subtitle_offset',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
	                'top' => '0',
	                'right' => '0',
	                'bottom' => '10',
	                'left' => '0',
	                'unit'  => 'px',
	                'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_subtitle_styles');

        $this->start_controls_tab(
            'tab_subtitle_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'subtitle_color_idle',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_subtitle_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );

        $this->add_control(
            'subtitle_color_hover',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_subtitle' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

	    /**
	     * STYLE -> BG Text
	     */

	    $this->start_controls_section(
		    'background_text',
		    [
			    'label' => esc_html__('Background Text', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['ib_bg_text!' => ''],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name' => 'bg_text_custom_fonts',
			    'selector' => '{{WRAPPER}} .wgl-infobox_bg_text',
		    ]
	    );

	    $this->add_responsive_control(
		    'bg_text_stroke_size',
		    [
			    'label' => esc_html__('Stroke Width', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'size_units' => ['px', 'em'],
			    'range' => [
				    'px' => ['min' => 0, 'max' => 2, 'step' => 0.1],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-infobox_bg_text' => '-webkit-text-stroke-width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'bg_text_margin',
		    [
			    'label' => esc_html__('Margin', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '-1',
                    'right' => '0',
                    'bottom'=> '0',
                    'left' => '-12',
                    'unit'  => '%',
                    'isLinked' => false
                ],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-infobox_bg_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'bg_text_padding',
		    [
			    'label' => esc_html__('Padding', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%', 'custom'],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-infobox_bg_text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'bg_text_radius',
		    [
			    'label' => esc_html__('Border Radius', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'custom'],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-infobox_bg_text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'bg_text_z_index',
		    [
			    'label' => __( 'Z-Index', 'motto-core' ),
			    'type' => Controls_Manager::NUMBER,
			    'dynamic' => [  'active' => true],
			    'min' => -5,
                'default' => -1,
			    'selectors' => [
				    '{{WRAPPER}} .wgl-infobox_bg_text' => 'z-index: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->start_controls_tabs('tabs_bg_text_styles');

	    $this->start_controls_tab(
		    'tab_bg_text',
		    ['label' => esc_html__('Idle', 'motto-core')]
	    );

	    $this->add_control(
		    'bg_text_color_idle',
		    [
			    'label' => esc_html__('Text Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'default' => '#D3736E',
			    'selectors' => [
				    '{{WRAPPER}} .wgl-infobox_bg_text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'bg_text_bg_color_idle',
		    [
			    'label' => esc_html__('Background Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-infobox_bg_text' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'bg_text_stroke_idle',
		    [
			    'label' => esc_html__('Stroke Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => ['bg_text_stroke_size!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-infobox_bg_text' => '-webkit-text-stroke-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->end_controls_tab();

	    $this->start_controls_tab(
		    'tab_bg_text_hover',
		    ['label' => esc_html__('Hover', 'motto-core')]
	    );

	    $this->add_control(
		    'bg_text_color_hover',
		    [
			    'label' => esc_html__('Text Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'selectors' => [
				    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_bg_text' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'bg_text_bg_color_hover',
		    [
			    'label' => esc_html__('Background Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'selectors' => [
				    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_bg_text' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'bg_text_stroke_hover',
		    [
			    'label' => esc_html__('Stroke Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => ['bg_text_stroke_size!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_bg_text' => '-webkit-text-stroke-color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->end_controls_tab();
	    $this->end_controls_tabs();
	    $this->end_controls_section();

        /**
         * STYLE -> CONTENT
         */

        $this->start_controls_section(
            'style_content',
            [
                'label' => esc_html__('Content', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['ib_content!' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_content',
                'selector' => '{{WRAPPER}} .wgl-infobox_content',
            ]
        );

        $this->add_responsive_control(
            'content_offset',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'custom_content_mask_color',
                'label' => esc_html__('Background', 'motto-core'),
                'types' => ['classic', 'gradient'],
                'condition' => ['custom_bg' => 'custom'],
                'selector' => '{{WRAPPER}} .wgl-infobox_content',
            ]
        );

        $this->start_controls_tabs('content_color_tab');

        $this->start_controls_tab(
            'custom_content_color_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_content_color_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );

        $this->add_control(
            'content_color_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_content' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> BUTTON
         */

        $this->start_controls_section(
            'style_button',
            [
                'label' => esc_html__('Button', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['add_read_more!' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_button',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'text_transform' => ['default' => 'uppercase'],
                ],
                'selector' => '{{WRAPPER}} .wgl-infobox_button .button__text',
            ]
        );
        $this->add_responsive_control(
            'button_decoration_line_size',
            [
                'label' => esc_html__('Decoration Line Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'custom_fonts_button_text_decoration' => ['line-through', 'overline', 'underline'] ],
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 20, 'step' => 1],
                    'em' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button .button__text' => 'text-decoration-thickness: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_underline_offset',
            [
                'label' => esc_html__('Underline Offset Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'custom_fonts_button_text_decoration' => 'underline' ],
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => ['min' => -20, 'max' => 20, 'step' => 1],
                    'em' => ['min' => -1, 'max' => 1, 'step' => 0.1],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button .button__text' => 'text-underline-offset: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '11',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox-button_wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox-button_wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_inner_padding',
            [
                'label' => esc_html__('Inner Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'button_radius',
		    [
			    'label' => esc_html__('Border Radius', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'custom'],
			    'condition' => ['read_more_icon_fontawesome[value]!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-infobox_button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name' => 'button_border',
			    'render_type' => 'template',
			    'dynamic' => [  'active' => true],
			    'fields_options' => [
				    'color' => ['type' => Controls_Manager::HIDDEN],
			    ],
                'condition' => ['read_more_icon_fontawesome[value]!' => ''],
			    'selector' => '{{WRAPPER}} .wgl-infobox_button',
		    ]
	    );

        $this->add_control(
            'read_more_button_width',
            [
                'label' => esc_html__( 'Button Min-Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem', '%', 'custom'],
                'range' => [
                    'px' => ['max' => 500],
                    '%' => ['max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'min-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_alignment',
            [
                'label' => esc_html__('Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => true,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__('Justify', 'motto-core'),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'condition' => [ 'add_read_more!' => '' ],
                'prefix_class' => 'button_',
            ]
        );

        $this->add_control(
            'read_more_button_width_alignment',
            [
                'label' => esc_html__('Additional Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => true,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__('Justify', 'motto-core'),
                        'icon' => 'eicon-text-align-justify',
                    ],
                    'space-between' => [
                        'title' => esc_html__( 'Space Between', 'motto-core' ),
                        'icon' => 'eicon-justify-space-between-h',
                    ],
                ],
                'condition' => [
                    'add_read_more!' => '',
                    'read_more_button_width!' => '',
                ],
                'default' => 'space-between',
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_position',
            [
                'label' => esc_html__('Button Position', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'relative' => esc_html__('Default', 'motto-core'),
                    'absolute' => esc_html__('Absolute', 'motto-core'),
                ],
                'default' => 'relative',
                'render_type' => 'template',
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox-button_wrapper' => 'position: {{VALUE}};',
                ],
            ]
        );
		$this->add_responsive_control(
			'button_position_offset_x',
			[
				'label' => esc_html__( 'Offset X', 'motto-core' ),
				'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
                'condition' => [
                    'button_position!' => 'relative',
                ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .wgl-infobox-button_wrapper' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_responsive_control(
			'button_position_offset_y',
			[
				'label' => esc_html__( 'Offset Y', 'motto-core' ),
				'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
                'condition' => [
                    'button_position!' => 'relative',
                ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .wgl-infobox-button_wrapper' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->start_controls_tabs( 'tabs_button' );
        $this->start_controls_tab(
            'tab_button_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'button_color_idle',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .wgl-infobox_button::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_decoration_color_idle',
            [
                'label' => esc_html__('Decoration Line Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'custom_fonts_button_text_decoration' => ['line-through', 'overline', 'underline'] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button .button__text' => 'text-decoration-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
		    'button_icon_color_idle',
		    [
			    'label' => esc_html__('Icon Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['read_more_icon_fontawesome[value]!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .read-more-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
			    ],
		    ]
	    );
        $this->add_control(
		    'button_icon_bg_color_idle',
		    [
			    'label' => esc_html__('Icon BG Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => [ 'read_more_icon_fontawesome!' => [
				    'value' => '',
				    'library' => ''
			    ]],
			    'selectors' => [
				    '{{WRAPPER}} .read-more-icon,
				     {{WRAPPER}} .button-read-more .wgl-icon::before' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
        $this->add_control(
		    'button_icon_stroke_idle',
		    [
			    'label' => esc_html__('Stroke Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => [ 'read_more_icon_fontawesome[library]' => 'svg' ],
			    'selectors' => [
                    '{{WRAPPER}} .read-more-icon' => 'stroke: {{VALUE}}'
			    ],
		    ]
	    );
        $this->add_control(
            'button_border_color_idle',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
	            'condition' => [
	            	'button_border_border!' => ['', 'none'],
		            'read_more_icon_fontawesome!' => [
			            'value' => '',
			            'library' => ''
		            ]
	            ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_idle',
                'selector' => '{{WRAPPER}} .wgl-infobox_button',
            ]
        );
        $this->add_control(
            'button_bg_backdrop_filter_idle',
            [
                'label' => esc_html__('Backdrop Filter', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 100, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'backdrop-filter: blur({{SIZE}}px); -webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->add_control(
            'button_icon_rotation_idle',
            [
                'label' => esc_html__( 'Icon Rotate', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'deg' => [ 'min' => -360, 'max' => 360 ],
                    'turn' => ['min' => -1, 'max' => 1, 'step' => 0.1],
                ],
                'condition' => [ 'read_more_icon_type' => 'font' ],
                'default' => [ 'size' => -45, 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button .read-more-icon' => '--icon-rotate: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
        'tab_button_item_hover',
            ['label' => esc_html__('Item Hover', 'motto-core')]
        );
        $this->add_control(
            'button_color_item_hover',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_button' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_item_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_button,
                     {{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_button::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'button_decoration_color_item_hover',
            [
                'label' => esc_html__('Decoration Line Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'custom_fonts_button_text_decoration' => ['line-through', 'overline', 'underline'] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_button .button__text' => 'text-decoration-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_color_item_hover',
            [
                'label' => esc_html__('Icon Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'read_more_icon_fontawesome!' => [
                    'value' => '',
                    'library' => ''
                ]],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .read-more-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_bg_color_item_hover',
            [
                'label' => esc_html__('Icon BG Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'read_more_icon_fontawesome!' => [
                    'value' => '',
                    'library' => ''
                ]],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .read-more-icon,
				     {{WRAPPER}} .elementor-widget-container:hover .button-read-more .wgl-icon::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_stroke_item_hover',
            [
                'label' => esc_html__('Icon Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'read_more_icon_fontawesome[library]' => 'svg' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .read-more-icon' => 'stroke: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_border_color_item_hover',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [
                    'button_border_border!' => ['', 'none'],
                    'read_more_icon_fontawesome[value]!' => ''
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_button' => 'border-color: {{VALUE}}'
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_item_hover',
                'selector' => '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_button',
            ]
        );
        $this->add_control(
            'button_bg_backdrop_filter_item_hover',
            [
                'label' => esc_html__('Backdrop Filter', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 100, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_button' => 'backdrop-filter: blur({{SIZE}}px); -webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->add_control(
            'button_icon_rotation_item_hover',
            [
                'label' => esc_html__( 'Icon Rotate', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'deg' => [ 'min' => -360, 'max' => 360 ],
                    'turn' => ['min' => -1, 'max' => 1, 'step' => 0.1],
                ],
                'condition' => [ 'read_more_icon_type' => 'font' ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_button .read-more-icon' => '--icon-rotate: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_button_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'button_color_hover',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover,
                     {{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'button_decoration_color_hover',
            [
                'label' => esc_html__('Decoration Line Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'custom_fonts_button_text_decoration' => ['line-through', 'overline', 'underline'] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover span' => 'text-decoration-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_color_hover',
            [
                'label' => esc_html__('Icon Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'read_more_icon_fontawesome!' => [
                    'value' => '',
                    'library' => ''
                ]],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover .read-more-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_bg_color_hover',
            [
                'label' => esc_html__('Icon BG Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'read_more_icon_fontawesome!' => [
                    'value' => '',
                    'library' => ''
                ]],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover .read-more-icon,
				     {{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover .wgl-icon::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_stroke_hover',
            [
                'label' => esc_html__('Icon Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'read_more_icon_fontawesome[library]' => 'svg' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover .read-more-icon' => 'stroke: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_border_color_hover',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [
                    'button_border_border!' => ['', 'none'],
                    'read_more_icon_fontawesome[value]!' => ''
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover' => 'border-color: {{VALUE}}'
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_hover',
                'selector' => '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover',
            ]
        );
        $this->add_control(
            'button_bg_backdrop_filter_hover',
            [
                'label' => esc_html__('Backdrop Filter', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 100, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover' => 'backdrop-filter: blur({{SIZE}}px); -webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->add_control(
            'button_icon_rotation_hover',
            [
                'label' => esc_html__( 'Icon Rotate', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'deg' => [ 'min' => -360, 'max' => 360 ],
                    'turn' => ['min' => -1, 'max' => 1, 'step' => 0.1],
                ],
                'condition' => [ 'read_more_icon_type' => 'font' ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:hover .read-more-icon' => '--icon-rotate: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_button_active',
            ['label' => esc_html__('Active', 'motto-core')]
        );
        $this->add_control(
            'button_color_active',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_bg_active',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active,
                     {{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'button_decoration_color_active',
            [
                'label' => esc_html__('Decoration Line Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'custom_fonts_button_text_decoration' => ['line-through', 'overline', 'underline'] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active span' => 'text-decoration-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_color_active',
            [
                'label' => esc_html__('Icon Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'read_more_icon_fontawesome!' => [
                    'value' => '',
                    'library' => ''
                ]],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active .read-more-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_bg_color_active',
            [
                'label' => esc_html__('Icon BG Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'read_more_icon_fontawesome!' => [
                    'value' => '',
                    'library' => ''
                ]],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active .read-more-icon,
				     {{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active .wgl-icon::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_icon_stroke_active',
            [
                'label' => esc_html__('Icon Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'read_more_icon_fontawesome[library]' => 'svg' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active .read-more-icon' => 'stroke: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_border_color_active',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [
                    'button_border_border!' => ['', 'none'],
                    'read_more_icon_fontawesome[value]!' => ''
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active' => 'border-color: {{VALUE}}'
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_active',
                'selector' => '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active',
            ]
        );
        $this->add_control(
            'button_bg_backdrop_filter_active',
            [
                'label' => esc_html__('Backdrop Filter', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 100, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active' => 'backdrop-filter: blur({{SIZE}}px); -webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->add_control(
            'button_icon_rotation_active',
            [
                'label' => esc_html__( 'Icon Rotate', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'deg' => [ 'min' => -360, 'max' => 360 ],
                    'turn' => ['min' => -1, 'max' => 1, 'step' => 0.1],
                ],
                'condition' => [ 'read_more_icon_type' => 'font' ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-infobox_button:active .read-more-icon' => '--icon-rotate: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> BACKGROUND
         */

        $this->start_controls_section(
            'style_background',
            [
                'label' => esc_html__('Background', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'item_overflow',
            [
                'label' => esc_html__('Module Overflow', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__('Theme Default', 'motto-core'),
                    'overflow: visible;' => esc_html__('Visible', 'motto-core'),
                    'overflow: hidden;' => esc_html__('Hidden', 'motto-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container' => '{{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
		    'container_padding',
		    [
			    'label' => esc_html__('Padding', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'custom'],
			    'selectors' => [
				    '{{WRAPPER}} .elementor-widget-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_border_idle',
                'fields_options' => [
                    'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                    'color' => [ 'type' => Controls_Manager::HIDDEN ],
                ],
                'selector' => '{{WRAPPER}} .wgl-infobox_bg_wrapper',
            ]
        );
	    $this->start_controls_tabs('tabs_background');
        $this->start_controls_tab(
            'tab_bg_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_idle',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .wgl-infobox_bg_wrapper',
            ]
        );
        $this->add_control(
            'item_border_color_idle',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'item_border_idle_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_bg_wrapper' => 'border-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'container_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name' => 'container_shadow_idle',
			    'selector' => '{{WRAPPER}} .elementor-widget-container',

		    ]
	    );
        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'container_blur_idle',
                'selector' => '{{WRAPPER}} .wgl-infobox_bg_wrapper',
            ]
        );
	    $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_bg_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_hover',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_bg_wrapper',
            ]
        );
        $this->add_control(
            'item_border_color_hover',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'item_border_idle_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_bg_wrapper' => 'border-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'container_radius_hover',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
	    $this->add_group_control(
		    Group_Control_Box_Shadow::get_type(),
		    [
			    'name' => 'container_shadow_hover',
			    'selector' => '{{WRAPPER}} .elementor-widget-container:hover',
		    ]
	    );
        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'container_blur_hover',
                'selector' => '{{WRAPPER}} .elementor-widget-container:hover .wgl-infobox_bg_wrapper',
            ]
        );
        $this->add_control(
            'item_bg_transition',
            [
                'label' => esc_html__('Transition Delay', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'separator' => 'before',
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.1],
                ],
                'default' => ['size' => 0.4],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container,
                     {{WRAPPER}} .wgl-infobox_bg_wrapper' => 'transition: {{SIZE}}s',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * CONTENT -> HOVER ANIMATION
         */

        $this->start_controls_section(
            'content_animation',
            [
                'label' => esc_html__('Hover Animation', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_control(
            'hover_lifting',
            [
                'label' => esc_html__('Lift Up the Item', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [
                    'hover_toggling' => '',
                    'hover_toggling_icon' => ''
                ],
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'return_value' => 'lifting',
                'prefix_class' => 'animation_'
            ]
        );

        $this->add_control(
            'hover_toggling_icon',
            [
                'label' => esc_html__('Toggle Icon Visibility', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [
                    'background_animation' => '',
                    'hover_lifting' => '',
                    'hover_toggling' => '',
                    'layout' => ['left', 'right'],
                    'icon_type!' => '',
                ],
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'return_value' => 'toggling_icon',
                'prefix_class' => 'animation_'
            ]
        );

        $this->add_responsive_control(
            'hover_toggling_icon_offset',
            [
                'label' => esc_html__('Animation Distance', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [
                    'background_animation' => '',
                    'hover_lifting' => '',
                    'hover_toggling' => '',
                    'hover_toggling_icon!' => '',
                    'layout' => ['left', 'right'],
                    'icon_type!' => '',
                ],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 10, 'max' => 100],
                ],
                'default' => ['size' => 40],
                'selectors' => [
                    '{{WRAPPER}}.animation_toggling_icon .content_wrapper' => 'padding-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.animation_toggling_icon .elementor-widget-container:hover .content_wrapper' => 'padding-left: {{SIZE}}{{UNIT}}; margin-right: -{{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.animation_toggling_icon .media-wrapper' => 'transform: translateX(-{{SIZE}}{{UNIT}}) scale(0.5);',
                ],
            ]
        );

        $this->add_control(
            'hover_toggling',
            [
                'label' => esc_html__('Toggle Icon/Content Visibility', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [
                    'hover_lifting' => '',
                    'hover_toggling_icon' => '',
                    'layout!' => ['left', 'right'],
                    'icon_type!' => ''
                ],
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'return_value' => 'toggling',
                'prefix_class' => 'animation_',
            ]
        );

        $this->add_responsive_control(
            'hover_toggling_offset',
            [
                'label' => esc_html__('Animation Distance', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [
                    'hover_toggling!' => '',
                    'layout!' => ['left', 'right'],
                    'icon_type!' => '',
                ],
                'range' => [
                    'px' => ['min' => 30, 'max' => 100],
                ],
                'default' => ['size' => 40],
                'selectors' => [
                    '{{WRAPPER}}.animation_toggling .wgl-infobox_wrapper' => 'transform: translateY({{SIZE}}{{UNIT}});',
                    '{{WRAPPER}}.animation_toggling .elementor-widget-container:hover .wgl-infobox_wrapper' => 'transform: translateY(-{{SIZE}}{{UNIT}});',
                ],
            ]
        );
        $this->add_responsive_control(
            'hover_toggling_transition',
            [
                'label' => esc_html__('Transition Duration', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [
                    'hover_toggling!' => '',
                    'layout!' => ['left', 'right'],
                    'icon_type!' => '',
                ],
                'range' => [
                    'px' => ['min' => 0.1, 'max' => 2, 'step' => 0.1],
                ],
                'default' => ['size' => 0.6],
                'selectors' => [
                    '{{WRAPPER}}.animation_toggling .wgl-infobox_wrapper,
                     {{WRAPPER}}.animation_toggling .media-wrapper,
                     {{WRAPPER}}.animation_toggling .wgl-infobox-button_wrapper' => 'transition-duration: {{SIZE}}s;',
                ],
            ]
        );

        $this->add_control(
            'background_animation',
            [
                'label' => esc_html__('Background Animation', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__('None', 'motto-core'),
                    'borders' => esc_html__('Borders', 'motto-core'),
                    'gradient' => esc_html__('Gradient', 'motto-core'),
                ],
                'condition' => ['hover_toggling_icon' => ''],
                'prefix_class' => 'bg_animation-',
            ]
        );

        $this->add_control(
            'container_animation_color',
            [
                'label' => esc_html__('Border Color for Animation', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => ['background_animation' => 'borders'],
                'default' => WGL_Globals::get_primary_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before, {{WRAPPER}} .wgl-infobox::after' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'overlay_width',
            [
                'label' => esc_html__('Wrapper Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'background_animation' => 'gradient' ],
                'size_units' => ['px', '%', 'vw', 'vh', 'custom'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 2560],
                    '%' => ['min' => 0, 'max' => 200],
                    'vw' => ['min' => 0, 'max' => 100],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'default' => [ 'size' => 100, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'overlay_height',
            [
                'label' => esc_html__('Wrapper Height', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'background_animation' => 'gradient' ],
                'size_units' => ['px', '%', 'vw', 'vh', 'custom'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 2560],
                    '%' => ['min' => 0, 'max' => 200],
                    'vw' => ['min' => 0, 'max' => 100],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'default' => [ 'size' => 100, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'overlay_color_1',
            [
                'label' => esc_html__('Primary Gradient Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'background_animation' => 'gradient' ],
                'default' => '#1C5540',
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before' => '--overlay-color-1: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'overlay_color_2',
            [
                'label' => esc_html__('Secondary Gradient Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'background_animation' => 'gradient' ],
                'default' => WGL_Globals::get_secondary_color(0),
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before' => '--overlay-color-2: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'overlay_location_1',
            [
                'label' => esc_html__('First Color Location', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ '%', 'px' ],
                'default' => [ 'unit' => '%', 'size' => 0 ],
                'render_type' => 'ui',
                'condition' => [ 'background_animation' => 'gradient' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before' => '--overlay-location-1: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'overlay_location_2',
            [
                'label' => esc_html__('Second Color Location', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ '%', 'px' ],
                'default' => [ 'unit' => '%', 'size' => 100 ],
                'render_type' => 'ui',
                'condition' => [ 'background_animation' => 'gradient' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before' => '--overlay-location-2: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'overlay_gradient_type',
            [
                'label' => esc_html__('Type', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'linear' => esc_html__( 'Linear', 'motto-core' ),
                    'radial' => esc_html__( 'Radial', 'motto-core' ),
                ],
                'render_type' => 'ui',
                'condition' => [ 'background_animation' => 'gradient' ],
                'default' => 'linear',
            ]
        );

        $this->add_responsive_control(
            'overlay_gradient_angle',
            [
                'label' => esc_html__('Angle', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'deg' ],
                'range' => [
                    'deg' => [ 'step' => 10 ],
                ],
                'condition' => [
                    'background_animation' => 'gradient',
                    'overlay_gradient_type' => 'linear',
                ],
                'default' => [ 'unit' => 'deg', 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before' => 'background-color: transparent; background-image: linear-gradient({{SIZE}}{{UNIT}}, var(--overlay-color-1) var(--overlay-location-1), var(--overlay-color-2) var(--overlay-location-2));',
                ],
            ]
        );
        $this->add_responsive_control(
            'overlay_gradient_position',
            [
                'label' => esc_html__('Position', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'center center' => esc_html__( 'Center Center', 'motto-core' ),
                    'center left' => esc_html__( 'Center Left', 'motto-core' ),
                    'center right' => esc_html__( 'Center Right', 'motto-core' ),
                    'top center' => esc_html__( 'Top Center', 'motto-core' ),
                    'top left' => esc_html__( 'Top Left', 'motto-core' ),
                    'top right' => esc_html__( 'Top Right', 'motto-core' ),
                    'bottom center' => esc_html__( 'Bottom Center', 'motto-core' ),
                    'bottom left' => esc_html__( 'Bottom Left', 'motto-core' ),
                    'bottom right' => esc_html__( 'Bottom Right', 'motto-core' ),
                    'var(--h-pos) var(--v-pos)' => esc_html__( 'Custom', 'motto-core' ),
                ],
                'default' => 'center center',
                'condition' => [
                    'background_animation' => 'gradient',
                    'overlay_gradient_type' => 'radial',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before' => 'background-color: transparent; background-image: radial-gradient(circle at {{VALUE}}, var(--overlay-color-1) var(--overlay-location-1), var(--overlay-color-2) var(--overlay-location-2));',
                ],
            ]
        );
        $this->add_responsive_control(
            'overlay_gradient_h_position',
            [
                'label' => esc_html__('Horizontal Position', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'vw', 'custom'],
                'range' => [
                    'px' => [ 'min' => -2560, 'max' => 2560 ],
                    '%' => [ 'min' => -100, 'max' => 200 ],
                    'vw' => [ 'min' => -100, 'max' => 100 ],
                ],
                'condition' => [
                    'background_animation' => 'gradient',
                    'overlay_gradient_type' => 'radial',
                    'overlay_gradient_position' => 'var(--h-pos) var(--v-pos)',
                ],
                'default' => [ 'size' => 50, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before' => '--h-pos: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'overlay_gradient_v_position',
            [
                'label' => esc_html__('Vertical Position', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'vw', 'custom'],
                'range' => [
                    'px' => [ 'min' => -2560, 'max' => 2560 ],
                    '%' => [ 'min' => -100, 'max' => 200 ],
                    'vw' => [ 'min' => -100, 'max' => 100 ],
                ],
                'condition' => [
                    'background_animation' => 'gradient',
                    'overlay_gradient_type' => 'radial',
                    'overlay_gradient_position' => 'var(--h-pos) var(--v-pos)',
                ],
                'default' => [ 'size' => 100, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox::before' => '--v-pos: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        /** STYLE -> BUTTON ANIMATION */

        $this->start_controls_section(
            'style_button_animation',
            [
                'label' => esc_html__( 'Button Animation', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'button_type' => 'wgl-button' ],
            ]
        );

        $this->add_control(
            'animation_style',
            [
                'label' => esc_html__('Animation Style', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'render_type' => 'template',
                'options' => [
                    '' => esc_html__('None', 'motto-core'),
                    'highlight_animation' => esc_html__('Highlight Animation', 'motto-core'),
                    'clip_animation' => esc_html__('Clipping Animation', 'motto-core'),
                    'bg_animation' => esc_html__('Background Animation ', 'motto-core'),
                    'border_animation' => esc_html__('Border Animation', 'motto-core'),
                    'magnetic' => esc_html__('Magnetic', 'motto-core'),
                    'icon_size_animation' => esc_html__('Icon Size Animation', 'motto-core'),
                    'icon_visibility' => esc_html__('Icon Visibility', 'motto-core'),
                ],
                'prefix_class' => 'has-',
                'default' => '',
            ]
        );

        /** Highlight Animation */
        $this->add_control(
            'stroke_highlight_color_normal',
            [
                'label' => esc_html__( 'Stroke Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(),
                'condition' => [ 'animation_style' => 'highlight_animation' ],
                'selectors' => [
                    '{{WRAPPER}} .highlight_svg path' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'stroke_highlight_width_normal',
            [
                'label' => esc_html__( 'Stroke Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'vw', 'custom'],
                'condition' => [ 'animation_style' => 'highlight_animation' ],
                'range' => [
                    'px' => [ 'min' => 0.1, 'max' => 10 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .highlight_svg path' => 'stroke-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        /** Clipping Animation */
        $this->add_responsive_control(
            'button_clip_border',
            [
                'label' => esc_html__( 'Border Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 50 ] ],
                'condition' => [ 'animation_style' => 'clip_animation' ],
                'default' => [ 'size' => 2 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button' => '--border-size:{{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_clip_size',
            [
                'label' => esc_html__( 'Clipping Size', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
                'condition' => [ 'animation_style' => 'clip_animation' ],
                'default' => [ 'size' => 14 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button' => '--corner-size:{{SIZE}}{{UNIT}};',
                ],
            ]
        );

        /** Background Animation */
        $this->start_controls_tabs( 'button_animation', [
            'condition' => [ 'animation_style' => 'bg_animation' ],
        ] );
        $this->start_controls_tab(
            'button_animation_idle',
            [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
        );
        $this->add_responsive_control(
            'button_bg_top_offset_idle',
            [
                'label' => esc_html__( 'Background Top Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button::after' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_bg_left_offset_idle',
            [
                'label' => esc_html__( 'Background Left Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button::after' => 'left:{{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_bg_size',
            [
                'label' => esc_html__('Background Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 200 ],
                    '%' => [ 'min' => 0, 'max' => 100 ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button::after' => '--bg-size: {{SIZE}}{{UNIT}};',
                ]
            ]
        );

        $this->add_control(
            'button_bg_border_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                    'unit' => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_animation_item_hover',
            [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
        );
        $this->add_responsive_control(
            'button_bg_top_offset_item_hover',
            [
                'label' => esc_html__( 'Background Top Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover wgl-button::after' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_bg_left_offset_item_hover',
            [
                'label' => esc_html__( 'Background Left Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-button::after' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_bg_size_item_hover',
            [
                'label' => esc_html__('Background Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'custom' ],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'render_type' => 'template',
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 2000 ],
                    '%' => [ 'min' => 0, 'max' => 100 ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'default' => [ 'size' => 100, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-button::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_bg_border_radius_item_hover',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '32',
                    'right' => '32',
                    'bottom' => '32',
                    'left' => '32',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-button::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_animation_hover',
            [ 'label' => esc_html__( 'Hover', 'motto-core' ) ]
        );
        $this->add_responsive_control(
            'button_bg_top_offset_hover',
            [
                'label' => esc_html__( 'Background Top Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:hover::after,
                     {{WRAPPER}} .elementor-widget-container .wgl-button:focus::after' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_bg_left_offset_hover',
            [
                'label' => esc_html__( 'Background Left Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:hover::after,
                     {{WRAPPER}} .elementor-widget-container .wgl-button:focus::after' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_bg_size_hover',
            [
                'label' => esc_html__('Background Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'custom' ],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'render_type' => 'template',
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 2000 ],
                    '%' => [ 'min' => 0, 'max' => 100 ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'default' => [ 'size' => 100, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:hover::after,
                     {{WRAPPER}} .elementor-widget-container .wgl-button:focus::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_bg_border_radius_hover',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '32',
                    'right' => '32',
                    'bottom' => '32',
                    'left' => '32',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:hover::after,
                     {{WRAPPER}} .elementor-widget-container .wgl-button:focus::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_animation_active',
            [ 'label' => esc_html__( 'Active', 'motto-core' ) ]
        );
        $this->add_responsive_control(
            'button_bg_top_offset_active',
            [
                'label' => esc_html__( 'Background Top Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:active::after' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_bg_left_offset_active',
            [
                'label' => esc_html__( 'Background Left Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => -200, 'max' => 200 ],
                    '%' => ['min' => -100,'max' => 100],
                ],
                'default' => [ 'size' => 0 ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:active::after' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_bg_size_active',
            [
                'label' => esc_html__('Background Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'custom' ],
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 2000 ],
                    '%' => [ 'min' => 0, 'max' => 100 ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'default' => [ 'size' => 100, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:active::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'render_type' => 'template',
            ]
        );

        $this->add_control(
            'button_bg_border_radius_active',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [ 'animation_style' => 'bg_animation' ],
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '32',
                    'right' => '32',
                    'bottom' => '32',
                    'left' => '32',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:active::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        /** Border Animation */
        $this->add_control(
            'button_border_animation_revers',
            [
                'label' => esc_html__( 'Revers This Animation', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'revers',
                'prefix_class' => '',
                'condition' => [ 'animation_style' => 'border_animation' ],
            ]
        );

        $this->add_control(
            'button_border_animation_color',
            [
                'label' => esc_html__( 'Animation Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'border_animation' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button' => '--ab-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_border_animation_offset',
            [
                'label' => esc_html__('Animation Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 20, 'step' => 1],
                ],
                'condition' => [ 'animation_style' => 'border_animation' ],
                'default' => ['size' => 6],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button' => '--ab-offset: {{SIZE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_border_animation_width',
            [
                'label' => esc_html__('Animation Border Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 10, 'step' => 1],
                ],
                'condition' => [ 'animation_style' => 'border_animation' ],
                'default' => ['size' => 1],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button' => '--ab-width: {{SIZE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_border_animation_extend',
            [
                'label' => esc_html__('Mow Much to Extend the Border', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 1, 'max' => 50, 'step' => 1],
                ],
                'condition' => [ 'animation_style' => 'border_animation' ],
                'default' => ['size' => 4],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button' => '--ab-extend: {{SIZE}};',
                ],
            ]
        );

        /** Magnetic Threshold */

        $this->add_control(
            'button_magnetic_threshold',
            [
                'label' => esc_html__('Magnetic Threshold', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'render_type' => 'template',
                'style_transfer' => true,
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 10, 'max' => 1920, 'step' => 1],
                ],
                'condition' => [ 'animation_style' => 'magnetic' ],
                'default' => ['size' => 500],
            ]
        );

        $this->add_control(
            'button_magnetic_strong',
            [
                'label' => esc_html__('Magnetic Strong', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'render_type' => 'template',
                'style_transfer' => true,
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 0.05, 'max' => 1, 'step' => 0.05],
                ],
                'condition' => [ 'animation_style' => 'magnetic' ],
                'default' => ['size' => 0.2],
            ]
        );

        /** Icon Size Animation */
        $this->start_controls_tabs(
            'icon_size_animation_tabs',
            [
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
            ]
        );
        $this->start_controls_tab(
            'icon_size_animation_tab_idle',
            [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_size_animation_idle',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_animation_idle',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'default' => ['size' => 8, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'icon_size_animation_tab_item_hover',
            [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_size_animation_item_hover',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-button .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_animation_item_hover',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .wgl-button .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'icon_size_animation_tab_hover',
            [ 'label' => esc_html__( 'Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_size_animation_hover',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:hover .wgl-icon,
                     {{WRAPPER}} .elementor-widget-container .wgl-button:focus .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_animation_hover',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'default' => ['size' => 12, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:hover .wgl-icon,
                     {{WRAPPER}} .elementor-widget-container .wgl-button:focus .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'icon_size_animation_tab_active',
            [ 'label' => esc_html__( 'Active', 'motto-core' ) ]
        );
        $this->add_control(
            'icon_size_animation_active',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:active .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_bg_animation_active',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'animation_style' => 'icon_size_animation' ],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'default' => ['size' => 12, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .wgl-button:active .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        /** Icon Visibility */
        $this->add_control(
            'icon_visibility',
                [
                'label' => esc_html__( 'Icon Visibility', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [ 'animation_style' => 'icon_visibility' ],
                'options' => [
                    'default' => esc_html__( 'Default', 'motto-core' ),
                    'revert' => esc_html__( 'Revert', 'motto-core' ),
                ],
                'default' => 'default',
                'prefix_class' => 'icon-visibility-'
            ]
        );

        $this->end_controls_section();


        /** STYLE -> READ MORE ANIMATION */

        $this->start_controls_section(
            'read_more_animation',
            [
                'label' => esc_html__( 'Read More Animation', 'motto-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'button_type' => 'button-read-more' ],
            ]
        );
        $this->add_control(
            'read_more_animation_style',
            [
                'label' => esc_html__('Animation Style', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'render_type' => 'template',
                'options' => [
                    '' => esc_html__('None', 'motto-core'),
                    'icon_size_animation' => esc_html__('Icon Size Animation', 'motto-core'),
                ],
                'prefix_class' => 'rm_has-',
                'default' => '',
            ]
        );
        $this->start_controls_tabs( 'read_more_icon_size_animation_tabs', [
            'condition' => [ 'read_more_animation_style' => 'icon_size_animation' ],
        ] );
        $this->start_controls_tab(
            'read_more_icon_size_animation_tab_idle',
            [ 'label' => esc_html__( 'Idle', 'motto-core' ) ]
        );
        $this->add_control(
            'read_more_icon_size_animation_idle',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'default' => ['size' => 0, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .button-read-more .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'read_more_icon_bg_animation_idle',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'default' => ['size' => 8, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .button-read-more .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'read_more_icon_size_animation_tab_item_hover',
            [ 'label' => esc_html__( 'Item Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'read_more_icon_size_animation_item_hover',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .button-read-more .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'read_more_icon_bg_animation_item_hover',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .button-read-more .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'read_more_icon_size_animation_tab_hover',
            [ 'label' => esc_html__( 'Hover', 'motto-core' ) ]
        );
        $this->add_control(
            'read_more_icon_size_animation_hover',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'default' => ['size' => 0, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .button-read-more:hover .wgl-icon,
                     {{WRAPPER}} .elementor-widget-container .button-read-more:focus .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'read_more_icon_bg_animation_hover',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'default' => ['size' => 12, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .button-read-more:hover .wgl-icon,
                     {{WRAPPER}} .elementor-widget-container .button-read-more:focus .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'read_more_icon_size_animation_tab_active',
            [ 'label' => esc_html__( 'Active', 'motto-core' ) ]
        );
        $this->add_control(
            'read_more_icon_size_animation_active',
            [
                'label' => esc_html__( 'Icon Scale', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 5, 'step' => 0.01 ] ],
                'default' => ['size' => 0, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .button-read-more:active .wgl-icon' => '--icon-scale: {{SIZE}};',
                ],
            ]
        );
        $this->add_control(
            'read_more_icon_bg_animation_active',
            [
                'label' => esc_html__( 'Background Size(px)', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ] ],
                'default' => ['size' => 12, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container .button-read-more:active .wgl-icon' => '--icon-bg-size: {{SIZE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function render()
    {
        $atts = $this->get_settings_for_display();

        (new WGLInfoBoxes())->render($this, $atts);
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WGL_Extensions\Includes\WGL_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
