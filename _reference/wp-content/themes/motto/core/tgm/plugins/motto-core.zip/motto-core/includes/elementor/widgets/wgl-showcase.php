<?php
/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/widgets/wgl-showcase.php`.
 */
namespace WGL_Extensions\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{
    Plugin,
    Widget_Base,
    Controls_Manager,
    Icons_Manager,
    Utils,
    Repeater,
    Group_Control_Border,
    Group_Control_Box_Shadow,
    Group_Control_Typography,
    Group_Control_Background
};

use WGL_Extensions\{
    Includes\WGL_Elementor_Helper,
    WGL_Framework_Global_Variables as WGL_Globals,
    Includes\WGL_Cursor
};

class WGL_Showcase extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-showcase';
    }

    public function get_title()
    {
        return esc_html__('WGL Showcase', 'motto-core');
    }

    public function get_icon()
    {
        return 'wgl-showcase';
    }

    public function get_keywords()
    {
        return [ 'showcase', 'title', 'images' ];
    }

    public function get_script_depends()
    {
        return [
            'wgl-widgets',
        ];
    }


    public function get_categories()
    {
        return ['wgl-modules'];
    }

    protected function register_controls()
    {
        /**
         * CONTENT -> GENERAL
         */

        $this->start_controls_section(
            'content_general',
            ['label' => esc_html__('General', 'motto-core')]
        );

        $this->add_control(
            'showcase_layout',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Layout', 'motto-core'),
                'options' => [
                    'slide' => esc_html__('Slide', 'motto-core'),
                    'interactive' => esc_html__('Interactive', 'motto-core'),
                ],
                'default' => 'interactive',
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'motto-core'),
                'type' => Controls_Manager::URL,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => [ 'url' => '#' ],
            ]
        );

        $repeater->add_control(
            'thumbnail',
            [
                'label' => esc_html__('Image', 'motto-core'),
                'type' => Controls_Manager::MEDIA,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => ['url' => Utils::get_placeholder_image_src()],
            ]
        );

        $repeater->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => esc_html__('GREAT WORK!', 'motto-core'),
            ]
        );

        $repeater->add_control(
            'subtitle',
            [
                'label' => esc_html__('Subtitle', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
            ]
        );

        $repeater->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'motto-core'),
                'type' => Controls_Manager::WYSIWYG,
                'dynamic' => [  'active' => true],
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'link_active',
            [
                'label' => esc_html__( 'Active by Default', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        WGL_Cursor::init(
            $repeater,
            [
                'section' => false,
                'repeater' => true,
                'prefix' => 'showcase_',
            ]
        );

        $this->add_control(
            'items',
            [
                'label' => esc_html__('Items', 'motto-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
                'default' => [
                    [
                        'title' => esc_html__( 'Showcase Title 1', 'motto-core' ),
                        'subtitle' => esc_html__( '001', 'motto-core' ),
                    ],
                    [
                        'title' => esc_html__( 'Showcase Title 2', 'motto-core' ),
                        'subtitle' => esc_html__( '002', 'motto-core' ),
                        'link_active' => 'yes'
                    ],
                    [
                        'title' => esc_html__( 'Showcase Title 3', 'motto-core' ),
                        'subtitle' => esc_html__( '003', 'motto-core' ),
                    ],
                    [
                        'title' => esc_html__( 'Showcase Title 4', 'motto-core' ),
                        'subtitle' => esc_html__( '004', 'motto-core' ),
                    ],
                ],
            ]
        );

        $this->add_control(
            'height_slide',
            [
                'label' => esc_html__( 'Height', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'full',
                'options' => [
                    'full' => esc_html__( 'Fit To Screen', 'motto-core' ),
                    'min-height' => esc_html__( 'Set Height', 'motto-core' ),
                ],
                'prefix_class' => 'wgl-showcase-height-',
                'condition' => [
                    'showcase_layout' => 'slide',
                ]
            ]
        );

        $this->add_responsive_control(
            'custom_height_slide',
            [
                'label' => esc_html__( 'Height', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'default' => [
                    'size' => 800,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 2440,
                    ],
                ],
                'size_units' => [ 'px', 'vh', 'vw', 'custom'],
                'condition' => [
                    'showcase_layout' => 'slide',
                    'height_slide' => [ 'min-height' ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase.slide-showcase .showcase__wrapper' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'custom_height_interactive',
            [
                'label' => esc_html__( 'Image Height', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'size_units' => [ 'px', 'vh', 'vw', 'custom'],
                'condition' => [ 'showcase_layout' => 'interactive' ],
                'default' => [ 'size' => 320 ],
                'tablet_default' => [ 'size' => 250 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase.interactive-showcase .showcase__image img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'interactive_image_position',
            [
                'label' => esc_html__( 'Image Position', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    '%' => [ 'min' => -100, 'max' => 200 ],
                ],
                'size_units' => [ '%' ],
                'condition' => [
                    'showcase_layout' => 'interactive',
                ],
                'default' => [ 'size' => 80, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase.interactive-showcase .showcase__image' => '--wgl-image-position: {{SIZE}}%;',
                ],
            ]
        );

        $this->add_control(
            'interactive_image_near_content',
            [
                'label' => esc_html__( 'Place Image Near Content', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [
                    'showcase_layout' => 'interactive',
                ],
                'default' => 'yes',
                'selectors' => [
                    '{{WRAPPER}} .showcase__item' => 'width: fit-content;',
                ],
            ]
        );

        $this->add_control(
            'img_size_string',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Image Size', 'motto-core'),
                'separator' => 'before',
                'options' => [
                    '150' => esc_html__('150x150 - Thumbnail', 'motto-core'),
                    '300' => esc_html__('300x300 - Medium', 'motto-core'),
                    '768' => esc_html__('768x768 - Medium Large', 'motto-core'),
                    '1024' => esc_html__('1024x1024 - Large', 'motto-core'),
                    'full' => esc_html__('Full', 'motto-core'),
                    'custom' => esc_html__('Custom', 'motto-core'),
                ],
                'default' => 'full',
            ]
        );

        $this->add_control(
            'img_size_array',
            [
                'label' => esc_html__('Image Dimension', 'motto-core'),
                'type' => Controls_Manager::IMAGE_DIMENSIONS,
                'condition' => [
                    'img_size_string' => 'custom',
                ],
                'description' => esc_html__('Crop the original image to any custom size. You can also set a single value for width to keep the initial ratio.', 'motto-core'),
            ]
        );

        $this->add_control(
            'img_aspect_ratio',
            [
                'label' => esc_html__('Image Aspect Ratio', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__('No Crop', 'motto-core'),
                    '1:1' => esc_html__('1:1', 'motto-core'),
                    '3:2' => esc_html__('3:2', 'motto-core'),
                    '4:3' => esc_html__('4:3', 'motto-core'),
                    '6:5' => esc_html__('6:5', 'motto-core'),
                    '9:16' => esc_html__('9:16', 'motto-core'),
                    '16:9' => esc_html__('16:9', 'motto-core'),
                    '21:9' => esc_html__('21:9', 'motto-core'),
                ],
                'default' => '',
            ]
        );

        $this->add_responsive_control(
            'items_min_height',
            [
                'label' => esc_html__( 'Items Min Height', 'elementor' ),
                'separator' => 'before',
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem', 'vh', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1440,
                    ],
                    'vh' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase__item' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'items_wrap',
                [
                'label' => esc_html__( 'Wrap', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'nowrap' => [
                        'title' => esc_html__( 'No Wrap', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-nowrap',
                    ],
                    'wrap' => [
                        'title' => esc_html__( 'Wrap', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-wrap',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase__item' => 'flex-wrap: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'items_justify_content',
            [
                'label' => esc_html__( 'Justify Content', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => false,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-start-h',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-center-h',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-end-h',
                    ],
                    'space-between' => [
                        'title' => esc_html__( 'Space Between', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-space-between-h',
                    ],
                    'space-around' => [
                        'title' => esc_html__( 'Space Around', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-space-around-h',
                    ],
                    'space-evenly' => [
                        'title' => esc_html__( 'Space Evenly', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-justify-space-evenly-h',
                    ],
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .showcase__item' => 'justify-content: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'items_align_items',
            [
                'label' => esc_html__( 'Align Items', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => false,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-end-v',
                    ],
                    'stretch' => [
                        'title' => esc_html__( 'Stretch', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-stretch-v',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .showcase__item' => 'align-items: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();

        /**
         * STYLE -> ITEM CONTAINER
         */

        $this->start_controls_section(
            'style_item_container',
            [
                'label' => esc_html__('Item Container', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'item_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
            ]
        );
        $this->add_responsive_control(
            'item_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '10',
                    'right' => '0',
                    'bottom' => '10',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'item_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_bg',
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__item',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_border',
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__item',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_shadow',
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__item',
            ]
        );

        $this->add_responsive_control(
            'image_wrapper_size',
            [
                'label' => esc_html__('Image Cointainer Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%'],
                'range' => [
                    '%' => ['max' => 100],
                ],
                'condition' => ['showcase_layout' => 'slide'],
                'default' => ['size' => 61, 'unit' => '%'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase.slide-showcase .showcase__images' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_wrapper_size',
            [
                'label' => esc_html__('Title Cointainer Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%'],
                'range' => [
                    '%' => ['max' => 100],
                ],
                'condition' => ['showcase_layout' => 'slide'],
                'default' => ['size' => 39, 'unit' => '%'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase.slide-showcase .showcase__items' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        /**
         * STYLE -> IMAGE
         */

        $this->start_controls_section(
            'style_image',
            [
                'label' => esc_html__('Image', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'image_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => ['showcase_layout' => 'interactive'],
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '-300',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_visibility',
                [
                'label' => esc_html__( 'Image Visibility', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => ['showcase_layout' => 'interactive'],
                'options' => [
                    'block' => esc_html__( 'Show', 'motto-core' ),
                    'none' => esc_html__( 'Hide', 'motto-core' ),
                ],
                'mobile_default' => 'none',
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__image' => 'display: {{VALUE}};',
                ],
            ]
        );
        $this->add_mobile_breakpoint();

        $this->start_controls_tabs('image');
        $this->start_controls_tab(
            'image_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'image_radius_idle',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_border_idle',
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__image',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_shadow_idle',
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__image',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'image_bg_idle',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__image:before',
            ]
        );
        $this->add_responsive_control(
            'image_rotation_idle',
            [
                'label' => esc_html__( 'Rotation', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => ['showcase_layout' => 'interactive'],
                'size_units' => [ 'deg' ],
                'range' => [
                    'px' => [ 'min' => -360, 'max' => 360 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase__image' => '--wgl-image-rotate: {{SIZE}}deg;',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'image_hover',
            ['label' => esc_html__('Hover/Active', 'motto-core')]
        );
        $this->add_control(
            'image_radius_hover',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__image,
				     {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_border_hover',
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__image,
				     {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__image',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_shadow_hover',
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__image,
				     {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__image',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'image_bg_hover',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__image::after,
				     {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__image::after',
            ]
        );
        $this->add_responsive_control(
            'image_rotation_hover',
            [
                'label' => esc_html__( 'Rotation', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => ['showcase_layout' => 'interactive'],
                'size_units' => [ 'deg' ],
                'range' => [
                    'px' => [ 'min' => -360, 'max' => 360 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__image,
				     {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__image' => '--wgl-image-rotate: {{SIZE}}deg;',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> Title
         */

        $this->start_controls_section(
            'style_title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'title_width',
            [
                'label' => esc_html__( 'Title Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem', '%', 'custom'],
                'range' => [ 'px' => ['max' => 1200] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__title' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_grow',
            [
                'label' => esc_html__( 'Title Flex Grow', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [ 'px' => ['min' => -10, 'max' => 10] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__title' => 'flex-grow: {{SIZE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_align_items',
            [
                'label' => esc_html__( 'Align Items', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-end-v',
                    ],
                    'stretch' => [
                        'title' => esc_html__( 'Stretch', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-stretch-v',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__title' => 'align-self: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_order',
            [
                'label' => esc_html__('Content Order', 'motto-core'),
                'type' => Controls_Manager::NUMBER,
                'dynamic' => [  'active' => true],
                'min' => -10,
                'max' => 10,
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__title' => 'order: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'div' => esc_html('‹div›'),
                    'span' => esc_html('‹span›'),
                ],
                'separator' => 'before',
                'default' => 'h3',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_font_title',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => ['size' => 96],
                        'tablet_default' => ['size' => 64],
                        'mobile_default' => ['size' => 36],
                    ],
                    'line_height' => ['default' => ['size' => 1.2, 'unit' => 'em']],
                ],
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__title',
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; --title-p-r: {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_stroke_size',
            [
                'label' => esc_html__('Stroke Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => ['px' => ['min' => 0, 'max' => 2, 'step' => 0.1]],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .title' => '-webkit-text-stroke-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->start_controls_tabs( 'title_tabs' );
        $this->start_controls_tab(
            'title_color_tab',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(0.2),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .title' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->add_control(
            'title_bg',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__title' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_stroke_color',
            [
                'label' => esc_html__('Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .title' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_skew',
            [
                'label' => esc_html__('Skew the title', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'deg' ],
                'range' => [
                    'deg' => ['min' => -45, 'max' => 45],
                ],
                'default' => [ 'size' => '0', 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .showcase__item .title' => 'transform: skew({{SIZE}}deg)',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_animation_offset_idle',
            [
                'label' => esc_html__('Animation Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'vw', 'custom' ],
                'range' => [
                    'px' => ['min' => -200, 'max' => 500],
                ],
                'default' => [ 'size' => 0, 'unit' => 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .showcase__item .showcase__title' => 'transform: translateX({{SIZE}}{{UNIT}})',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'title_hover_tab',
            ['label' => esc_html__('Hover/Active' , 'motto-core')]
        );
        $this->add_control(
            'title_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .title,
                     {{WRAPPER}} .wgl-showcase .showcase__item:hover .title' => 'color: {{VALUE}};',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase .showcase__item .title,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase .showcase__item .title,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase .showcase__item .title,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase .showcase__item .title' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->add_control(
            'title_bg_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__title,
                     {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__title' => 'background-color: {{VALUE}};',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase .showcase__item .showcase__title,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase .showcase__item .showcase__title,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase .showcase__item .showcase__title,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase .showcase__item .showcase__title' => 'background-color: {{VALUE}};'
                ],
            ]
        );
        $this->add_control(
            'title_stroke_color_hover',
            [
                'label' => esc_html__('Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .title,
                     {{WRAPPER}} .wgl-showcase .showcase__item:hover .title' => '-webkit-text-stroke-color: {{VALUE}};',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase .showcase__item .title,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase .showcase__item .title,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase .showcase__item .title,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase .showcase__item .title' => '-webkit-text-stroke-color: {{VALUE}};'
                ],
            ]
        );
        $this->add_control(
            'title_hover_skew',
            [
                'label' => esc_html__('Skew the title', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'deg' ],
                'range' => [
                    'deg' => ['min' => -45, 'max' => 45],
                ],
                'default' => [ 'size' => '0', 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .title,
                     {{WRAPPER}} .wgl-showcase .showcase__item:hover .title' => 'transform: skew({{SIZE}}deg);',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase .showcase__item .title,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase .showcase__item .title,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase .showcase__item .title,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase .showcase__item .title' => 'transform: skew({{SIZE}}deg);',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_animation_offset_hover',
            [
                'label' => esc_html__('Animation Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'vw', 'custom' ],
                'range' => [
                    'px' => ['min' => -200, 'max' => 500],
                ],
                'default' => [ 'size' => 0, 'unit' => 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__title,
                     {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__title' => 'transform: translateX({{SIZE}}{{UNIT}});',
                    '{{WRAPPER}} .wgl-showcase .showcase__title' => ' --title-a-o: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'title_transition',
            [
                'label' => esc_html__('Transition', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.1],
                ],
                'default' => ['size' => 0.4],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .title,
                     {{WRAPPER}} .wgl-showcase.interactive-showcase .showcase__image img' => 'transition: {{SIZE}}s;',
                    '{{WRAPPER}} .wgl-showcase .showcase__title' => 'transition: {{SIZE}}s, z-index 0s 0.1s;',
                    '{{WRAPPER}} .wgl-showcase.interactive-showcase .showcase__item:hover .showcase__title' => 'transition: {{SIZE}}s, z-index 0s 0s;',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();


        /**
         * STYLE -> Subtitle
         */

        $this->start_controls_section(
            'style_subtitle',
            [
                'label' => esc_html__('Subtitle', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'subtitle_width',
            [
                'label' => esc_html__( 'Subtitle Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem', '%', 'custom'],
                'range' => [ 'px' => ['max' => 1200] ],
                'default' => ['size' => 44],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__subtitle' => 'width: {{SIZE}}{{UNIT}}; min-width: fit-content; text-align: center;',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_align_items',
                [
                'label' => esc_html__( 'Align Items', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-end-v',
                    ],
                    'stretch' => [
                        'title' => esc_html__( 'Stretch', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-stretch-v',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__subtitle' => 'align-self: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'subtitle_order',
            [
                'label' => esc_html__('Subtitle Order', 'motto-core'),
                'type' => Controls_Manager::NUMBER,
                'dynamic' => [  'active' => true],
                'min' => -10,
                'max' => 10,
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__subtitle' => 'order: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_font_subtitle',
                'separator' => 'before',
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__subtitle',
            ]
        );

        $this->add_responsive_control(
            'subtitle_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '24',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'tablet_default' => [
                    'top' => '0',
                    'right' => '16',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'mobile_default' => [
                    'top' => '0',
                    'right' => '10',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '4',
                    'right' => '6',
                    'bottom' => '3',
                    'left' => '6',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '30',
                    'right' => '30',
                    'bottom' => '30',
                    'left' => '30',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__subtitle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_top_offset',
            [
                'label' => esc_html__('Top Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 100],
                    'px' => ['min' => -100, 'max' => 100, 'step' => 1],
                ],
                'default' => ['size' => -17, 'unit' => 'px'],
                'tablet_default' => ['size' => -8, 'unit' => 'px'],
                'mobile_default' => ['size' => -1, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase.slide-showcase .showcase__subtitle' => 'top: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .wgl-showcase.interactive-showcase .showcase__subtitle' => 'transform: translateY( {{SIZE}}{{UNIT}} );',
                ],
            ]
        );

        $this->add_control(
            'subtitle_absolute',
            [
                'label' => esc_html__( 'Place the Subtitle Absolutely', 'motto-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [
                    'subtitle_top_offset[size]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .showcase__subtitle' => 'position: absolute; left: 0; top: 0;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'subtitle_border',
                'render_type' => 'template',
                'dynamic' => [  'active' => true],
                'fields_options' => [
                    'border' => [ 'default' => 'solid' ],
                    'width' => [
                        'label' => esc_html__( 'Border Width', 'motto-core' ),
                        'default' => [
                            'top' => 1,
                            'right' => 1,
                            'bottom' => 1,
                            'left' => 1,
                        ],
                    ],
                    'color' => ['type' => Controls_Manager::HIDDEN],
                ],
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__subtitle',
            ]
        );
        $this->start_controls_tabs( 'subtitle_tabs' );
        $this->start_controls_tab(
            'subtitle_tab',
            ['label' => esc_html__('Idle' , 'motto-core')]
        );
        $this->add_control(
            'subtitle_color_idle',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(0.3),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__subtitle' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->add_control(
            'subtitle_bg_color_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__subtitle' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'subtitle_border_color_idle',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'subtitle_border_border!' => ['', 'none'] ],
                'default' => WGL_Globals::get_h_font_color(0.3),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__subtitle' => 'border-color: {{VALUE}}'
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'subtitle_hover_tab',
            ['label' => esc_html__('Hover/Active' , 'motto-core')]
        );
        $this->add_control(
            'subtitle_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__subtitle,
                     {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__subtitle' => 'color: {{VALUE}};',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase .showcase__item .showcase__subtitle,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase .showcase__item .showcase__subtitle,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase .showcase__item .showcase__subtitle,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase .showcase__item .showcase__subtitle' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->add_control(
            'subtitle_bg_color_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__subtitle,
                     {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__subtitle' => 'background-color: {{VALUE}}',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase .showcase__item .showcase__subtitle,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase .showcase__item .showcase__subtitle,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase .showcase__item .showcase__subtitle,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase .showcase__item .showcase__subtitle' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'subtitle_border_color_hover',
            [
                'label' => esc_html__('Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'subtitle_border_border!' => ['', 'none'] ],
                'default' => WGL_Globals::get_primary_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__subtitle,
                    {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__subtitle' => 'border-color: {{VALUE}}',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase .showcase__item .showcase__subtitle,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase .showcase__item .showcase__subtitle,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase .showcase__item .showcase__subtitle,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase .showcase__item .showcase__subtitle' => 'border-color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> CONTENT
         */

        $this->start_controls_section(
            'style_content',
            [
                'label' => esc_html__('Content', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'content_width',
            [
                'label' => esc_html__( 'Content Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem', '%', 'custom'],
                'range' => [ 'px' => ['max' => 1200] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__content' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'content_grow',
            [
                'label' => esc_html__( 'Content Flex Grow', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [ 'px' => ['min' => -10, 'max' => 10] ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__content' => 'flex-grow: {{SIZE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'content_align_items',
            [
                'label' => esc_html__( 'Align Items', 'motto-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-end-v',
                    ],
                    'stretch' => [
                        'title' => esc_html__( 'Stretch', 'motto-core' ),
                        'icon' => 'eicon-flex eicon-align-stretch-v',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__content' => 'align-self: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_content',
                'selector' => '{{WRAPPER}} .wgl-showcase .showcase__content',
            ]
        );
        $this->add_responsive_control(
            'content_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; --content-p-r: {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->start_controls_tabs('content_color_tab');
        $this->start_controls_tab(
            'custom_content_color_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_animation_offset_idle',
            [
                'label' => esc_html__('Animation Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'vw', 'custom' ],
                'range' => [
                    'px' => ['min' => -200, 'max' => 500],
                ],
                'default' => [ 'size' => 0, 'unit' => 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .showcase__item .showcase__content' => 'transform: translateX({{SIZE}}{{UNIT}})',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'custom_content_color_hover',
            ['label' => esc_html__('Hover/Active', 'motto-core')]
        );
        $this->add_control(
            'content_color_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__content,
                    {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__content' => 'color: {{VALUE}};',

                    'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}}.breakpoint_on-tablet_extra .wgl-showcase .showcase__item .showcase__content,
                     body[data-elementor-device-mode="tablet"] {{WRAPPER}}.breakpoint_on-tablet .wgl-showcase .showcase__item .showcase__content,
                     body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}}.breakpoint_on-mobile_extra .wgl-showcase .showcase__item .showcase__content,
                     body[data-elementor-device-mode="mobile"] {{WRAPPER}}.breakpoint_on-mobile .wgl-showcase .showcase__item .showcase__content' => 'color: {{VALUE}};'
                ],
            ]
        );
        $this->add_responsive_control(
            'content_animation_offset_hover',
            [
                'label' => esc_html__('Animation Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'vw', 'custom' ],
                'range' => [
                    'px' => ['min' => -200, 'max' => 500],
                ],
                'default' => [ 'size' => 0, 'unit' => 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__item.active .showcase__content,
                     {{WRAPPER}} .wgl-showcase .showcase__item:hover .showcase__content' => 'transform: translateX({{SIZE}}{{UNIT}});',
                    '{{WRAPPER}} .wgl-showcase .showcase__content' => '--content-a-o: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'content_transition',
            [
                'label' => esc_html__('Transition', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 3, 'step' => 0.1],
                ],
                'default' => ['size' => 0.4],
                'selectors' => [
                    '{{WRAPPER}} .wgl-showcase .showcase__content' => 'transition: {{SIZE}}s',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function add_mobile_breakpoint() {
        // The 'Hide On X' controls are displayed from largest to smallest, while the method returns smallest to largest.
        $active_devices = Plugin::$instance->breakpoints->get_active_devices_list( [ 'reverse' => true ] );
        $active_breakpoints = Plugin::$instance->breakpoints->get_active_breakpoints();

        $avaliable_breakpoints = [];
        foreach ( $active_devices as $breakpoint_key ) {
            $label = 'desktop' === $breakpoint_key ? esc_html__( 'Desktop', 'motto-core' ) : $active_breakpoints[ $breakpoint_key ]->get_label();
            $avaliable_breakpoints[$breakpoint_key] = $label;
        }
        $avaliable_breakpoints['disable'] = 'Disable';

        $this->add_control(
            'wgl_mobile_breakpoint',
            [
                /* translators: %s: Device Name. */
                'label' => esc_html__( 'Set Mobile Template On:', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => $avaliable_breakpoints,
                'prefix_class' => 'breakpoint_on-',
            ]
        );
    }

    protected function render()
    {
        extract($this->get_settings_for_display());

        // Variables validation
        $img_size_string = $img_size_string ?? '';
        $img_size_array = $img_size_array ?? [];
        $img_aspect_ratio = $img_aspect_ratio ?? '';

        // Build structure
        $items_html_title = $items_html_image = $showcase__wrapper = '';

        foreach ($items as $index => $item) {
            // Fields validation
            $thumbnail = $item['thumbnail'] ?? '';
            $attachment = get_post($thumbnail['id']);
            $image_data = wp_get_attachment_image_src($thumbnail['id'], 'full');
            $title = $item['title'] ?? '';
            $subtitle = $item['subtitle'] ?? '';
            $link = $item['link'] ?? '';
            $content = $item['content'] ?? '';

            $has_link = !empty($link['url']);

            //Cursor
            if (isset($item['cursor_tooltip']) && '' != $item['cursor_tooltip']) {
                add_filter( 'wgl/motto_module_cursor', function () { return true; });
            }
            $cursor = new WGL_Cursor;
            $cursor_data = $cursor->build($this, $item, $item['_id'], 'showcase_');

            //* Image size
            $dim = null;
            $image = $showcase_content = '';

            if ($image_data) {
                $dim = WGL_Elementor_Helper::get_image_dimensions(
                    $img_size_array ?: $img_size_string,
                    $img_aspect_ratio,
                    $image_data
                );
            }

            if ($has_link) {
                $link = $this->get_repeater_setting_key('link', 'items', $index);
                $this->add_link_attributes($link, $item['link']);
            }

            if($dim){
                $image_url = aq_resize($image_data[0], $dim['width'], $dim['height'], true, true, true) ?: $image_data[0];
                //* Image Attachment
                $image_arr = [
                    'src' => $image_url,
                    'alt' => get_post_meta($thumbnail['id'], '_wp_attachment_image_alt', true),
                ];

                $this->add_render_attribute('image' . $index, [
                    'class' => 'image',
                    'src' => $image_arr['src'],
                    'alt' => $image_arr['alt']
                ]);

                $this->add_render_attribute('showcase__image' . $index, [
                    'class' => [
                        'showcase__image',
                        $dim && 'slide' ? $showcase_layout : '',
                    ],
                    'style' => 'background-image:url('.esc_url($image_arr['src']).')'
                ]);
            }

            $image .=  '<div '.$this->get_render_attribute_string('showcase__image' . $index).'>';
            $image .=  $dim ? '<img '. $this->get_render_attribute_string('image' . $index). '>' : '';
            $image .= '</div>';

            $items_html_image .= $image;

            // Content
            if (!empty($content)) {
                $showcase_content = '<div class="showcase__content">' . $content . '</div>';
            }

            switch ($showcase_layout) {
                case 'slide':
                    $subtitle = !empty($subtitle) ? '<span class="showcase__subtitle">'. esc_html($subtitle) .'</span>' : '';

                    $items_html_title .= '<' . esc_attr($title_tag) . ' class="showcase__item' . ( isset($item['cursor_tooltip']) && !empty($item['cursor_tooltip']) ? ' wgl-cursor-text' : '' ) . '"' . $cursor_data . '>'
                        . '<div class="showcase__item-inner">'
                        . ($has_link ? '<a class="showcase__link" ' . $this->get_render_attribute_string($link) . '></a>' : '')
                        . (!empty($title) ? $subtitle.'<span class="title">'. esc_html($title) .'</span>' : '')
                        . '</div>'
                        . '</' . esc_attr($title_tag) . '>';

                    break;

                case 'interactive':
                    $showcase__item = $this->get_repeater_setting_key( 'item_link_active', 'items', $index );
                    $this->add_render_attribute( $showcase__item, [
                        'class' => [
                            'showcase__item',
                            $item[ 'link_active' ] ? 'active' : '',
                            ( isset($item['cursor_tooltip']) && !empty($item['cursor_tooltip']) ? ' wgl-cursor-text' : '' )
                        ],
                    ] );

                    $subtitle = !empty($subtitle) ? '<span class="showcase__subtitle">'. esc_html($subtitle) .'</span>' : '';
                    $title = '<' . esc_attr($title_tag) . ' class="showcase__title">'
                        . $subtitle
                        . (!empty($title) ? '<span class="title">'. esc_html($title) .'</span>' : '')
                        . '</' . esc_attr($title_tag) . '>';

                    $showcase__wrapper .= '<div '. $this->get_render_attribute_string( $showcase__item ) . $cursor_data . '>';
                        if ($has_link) {
                            $showcase__wrapper .= '<a class="showcase__link" ' . $this->get_render_attribute_string($link) . '></a>';
                        }
                        $showcase__wrapper .= $title;
                        $showcase__wrapper .= $showcase_content;
                        $showcase__wrapper .= $image;
                    $showcase__wrapper .= '</div>';
                    break;
            }
        }

        if ('slide' === $showcase_layout) {
            echo '<div class="wgl-showcase slide-showcase">',
                '<div class="showcase__wrapper">',
                    '<div class="showcase__items">',
                        $items_html_title,
                    '</div>',
                    '<div class="showcase__images">',
                        $items_html_image,
                    '</div>',
                '</div>',
            '</div>';
        } else {
            echo '<div class="wgl-showcase interactive-showcase">',
                $showcase__wrapper,
            '</div>';
        }
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WGL_Extensions\Includes\WGL_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
