<?php

define('WGL_ELEMENTOR_MODULE_URL', plugins_url('/', __FILE__));
define('WGL_ELEMENTOR_MODULE_PATH', plugin_dir_path(__FILE__));
define('WGL_ELEMENTOR_MODULE_FILE', __FILE__);

use Elementor\{Controls_Manager, Group_Control_Border, Group_Control_Typography, Group_Control_Background, Plugin};
use WGL_Extensions\WGL_Framework_Global_Variables as WGL_Globals;

if (!class_exists('WGL_Elementor_Module')) {
    /**
     * WGL Elementor Module
     *
     *
     * @package motto-core\includes\elementor
     * @author WebGeniusLab <webgeniuslab@gmail.com>
     * @since 1.0.0
     */
    class WGL_Elementor_Module
    {
        /**
         * @var string The defualt path to elementor dir on this plugin.
         */
        private $dir_path;

        private static $instance;

        public $sections = [];

        public function __construct()
        {
            $this->dir_path = plugin_dir_path(__FILE__);

            add_action('plugins_loaded', [$this, 'elementor_setup']);

            add_action('elementor/init', [$this, 'optimize_elementor'], 5);
            add_action('elementor/init', [$this, 'inject_wgl_categories']);

            add_filter('elementor/widgets/wordpress/widget_args', [$this, 'wgl_widget_args'], 10, 1); // WPCS: spelling ok.

	        add_action('elementor/element/section/section_advanced/before_section_end', [$this, 'wgl_change_min_zindex'], 20, 2);
	        add_action('elementor/element/column/section_advanced/before_section_end', [$this, 'wgl_change_min_zindex'], 20, 2);

            // Empowers overflow hidden
            add_action('elementor/element/section/section_layout/before_section_end', [$this, 'empowers_column_overflow'], 20, 2);

	        add_action('elementor/element/common/_section_style/before_section_end', [$this, 'wgl_pointer_events'], 20, 2);
            add_action('elementor/element/section/section_advanced/before_section_end', [$this, 'wgl_pointer_events'], 20, 2);
            add_action('elementor/element/column/section_advanced/before_section_end', [$this, 'wgl_pointer_events'], 20, 2);
            add_action('elementor/element/container/section_layout_additional_options/before_section_end', [$this, 'wgl_pointer_events'], 10, 2);

            add_action('elementor/element/common/_section_responsive/before_section_end', [$this, 'wgl_hide_under'], 20, 2);

            add_filter('wgl_flaticon_icons', [$this, 'theme_icons']);

            // Add WGL extension control section to Section panel
            add_action('elementor/frontend/section/before_render', [$this, 'extended_row_render'], 10, 1);
            add_action('elementor/frontend/container/before_render', [$this, 'extended_row_render'], 10, 1);

            add_action('elementor/element/section/section_typo/after_section_end', [$this, 'extended_animation_options'], 10, 2);
            add_action('elementor/element/container/_section_transform/after_section_end', [$this, 'extended_animation_options'], 10, 2);
            // add_action('elementor/element/container/_section_transform/after_section_end', [$this, 'extended_container_parallax_section_options'], 10, 2);

            add_action('elementor/element/container/_section_transform/after_section_end', [$this, 'extended_container_stretch_section_options'], 10, 2);
        }

        /**
         * Eliminate redundant functionality
         * and speed up website load
         */
        public function optimize_elementor()
        {
            if (!class_exists('\WGL_Framework')) {
                return;
            }

            if (WGL_Framework::get_option('disable_elementor_googlefonts')) {
                /**
                 * Disable Google Fonts
                 * Note: breaks all fonts selected within `Group_Control_Typography` (if any).
                 */
                add_filter('elementor/frontend/print_google_fonts', '__return_false');
            }

            if (WGL_Framework::get_option('disable_elementor_fontawesome')) {
                /** Disable Font Awesome pack */
                add_action('elementor/frontend/after_register_styles', function () {
                    foreach (['solid', 'regular', 'brands'] as $style) {
                        wp_deregister_style('elementor-icons-fa-' . $style);
                    }
                }, 20);
            }
        }

        public function elementor_setup()
        {
            $this->requiere_all_files('includes');
            $this->requiere_all_files('templates');

            /**
             * Check if Elementor installed and activated
             * @see https://developers.elementor.com/creating-an-extension-for-elementor/
             */
            if (!did_action('elementor/loaded')) {
                return;
            }

            $this->init_addons();
        }

        /**
         * Load required file for addons integration
         */
        public function init_addons()
        {
            add_action('elementor/widgets/register', [$this, 'widgets_area']);

            add_action('elementor/frontend/after_register_scripts', [$this, 'frontend_scripts_registration']);
            add_action('elementor/editor/before_enqueue_scripts', [$this, 'admin_styles_enqueuing']);
            add_action('elementor/frontend/before_enqueue_scripts', [$this, 'enqueue_scripts']);

            add_action( 'init', [ $this, 'add_wpml_support' ] );

            $this->init_all_modules();
        }

        public function init_all_modules()
        {
            foreach (glob($this->dir_path . 'modules/' . '*.php') as $file_name) {
                $base = basename(str_replace('.php', '', $file_name));
                $class = ucwords(str_replace('-', ' ', $base));
                $class = str_replace(' ', '_', $class);
                $class = sprintf('WGL_Extensions\Modules\%s', $class);

                // Class File
                require_once $file_name;

                if (class_exists($class)) {
                    new $class();
                }
            }
        }

        /**
         * Register addon by file name.
         */
        public function register_controls_addon($file_name)
        {
            $controls_manager = Plugin::$instance->controls_manager;

            $base = basename(str_replace('.php', '', $file_name));
            $class = ucwords(str_replace('-', ' ', $base));
            $class = str_replace(' ', '_', $class);
            $class = sprintf('WGL_Extensions\Controls\%s', $class);

            // Class Constructor File
            require_once $file_name;

            if (class_exists($class)) {
                $controls_manager->register(new $class);
            }
        }

        /**
         * Load widgets require function
         */
        public function widgets_area()
        {
            $this->requiere_all_files('widgets');
            $this->requiere_all_files('header');
        }

        private function requiere_all_files($require_file = 'widgets', $wpml_translate = false)
        {
            $template_names = [];
            $template_path = '/wgl-extensions/elementor/'.$require_file.'/';
            $plugin_template_path = $this->dir_path . $require_file.'/';
            $ext_template_path = WGL_EXTENSIONS_ELEMENTOR_PATH . $require_file.'/';

            foreach (glob($ext_template_path . '*.php') as $file) {
                $template_name = basename($file);
                array_push($template_names, $template_name);
            }

            foreach (glob($plugin_template_path . '*.php') as $file) {
                $template_name = basename($file);
                array_push($template_names, $template_name);
            }

            $files = wgl_extensions_global()->get_locate_template(
                $template_names,
                '/elementor/' . $require_file . '/',
                $template_path,
                realpath(__DIR__ . '/..')
            );

            switch ($require_file) {
                case 'templates':
                case 'includes':
                    foreach ((array) $files as $file) {
                        require_once $file;
                    }
                    break;
                case 'header':
                case 'widgets':
                    foreach ((array) $files as $file_name) {
                        $this->register_wgl_widget($file_name, $wpml_translate);
                    }
                    break;
            }
        }

        public function register_wgl_widget($file_name = '', $wpml_translate = false)
        {
            $widget_manager = Plugin::instance()->widgets_manager;

            $base = basename(str_replace('.php', '', $file_name));
            $class = ucwords(str_replace('-', ' ', $base));
            $class = str_replace('Wgl', 'WGL', $class);
            $class = str_replace(' ', '_', $class);
            $class = sprintf('WGL_Extensions\Widgets\%s', $class);

            if ($this->unvalid_widget_registration($class)) {
                // Bailout.
                return;
            }

            require_once $file_name;

            if (class_exists($class)) {
                if(!$wpml_translate){
                    $widget_manager->register( new $class );
                }else{
                    $widget = new $class();
                    if(method_exists(new $class(), 'wpml_support_module')){
                        $widget->wpml_support_module();
                    }
                }
            }
        }

        private function unvalid_widget_registration($class)
        {
            if (
                'WGL_Extensions\Widgets\WGL_Header_Wpml' === $class
                && !class_exists('\SitePress')
            ) {
                return true;
            }

            if (!class_exists('\WooCommerce')) {
                if (
                    'WGL_Extensions\Widgets\WGL_Header_Cart' === $class
                    || 'WGL_Extensions\Widgets\WGL_Header_login' === $class
                    || 'WGL_Extensions\Widgets\WGL_Products_Grid' === $class
                    || 'WGL_Extensions\Widgets\WGL_Products_Categories' === $class
                ) {
                    return true;
                }
            }

            if (!class_exists('WPCF7_ContactForm')) {
                if (
                    'WGL_Extensions\Widgets\WGL_Contact_Form_7' === $class
                ) {
                    return true;
                }
            }

            return false; // registration can be continued
        }

        public function frontend_scripts_registration()
        {
            wp_register_script(
                'wgl-widgets',
                WGL_ELEMENTOR_MODULE_URL . '/assets/js/wgl_elementor_widgets.js',
                ['jquery'],
                '1.0.0',
                true
            );

            wp_register_script(
                'isotope',
                WGL_EXTENSIONS_ELEMENTOR_URL . 'assets/js/isotope.pkgd.min.js',
                ['jquery'],
                '1.0.0',
                true
            );

	        wp_register_script(
		        'jquery-easypiechart',
		        get_template_directory_uri() . '/js/jquery.easypiechart.min.js',
		        ['jquery'],
		        '2.1.7',
		        true
	        );

            wp_register_script(
                'jquery-appear',
                get_template_directory_uri() . '/js/jquery.appear.js',
                ['jquery'],
                '1.0.0',
                true
            );

            wp_register_script(
                'jarallax',
                get_template_directory_uri() . '/js/jarallax.min.js',
                ['jquery'],
                '1.0.0',
                true
            );

            wp_register_script(
                'jarallax-video',
                get_template_directory_uri() . '/js/jarallax-video.min.js',
                ['jquery'],
                '1.0.0',
                true
            );

            wp_register_script(
                'jquery-countdown',
                get_template_directory_uri() . '/js/jquery.countdown.min.js',
                ['jquery'],
                '1.0.0',
                true
            );

            wp_register_script(
                'cocoen',
                get_template_directory_uri() . '/js/cocoen.min.js',
                ['jquery'],
                '1.0.0',
                true
            );

            wp_register_script(
                'matter',
                get_template_directory_uri() . '/js/matter.min.js',
                ['jquery'],
                '1.0.0',
                true
            );

            wp_register_script(
                'jquery-justifiedGallery',
                get_template_directory_uri() . '/js/jquery.justifiedGallery.min.js',
                ['jquery'],
                '1.0.0',
                true
            );
        }

        public function inject_wgl_categories()
        {
            $elements_manager = Plugin::instance()->elements_manager;

            $elements_manager->add_category(
                'wgl-modules',
                ['title' => esc_html__('WGL Modules', 'motto-core')]
            );

            $elements_manager->add_category(
                'wgl-header-modules',
                ['title' => esc_html__('WGL Header Modules', 'motto-core')]
            );
        }

        public function admin_styles_enqueuing()
        {
            wp_enqueue_style(
                WGL_Globals::get_theme_slug() . '-flaticon',
                get_template_directory_uri() . '/fonts/flaticon/flaticon.css',
                [],
                WGL_Globals::get_theme_version()
            );
        }

        public function wgl_widget_args($params)
        {
            // Default wrapper for widget and title
            $id = str_replace('wp-', '', $params['widget_id']);
            $id = str_replace('-', '_', $id);

            $wrapper_before = '<div class="wgl-elementor-widget widget '. WGL_Globals::get_theme_slug() . '_widget ' . esc_attr($id) . '">';
            $wrapper_after = '</div>';
            $title_before = '<div class="title-wrapper"><span class="title">';
            $title_after = '</span></div>';

            $default_widget_args = [
                'id' => 'sidebar_' . esc_attr(strtolower(preg_replace('/[^A-Za-z0-9\-]/', '', str_replace(' ', '-', $params['widget_id'])))),
                'before_widget' => $wrapper_before,
                'after_widget' => $wrapper_after,
                'before_title' => $title_before,
                'after_title' => $title_after,
            ];

            return $default_widget_args;
        }

	    public function wgl_change_min_zindex( $element, $args )
	    {
		    /* @var \Elementor\Widget_Base $element */
		    $element->update_control( 'z_index', [
			    'min' => -9999,
		    ] );
	    }

	    public function empowers_column_overflow( $element, $args )
	    {
		    /* @var \Elementor\Widget_Base $element */
		    $element->update_control( 'overflow', [
                'options' => [
                    '' => esc_html__( 'Default', 'elementor' ),
                    'hidden' => esc_html__( 'Hidden', 'elementor' ),
                    'hidden !important' => esc_html__( 'Hidden Important', 'elementor' ),
                ],
		    ] );
	    }

	    public function wgl_pointer_events( $element, $args )
	    {
		    /* @var \Elementor\Widget_Base $element */
		    $element->add_control(
			    'wgl_pointer_events',
			    [
				    'label' => esc_html__( 'WGL Pointer Events', 'motto-core' ),
				    'type' => Controls_Manager::SELECT,
				    'options' => [
					    '' => esc_html__( 'Default', 'motto-core' ),
					    'auto' => esc_html__( 'Auto', 'motto-core' ),
					    'none' => esc_html__( 'None', 'motto-core' ),
				    ],
				    'selectors' => [
					    '{{WRAPPER}}' => 'pointer-events: {{VALUE}};',
				    ],
			    ]
		    );
	    }

	    public function wgl_hide_under( $element, $args )
	    {
		    /* @var \Elementor\Widget_Base $element */
            $element->add_control(
                'wgl_hide_el_under_enable',
                [
                    'label' => esc_html__('Custom Responsive Visibility', 'motto-core'),
                    'description' => esc_html__('Experimental Features from WGL', 'motto-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'separator' => 'before',
                ]
            );
            $element->add_control(
                'wgl_hide_el_under',
                [
                    'label' => esc_html__( 'Hide Element Under (px)', 'motto-core' ),
                    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                    'size_units' => ['px'],
                    'range' => [ 'px' => [ 'min' => 280, 'max' => 2560 ] ],
                    'condition' => ['wgl_hide_el_under_enable!' => ''],
                    'default' => ['size' => 0],
                    'selectors' => [
                        '/* {{WRAPPER}}' => '*/@media (max-width:{{wgl_hide_el_under.SIZE}}px){/*',
                        '*/ body:not(.elementor-editor-active) {{WRAPPER}}' => 'display: none;',
                        'body.elementor-editor-active {{WRAPPER}}' => 'opacity: 0.5; filter: grayscale(1);',
                        '} {{WRAPPER}}' => 'display: block;',
                    ],
                ]
            );
	    }

        public function theme_icons()
        {
            return [
                "menu-burger",
                "menu-dots",
                "dots-menu",
                "down-arrow",
                "search",
                "quote",
                "arroba",
                "at",
                "shopping-cart",
                "down-arrow-1",
                "play-button",
                "play",
                "link",
                "attach-file",
                "right",
                "down-right-arrow",
                "levels",
                "search-1",
                "heart",
                "heart-1",
                "heart-2",
                "love",
                "bubble-chat",
                "geometric",
                "geometric-1",
                "geometric-2",
                "geometric-3",
                "geometric-4",
                "geometric-5",
                "geometric-shapes",
                "geometric-6",
                "close-button",
                "compare",
                "compare-1",
                "info",
                "check",
                "remove",
                "warning",
                "question",
                "user-interface",
                "smartphone",
                "chat",
                "script",
                "smartwatch",
                "lock",
                "data",
                "briefcase",
                "copy",
                "user",
                "file",
                "shop",
                "timer",
                "vip",
            ];
        }

        public function add_wpml_support() {
            if(class_exists('\SitePress')){
                $this->requiere_all_files('widgets', true);
                $this->requiere_all_files('header', true);
            }
        }

        /**
         * Creates and returns an instance of the class
         *
         * @return object
         */
        public static function get_instance()
        {
            if (is_null(self::$instance)) {
                self::$instance = new self;
            }

            return self::$instance;
        }

        function theme_section_settings_elementor($settings) {

            $new_arr = $cursor_keys = $stretch_section_keys = $parallax_section_keys = [];
            // Cursor
            if (!empty($settings['cursor_tooltip'])) {
                $cursor_keys = [
                    'cursor_tooltip',
                    'cursor_tooltip_type',
                    'tooltip_text',
                    'tooltip_descr',
                    'cursor_thumbnail',
                    'tooltip_thumbnail_width',
                    'cursor_color_bg',
                    'tabs_cursor',
                    'tabs_cursor_title',
                    'tooltip_title',
                    'tooltip_title_width',
                    'tooltip_title_alignment',
                    'tooltip_title_padding',
                    'tooltip_title_radius',
                    'tooltip_title_border',
                    'tooltip_title_color',
                    'tooltip_title_bg',
                    'tooltip_descr',
                    'tooltip_descr_width',
                    'tooltip_descr_alignment',
                    'tooltip_descr_padding',
                    'tooltip_descr_radius',
                    'tooltip_descr_border',
                    'tooltip_descr_color',
                    'tooltip_descr_bg',
                    'cursor_tooltip_bg',
                    'tooltip_bg_width',
                    'tooltip_bg_height',
                    'tooltip_bg_radius',
                    'tooltip_bg_color',
                    'tooltip_bg_blur',
                ];
            }
            // Stretch Section
            if (!empty($settings['apply_stretch_section'])) {
                $stretch_section_keys = [
                    'apply_stretch_section',
                ];
            }
            // Parallax Section
            if (!empty($settings['apply_parallax_section'])) {
                $parallax_section_keys = [
                    'apply_parallax_section'
                ];
            }

            $all_keys = array_unique(array_merge($cursor_keys, $stretch_section_keys, $parallax_section_keys));

            foreach ($all_keys as $key) {
                if (array_key_exists($key, $settings)) {
                    $new_arr[$key] = $settings[$key];
                }
            }

            return $new_arr;
        }

        public function extended_row_render(\Elementor\Element_Base $element)
        {
            if (
                'section' !== $element->get_name()
                && 'container' !== $element->get_name()
            ) {
                // Bailout.
                return;
            }

            $settings = $element->get_settings();
            $data = $element->get_data();
            $settings = $this->theme_section_settings_elementor($settings);

            if (!empty($settings)) {
                $this->sections[$data['id']] = $settings;
            }
        }

        public function enqueue_scripts()
        {
            wp_localize_script(WGL_Globals::get_theme_slug() . '-theme-addons', 'wgl_section_settings', [
                $this->sections,
            ]);

            // wp_enqueue_script('parallax', esc_url(get_template_directory_uri() . '/js/parallax.min.js'));
        }

        public function extended_animation_options($widget, $args)
        {

            /**
             * GENERAL -> CURSOR
             */

            $widget->start_controls_section(
                'extened_cursor_tooltip',
                [
                    'label' => esc_html__('WGL Cursor Tooltip', 'motto-core'),
                    'tab' => Controls_Manager::TAB_STYLE
                ]
            );

            $widget->add_control(
                'cursor_tooltip',
                [
                    'label' => esc_html__('Add Cursor Tooltip', 'motto-core'),
                    'type' => Controls_Manager::SWITCHER,
                ]
            );

            $widget->add_control(
                'cursor_tooltip_type',
                [
                    'label' => esc_html__('Tooltip Type', 'motto-core'),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'simple' => esc_html__('Simple', 'motto-core'),
                        'custom' => esc_html__('Custom Text', 'motto-core'),
                        'image' => esc_html__('Image', 'motto-core'),
                    ],
                    'default' => 'text',
                    'condition' => ['cursor_tooltip' => 'yes']
                ]
            );

            $widget->add_control(
                'tooltip_text',
                [
                    'label' => esc_html__('Tooltip Title', 'motto-core'),
                    'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                    'condition' => [
                        'cursor_tooltip_type' => 'custom',
                        'cursor_tooltip' => 'yes'
                    ],
                    'default' => esc_html__('Read More', 'motto-core'),
                    'label_block' => true,
                ]
            );

            $widget->add_control(
                'tooltip_descr',
                [
                    'label' => esc_html__('Tooltip Description', 'motto-core'),
                    'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                    'condition' => [
                        'cursor_tooltip_type' => 'custom',
                        'cursor_tooltip' => 'yes'
                    ],
                    'label_block' => true,
                ]
            );

            $widget->add_control(
                'cursor_thumbnail',
                [
                    'label' => esc_html__('Thumbnail', 'motto-core'),
                    'type' => Controls_Manager::MEDIA,
			    'dynamic' => [  'active' => true],
                    'label_block' => true,
                    'condition' => [
                        'cursor_tooltip_type' => 'image',
                        'cursor_tooltip' => 'yes'
                    ],
                ]
            );
            $widget->add_responsive_control(
                'tooltip_thumbnail_width',
                [
                    'label' => esc_html__('Width', 'motto-core'),
                    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                    'range' => [
                        'px' => [ 'min' => 10, 'max' => 500 ],
                    ],
                    'size_units' => [ 'px', 'vw', 'custom'],
                    'condition' => [
                        'cursor_tooltip_type' => 'image',
                        'cursor_tooltip' => 'yes'
                    ],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js img' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

            $widget->add_control(
                'cursor_color_bg',
                [
                    'label' => esc_html__('Background Color', 'motto-core'),
                    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                    'condition' => [
                        'cursor_tooltip_type' => 'simple',
                        'cursor_tooltip' => 'yes'
                    ],
                ]
            );

            $widget->start_controls_tabs(
                'tabs_cursor', [
                    'condition' => [
                        'cursor_tooltip_type' => ['def', 'custom'],
                        'cursor_tooltip' => 'yes'
                    ]
                ]
            );
            $widget->start_controls_tab(
                'tabs_cursor_title',
                ['label' => esc_html__('Title', 'motto-core')]
            );
            $widget->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'tooltip_title',
                    'selector' => '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js h6',
                ]
            );
            $widget->add_responsive_control(
                'tooltip_title_width',
                [
                    'label' => esc_html__('Min Width', 'motto-core'),
                    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                    'range' => [
                        'px' => [ 'min' => 50, 'max' => 500 ],
                    ],
                    'size_units' => [ 'px', '%', 'custom' ],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js h6' => 'min-width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $widget->add_responsive_control(
                'tooltip_title_alignment',
                [
                    'label' => esc_html__('Alignment', 'motto-core'),
                    'type' => Controls_Manager::CHOOSE,
                    'toggle' => true,
                    'options' => [
                        'left' => [
                            'title' => esc_html__('Left', 'motto-core'),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => esc_html__('Center', 'motto-core'),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => esc_html__('Right', 'motto-core'),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'default' => 'left',
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js h6' => 'text-align: {{VALUE}}',
                    ],
                ]
            );
            $widget->add_responsive_control(
                'tooltip_title_padding',
                [
                    'label' => esc_html__('Padding', 'motto-core'),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => ['px', '%', 'custom'],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js h6' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $widget->add_control(
                'tooltip_title_radius',
                [
                    'label' => esc_html__('Border Radius', 'motto-core'),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => ['px', '%', 'custom'],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js h6' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $widget->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'tooltip_title_border',
                    'fields_options' => [
                        'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                        'color' => [ 'label' => esc_html__( 'Border Color', 'motto-core' ) ],
                    ],
                    'selector' => '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js h6',
                ]
            );
            $widget->add_control(
                'tooltip_title_color',
                [
                    'label' => esc_html__('Title Color', 'motto-core'),
                    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js h6' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $widget->add_control(
                'tooltip_title_bg',
                [
                    'label' => esc_html__('Background Color', 'motto-core'),
                    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js h6' => 'background-color: {{VALUE}}',
                    ],
                ]
            );
            $widget->end_controls_tab();
            $widget->start_controls_tab(
                'tabs_cursor_descr',
                ['label' => esc_html__('Description', 'motto-core')]
            );
            $widget->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'tooltip_descr',
                    'selector' => '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js .descr',
                ]
            );
            $widget->add_responsive_control(
                'tooltip_descr_width',
                [
                    'label' => esc_html__('Min Width', 'motto-core'),
                    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                    'range' => [
                        'px' => [ 'min' => 50, 'max' => 500 ],
                    ],
                    'size_units' => [ 'px', '%', 'custom' ],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js .descr' => 'min-width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $widget->add_responsive_control(
                'tooltip_descr_alignment',
                [
                    'label' => esc_html__('Alignment', 'motto-core'),
                    'type' => Controls_Manager::CHOOSE,
                    'toggle' => true,
                    'options' => [
                        'left' => [
                            'title' => esc_html__('Left', 'motto-core'),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => esc_html__('Center', 'motto-core'),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => esc_html__('Right', 'motto-core'),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'default' => 'left',
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js .descr' => 'text-align: {{VALUE}}',
                    ],
                ]
            );
            $widget->add_responsive_control(
                'tooltip_descr_padding',
                [
                    'label' => esc_html__('Padding', 'motto-core'),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => ['px', '%', 'custom'],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js .descr' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $widget->add_control(
                'tooltip_descr_radius',
                [
                    'label' => esc_html__('Border Radius', 'motto-core'),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => ['px', '%', 'custom'],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js .descr' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $widget->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'tooltip_descr_border',
                    'fields_options' => [
                        'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                        'color' => [ 'label' => esc_html__( 'Border Color', 'motto-core' ) ],
                    ],
                    'selector' => '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js .descr',
                ]
            );
            $widget->add_control(
                'tooltip_descr_color',
                [
                    'label' => esc_html__('Description Color', 'motto-core'),
                    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js .descr' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $widget->add_control(
                'tooltip_descr_bg',
                [
                    'label' => esc_html__('Background Color', 'motto-core'),
                    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js .descr' => 'background-color: {{VALUE}}',
                    ],
                ]
            );
            $widget->end_controls_tab();

            $widget->start_controls_tab(
                'tabs_cursor_bg',
                ['label' => esc_html__('Background', 'motto-core')]
            );

            $widget->add_control(
                'cursor_tooltip_bg',
                [
                    'label' => esc_html__('Add Tooltip Background', 'motto-core'),
                    'type' => Controls_Manager::SWITCHER,
                ]
            );

            $widget->add_responsive_control(
                'tooltip_bg_width',
                [
                    'label' => esc_html__('Width', 'motto-core'),
                    'type' => Controls_Manager::SLIDER,
                    'dynamic' => [  'active' => true],
                    'range' => [
                        'px' => [ 'min' => 10, 'max' => 1500 ],
                    ],
                    'size_units' => [ 'px', 'vw', 'custom'],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js::before' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                    'condition' => ['cursor_tooltip_bg' => 'yes'],
                ]
            );

            $widget->add_responsive_control(
                'tooltip_bg_height',
                [
                    'label' => esc_html__('Height', 'motto-core'),
                    'type' => Controls_Manager::SLIDER,
                    'dynamic' => [  'active' => true],
                    'range' => [
                        'px' => [ 'min' => 10, 'max' => 1500 ],
                    ],
                    'size_units' => [ 'px', 'vw', 'custom'],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js::before' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                    'condition' => ['cursor_tooltip_bg' => 'yes'],
                ]
            );

            $widget->add_control(
                'tooltip_bg_radius',
                [
                    'label' => esc_html__('Border Radius', 'motto-core'),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => ['px', '%', 'custom'],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'condition' => ['cursor_tooltip_bg' => 'yes'],
                ]
            );

            $widget->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'tooltip_bg_color',
                    'label' => esc_html__('Background', 'motto-core'),
                    'types' => ['classic', 'gradient'],
                    'selector' => '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js::before',
                    'condition' => ['cursor_tooltip_bg' => 'yes'],
                    'fields_options' => [
                        'background' => [ 'default' => 'gradient' ],
                        'color' => [
                            'label' => esc_html__( 'Background Color', 'motto-core' ),
                            'default' => WGL_Globals::get_secondary_color(0.6),
                        ],
                        'color_b' => [
                            'label' => esc_html__( 'Second Background Color', 'motto-core' ),
                            'default' => WGL_Globals::get_secondary_color(0),
                        ],
                        'gradient_type' => [ 'default' => 'radial' ],
                        'image' => [ 'type' => Controls_Manager::HIDDEN ],
                    ],
                ]
            );

            $widget->add_control(
                'tooltip_bg_blur',
                [
                    'label' => esc_html__('Blur', 'motto-core'),
                    'type' => Controls_Manager::SLIDER,
                    'dynamic' => [  'active' => true],
                    'range' => [
                        'px' => ['max' => 100, 'step' => 0.1],
                    ],
                    'selectors' => [
                        '#wgl-cursor .wgl-element-{{ID}}.cursor-from-js::before' => 'filter: blur({{SIZE}}px);',
                    ],
                    'condition' => ['cursor_tooltip_bg' => 'yes'],
                ]
            );

            $widget->end_controls_tab();
            $widget->end_controls_tabs();

            $widget->end_controls_section();
        }

        public function extended_container_stretch_section_options($widget, $args)
        {
            /**
             * Stretch Section
             */

            $widget->start_controls_section(
                'extended_stretch_section',
                [
                    'label' => esc_html__('WGL Stretch Section', 'motto-core'),
                    'tab' => Controls_Manager::TAB_LAYOUT,
                    'hide_in_inner' => true,
                ]
            );

            $widget->add_control(
                'apply_stretch_section',
                [
                    'label' => esc_html__('Stretch Section', 'motto-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'default' => '',
                    'return_value' => 'section-stretched',
                    'hide_in_inner' => true,
                    'description' => esc_html__( 'Stretch the section to the full width of the page using JS.', 'motto-core' ),
                    'frontend_available' => true,
                ]
            );

            $widget->end_controls_section();
        }

        // public function extended_container_parallax_section_options($widget, $args)
        // {
        //     /**
        //      * Parallax for container
        //      */

        //     $widget->start_controls_section(
        //         'extended_parallax_section',
        //         [
        //             'label' => esc_html__('WGL Parallax Section', 'motto-core'),
        //             'tab' => Controls_Manager::TAB_LAYOUT,
        //         ]
        //     );

        //     $widget->add_control(
        //         'apply_parallax_section',
        //         [
        //             'label' => esc_html__('Parallax Section', 'motto-core'),
        //             'type' => Controls_Manager::SWITCHER,
        //             'default' => '',
        //             'return_value' => 'section-parallax',
        //         ]
        //     );

        //     $widget->end_controls_section();
        // }

    }
}

if (!function_exists('wgl_elementor_module')) {
    function wgl_elementor_module()
    {
        return WGL_Elementor_Module::get_instance();
    }

    wgl_elementor_module();
}
