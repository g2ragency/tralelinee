<?php
/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/widgets/wgl-cases.php`.
 */
namespace WGL_Extensions\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{Group_Control_Css_Filter,
    Group_Control_Typography,
    Icons_Manager,
    Widget_Base,
    Controls_Manager,
    Group_Control_Border,
    Group_Control_Box_Shadow,
    Group_Control_Background,
    Repeater,
    Utils};
use WGL_Extensions\Includes\{
    WGL_Carousel_Settings,
	WGL_Icons
};
use WGL_Extensions\WGL_Framework_Global_Variables as WGL_Globals;

class WGL_Cases extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-cases';
    }

    public function get_title()
    {
        return esc_html__('WGL Cases', 'motto-core');
    }

    public function get_icon()
    {
        return 'wgl-services-2';
    }

    public function get_keywords()
    {
        return [ 'cases', 'services' ];
    }

    public function get_script_depends()
    {
        return ['wgl-widgets', 'swiper'];
    }

    public function get_categories()
    {
        return ['wgl-modules'];
    }

    protected function register_controls()
    {
        /**
         * CONTENT -> GENERAL
         */

        $this->start_controls_section(
            'section_content_general',
            ['label' => esc_html__('General', 'motto-core')]
        );

	    $this->add_responsive_control(
		    'item_grid',
		    [
			    'label' => esc_html__('Grid Columns Amount', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'render_type' => 'template',
			    'range' => [
				    'px' => ['min' => 1, 'max' => 6 ],
			    ],
			    'size_units' => ['px'],
			    'default' => ['size' => 3],
			    'tablet_default' => ['size' => 2],
			    'mobile_default' => ['size' => 1],
			    'selectors' => [
				    '{{WRAPPER}} .case_items.swiper-slide' => 'width: calc(100% / {{SIZE}});',
				    '{{WRAPPER}} .wgl-cases:not([data-carousel="yes"])' => 'grid-template-columns: repeat({{SIZE}}, 1fr);',
			    ],
			    'label_block' => true,
		    ]
	    );

	    $this->add_responsive_control(
		    'item_gap',
		    [
			    'label' => esc_html__('Grid Gap', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'range' => [
				    'px' => ['min' => 0, 'max' => 100 ],
			    ],
			    'size_units' => ['px'],
                'label_block' => true,
			    'default' => ['size' => 30],
			    'tablet_default' => ['size' => 30],
			    'mobile_default' => ['size' => 20],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-cases:not([data-carousel="yes"])' => 'gap: {{SIZE}}px;',
                    '{{WRAPPER}} .wgl-cases[data-carousel="yes"] .case_items' => 'padding: calc({{SIZE}}px * 0.5);',
                    '{{WRAPPER}} .wgl-cases[data-carousel="yes"]' => 'margin: calc({{SIZE}}px * -0.5);',
                    '{{WRAPPER}} .wgl-cases[data-carousel="yes"] .swiper-pagination' => 'margin-bottom: calc({{SIZE}}px * 0.5);',
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'items_height',
            [
                'label' => esc_html__('Module Minimum Height', 'motto-core'),
                'type' => Controls_Manager::NUMBER,
			    'dynamic' => [  'active' => true],
                'min' => 150,
                'step' => 10,
                'selectors' => [
                    '{{WRAPPER}} .case_items__inner_wrapper' => 'min-height: {{VALUE}}px;',
                ],
            ]
        );

        $this->add_control(
            'items_v_alignment',
            [
                'label' => esc_html__('Vertical Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'label_block' => true,
                'toggle' => false,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Top', 'motto-core'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Middle', 'motto-core'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Bottom', 'motto-core'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .case_items__inner_wrapper' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
		    'item_grid_refresh',
		    [
			    'type' => Controls_Manager::HIDDEN,
			    'condition' => ['use_carousel!' => ''],
			    'render_type' => 'template',
		    ]
	    );

        $extra_controls[ 'img_size_string' ] = [
            'label' => esc_html__( 'Image Size', 'motto-core' ),
            'type' => Controls_Manager::SELECT,
            'condition' => [
                'icon_type' => 'image',
            ],
            'options' => [
                '150' => esc_html__('Thumbnail - 150x150', 'motto-core'),
                '300' => esc_html__('Medium - 300x300', 'motto-core'),
                '768' => esc_html__('Medium Large - 768x768', 'motto-core'),
                '1024' => esc_html__('Large - 1024x1024', 'motto-core'),
                '680x680' => esc_html__('680x680 - 3 Columns', 'motto-core'),
                'full' => esc_html__('Full', 'motto-core'),
                'custom' => esc_html__('Custom', 'motto-core'),
            ],
            'default' => 'full',
        ];

        $extra_controls[ 'img_size_array' ] = [
            'label' => esc_html__( 'Image Dimension', 'motto-core' ),
            'type' => Controls_Manager::IMAGE_DIMENSIONS,
            'condition' => [
                'img_size_string' => 'custom',
                'icon_type' => 'image',
            ],
            'description' => esc_html__( 'Crop the original image to any custom size. You can also set a single value for width to keep the initial ratio.', 'motto-core' ),
        ];

        $extra_controls[ 'img_aspect_ratio' ] = [
            'label' => esc_html__( 'Image Aspect Ratio', 'motto-core' ),
            'type' => Controls_Manager::SELECT,
            'condition' => [
                'img_size_string!' => 'custom',
                'icon_type' => 'image',
            ],
            'options' => [
                '' => esc_html__( 'No Crop', 'motto-core' ),
                '1:1' => esc_html( '1:1' ),
                '3:2' => esc_html( '3:2' ),
                '4:3' => esc_html( '4:3' ),
                '6:5' => esc_html( '6:5' ),
                '9:16' => esc_html( '9:16' ),
                '16:9' => esc_html( '16:9' ),
                '21:9' => esc_html( '21:9' ),
            ],
            'default' => '',
        ];

	    $repeater = new Repeater();


        $repeater->start_controls_tabs('tabs_items');

        // Tab Content
        $repeater->start_controls_tab(
            'tab_item_content',
            ['label' => esc_html__('Content', 'motto-core')]
        );
        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Add Link', 'motto-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr__( 'https://your-link.com', 'motto-core' ),
                'default' => [ 'url' => '#' ],
            ]
        );
        $repeater->add_control(
            'read_more_text',
            [
                'label' => esc_html__('Button Text', 'motto-core'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr_x( 'ex: Read More', 'WGL Cases', 'motto-core' ),
                'default' => esc_attr_x( 'BUTTON TITLE', 'WGL Cases', 'motto-core' ),
            ]
        );
        $repeater->add_control(
            'case_title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr_x( 'ex: Polishing of Hull', 'WGL Cases', 'motto-core' ),
            ]
        );
        $repeater->add_control(
            'case_bg_text',
            [
                'label' => esc_html__('Background Text', 'motto-core'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr_x( 'Case', 'WGL Cases', 'motto-core' ),
            ]
        );
        $repeater->add_control(
            'case_content',
            [
                'label' => esc_html__('Content', 'motto-core'),
                'type' => Controls_Manager::WYSIWYG,
                'dynamic' => [  'active' => true],
                'placeholder' => esc_attr__('Description Text', 'motto-core'),
                'label_block' => true,
            ]
        );
        $repeater->end_controls_tab();

        // Tab Image
        $repeater->start_controls_tab(
            'tab_item_image',
            ['label' => esc_html__('Image', 'motto-core')]
        );
        WGL_Icons::init(
            $repeater,
            [
                'section' => false,
                'output' => $extra_controls,
                'use_group_control_image_size' => ! ( $extra_controls[ 'img_size_string' ] ?? null ),
                'media_types_options' => [
                    '' => [
                        'title' => esc_html__('None', 'motto-core'),
                        'icon' => 'eicon-ban',
                    ],
                    'image' => [
                        'title' => esc_html__('Image', 'motto-core'),
                        'icon' => 'far fa-image',
                    ],
                ],
                'prefix' => 'image_',
                'default' => [
                    'media_type' => 'image',
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $repeater->add_responsive_control(
            'thumbnail_width',
            [
                'label' => esc_html__('Image Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 10, 'max' => 500 ],
                    '%' => ['min' => 10, 'max' => 100 ],
                ],
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}.case_items img,
				     {{WRAPPER}} {{CURRENT_ITEM}}.case_items .image_wrapper' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'label_block' => true,
            ]
        );
        $repeater->end_controls_tab();

        // Tab Icon
        $repeater->start_controls_tab(
            'tab_item_icon',
            ['label' => esc_html__('Icon', 'motto-core')]
        );
        WGL_Icons::init(
            $repeater,
            [
                'output' => '',
                'section' => false,
                'media_types_options' => [
                    '' => [
                        'title' => esc_html__('None', 'motto-core'),
                        'icon' => 'eicon-ban',
                    ],
                    'font' => [
                        'title' => esc_html__('Icon', 'motto-core'),
                        'icon' => 'far fa-smile',
                    ],
                ],
                'prefix' => 'icon_'
            ]
        );

        $repeater->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__('Icon Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 6, 'max' => 300],
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .icon_wrapper .elementor-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $repeater->add_control(
            'icon_rotate',
            [
                'label' => esc_html__('Icon Rotate', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .icon_wrapper .elementor-icon' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );
        $repeater->add_responsive_control(
            'icon_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'separator' => 'before',
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .icon_wrapper .elementor-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $repeater->add_control(
            'icon_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .icon_wrapper .elementor-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $repeater->end_controls_tab();

        // Tab Background
        $repeater->start_controls_tab(
            'tab_item_background',
            ['label' => esc_html__('Background', 'motto-core')]
        );
        $repeater->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'tab_item_background',
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .case_items__inner_wrapper',
            ]
        );
        $repeater->end_controls_tab();
        $repeater->end_controls_tabs();

        $this->add_control(
            'list',
            [
                'label' => esc_html__('Items', 'motto-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [ 'read_more_text' => esc_html__('Button Title 1', 'motto-core') ],
                    [ 'read_more_text' => esc_html__('Button Title 2', 'motto-core') ],
                    [ 'read_more_text' => esc_html__('Button Title 3', 'motto-core') ],
                ],
                'title_field' => '{{{ read_more_text }}}',
            ]
        );

        $this->add_responsive_control(
            'alignment',
            [
                'label' => esc_html__('General Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => true,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .case_items__inner_wrapper' => 'text-align: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'chess_layout',
		    [
			    'label' => esc_html__('Chess Layout', 'motto-core'),
			    'type' => Controls_Manager::SWITCHER,
			    'separator' => 'before',
			    'return_value' => 'chess',
			    'prefix_class' => 'layout-',
		    ]
	    );

	    $this->add_control(
		    'chess_layout_invert',
		    [
			    'label' => esc_html__('Invert Chess Layout', 'motto-core'),
			    'type' => Controls_Manager::SWITCHER,
			    'condition' => ['chess_layout!' => ''],
			    'return_value' => 'chess',
			    'prefix_class' => 'invert-',
		    ]
	    );

	    $this->add_responsive_control(
		    'chess_offset',
		    [
			    'label' => esc_html__('Chess Offset', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'condition' => ['chess_layout!' => ''],
			    'size_units' => ['px', 'rem'],
			    'range' => [
				    'px' => ['min' => 1, 'max' => 300],
				    'rem' => ['min' => 0.1, 'max' => 20, 'step' => 0.1],
			    ],
			    'default' => ['size' => 60],
			    'tablet_default' => ['size' => 30],
			    'mobile_default' => ['size' => 0],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-cases:not([data-carousel="yes"]),
				     {{WRAPPER}} .wgl-cases[data-carousel="yes"] .swiper-container' => 'padding-top: {{SIZE}}{{UNIT}} !important;',
				    '{{WRAPPER}}:not(.invert-chess) .case_items:nth-child(even)' => 'margin-top: -{{SIZE}}{{UNIT}};',
				    '{{WRAPPER}}.invert-chess .case_items:nth-child(odd)' => 'margin-top: -{{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'chess_notice',
		    [
			    'type' => Controls_Manager::RAW_HTML,
			    'condition' => [ 'chess_layout!' => '' ],
			    'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			    'raw' => esc_html__('Note: even number of Case Items is preffered.', 'motto-core'),
		    ]
	    );

	    $this->end_controls_section();

        /**
         * CONTENT -> LINK
         */

        $this->start_controls_section(
            'section_content_link',
            [
                'label' => esc_html__('Link', 'motto-core'),
            ]
        );
        $this->add_control(
            'module_link',
            [
                'label' => esc_html__('Whole Module Link', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'add_read_more',
            [
                'label' => esc_html__('\'Read More\' Button', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Use', 'motto-core'),
                'label_off' => esc_html__('Hide', 'motto-core'),
                'default' => 'yes'
            ]
        );
        $this->add_control(
            'button_type',
            [
                'label' => esc_html__( 'Button Type', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'style_transfer' => true,
                'options' => [
                    'wgl-button' => esc_html__( 'Default Button Style', 'motto-core' ),
                    'button-read-more' => esc_html__( 'Read More Style', 'motto-core' ),
                ],
                'condition' => [ 'add_read_more' => 'yes' ],
                'default' => 'wgl-button',
            ]
        );
        $this->add_control(
            'read_more_icon_fontawesome',
            [
                'label' => esc_html__('Button Icon', 'motto-core'),
                'type' => Controls_Manager::ICONS,
                'condition' => [ 'add_read_more' => 'yes' ],
                'description' => esc_html__('Select icon from available libraries.', 'motto-core'),
                'label_block' => true,
                'default' => [
                    'library' => 'flaticon',
                    'value' => 'flaticon flaticon-down-right-arrow'
                ],
            ]
        );
        $this->add_control(
            'read_more_icon_align',
            [
                'label' => esc_html__( 'Position', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'options' => [
                    'row' => esc_html__( 'Before', 'motto-core' ),
                    'row-reverse' => esc_html__( 'After', 'motto-core' ),
                ],
                'default' => 'row-reverse',
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'read_more_icon_indent',
            [
                'label' => esc_html__( 'Icon/Image Offset', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'range' => [
                    'px' => [ 'max' => 250 ],
                ],
                'default' => [ 'size' => 11 ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button' => 'gap: {{SIZE}}{{UNIT}}; --wgl-gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_icon_top',
            [
                'label' => esc_html__('Icon Top Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 300],
                ],
                'condition' => [
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button .read-more-icon' => 'top: {{SIZE}}{{UNIT}}; --icon-translate-y: {{SIZE}}{{UNIT}};',

                ],
            ]
        );
        $this->add_responsive_control(
            'button_icon_size',
            [
                'label' => esc_html__('Icon Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 6, 'max' => 300],
                ],
                'condition' => [
                    'read_more_icon_fontawesome[value]!' => '',
                ],
                'default' => [ 'size' => 30, 'unit' => 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button .read-more-icon,
                     {{WRAPPER}} .wgl-cases__button .read-more-icon svg' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_icon_stroke_size',
            [
                'label' => esc_html__('SVG Stroke Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 300],
                ],
                'condition' => [ 'read_more_icon_fontawesome[library]' => 'svg' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button .read-more-icon path' => 'stroke-width: {{SIZE}}{{UNIT}};'
                ],
            ]
        );
	    $this->end_controls_section();

        /**
         * CONTENT -> CAROUSEL OPTIONS
         */

        WGL_Carousel_Settings::add_controls($this);

        /**
         * STYLES -> ITEMS
         */

        $this->start_controls_section(
            'section_style_items',
            [
                'label' => esc_html__('Items', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'items_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .case_items__inner_wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'items_border_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .case_items__inner_wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'items_z_index',
            [
                'label' => __( 'Z-Index', 'motto-core' ),
                'type' => Controls_Manager::NUMBER,
			    'dynamic' => [  'active' => true],
                'min' => -5,
                'default' => 1,
                'selectors' => [
                    '{{WRAPPER}} .case_items' => 'z-index: {{VALUE}}; position: relative',
                ],
            ]
        );
        $this->start_controls_tabs( 'tabs_items' );
        $this->start_controls_tab(
            'tab_item_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_bg_idle',
                'types' => ['classic', 'gradient'],
                'fields_options' => [
                    'color' => [
                        'label' => esc_html__( 'Background Color', 'motto-core' ),
                    ],
                    'image' => [
                        'label' => esc_html__( 'Background Image', 'motto-core' ),
                    ],
                ],
                'selector' => '{{WRAPPER}} .case_items__inner_wrapper',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_shadow_idle',
                'selector' => '{{WRAPPER}} .case_items__inner_wrapper',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_border_idle',
                'selector' => '{{WRAPPER}} .case_items__inner_wrapper',
            ]
        );
        $this->add_control(
            'item_blur_idle',
            [
                'label' => esc_html__('Blur', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 30, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .case_items__inner_wrapper::after' => 'backdrop-filter: blur({{SIZE}}px);-webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_item_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_bg_hover',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .case_items__inner_wrapper:hover',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_shadow_hover',
                'selector' => '{{WRAPPER}} .case_items__inner_wrapper:hover',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_border_hover',
                'selector' => '{{WRAPPER}} .case_items__inner_wrapper:hover',
            ]
        );
        $this->add_control(
            'item_blur_hover',
            [
                'label' => esc_html__('Blur', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 30, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .case_items__inner_wrapper:hover::after' => 'backdrop-filter: blur({{SIZE}}px);-webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->add_control(
            'item_transition',
            [
                'label' => esc_html__('Transition Duration', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['s'],
                'range' => [
                    's' => ['min' => 0, 'max' => 2, 'step' => 0.1 ],
                ],
                'default' => ['size' => 0.4, 'unit' => 's'],
                'selectors' => [
                    '{{WRAPPER}} .case_items__inner_wrapper' => 'transition: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> TITLE
         */

        $this->start_controls_section(
            'style_title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_title',
                'selector' => '{{WRAPPER}} .case_title',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML Tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'div' => esc_html('‹div›'),
                    'span' => esc_html('‹span›'),
                ],
                'default' => 'h3',
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .case_title__wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .case_title__wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->start_controls_tabs(
            'titles_tabs',
        );
        $this->start_controls_tab(
            'title_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'title_color_idle',
            [
                'label' => esc_html__('Title Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .case_title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'title_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'title_color_hover',
            [
                'label' => esc_html__('Title Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .case_title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> BG TEXT
         */

        $this->start_controls_section(
            'style_bg_text',
            [
                'label' => esc_html__('BG Text', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_bg_text',
                'selector' => '{{WRAPPER}} .case_bg_text',
            ]
        );

        $this->add_responsive_control(
            'bg_text_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '0',
                    'right' => '-300',
                    'bottom' => '-100',
                    'left' => '-300',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .case_bg_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bg_text_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .case_bg_text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->start_controls_tabs(
            'bg_text_tabs',
        );
        $this->start_controls_tab(
            'bg_text_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'bg_text_color_idle',
            [
                'label' => esc_html__('Background Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(0.3),
                'selectors' => [
                    '{{WRAPPER}} .case_bg_text' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'bg_text_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'bg_text_color_hover',
            [
                'label' => esc_html__('Background Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .case_bg_text' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> CONTENT
         */

        $this->start_controls_section(
            'style_content',
            [
                'label' => esc_html__('Content', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_content',
                'selector' => '{{WRAPPER}} .case_content__wrapper',
            ]
        );

        $this->add_responsive_control(
            'content_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .case_content__wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .case_content__wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->start_controls_tabs(
            'contents_tabs',
        );
        $this->start_controls_tab(
            'content_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'content_color_idle',
            [
                'label' => esc_html__('Content Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .case_content__wrapper' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'content_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'content_color_hover',
            [
                'label' => esc_html__('Content Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .case_content__wrapper' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLES -> IMAGE
         */

        $this->start_controls_section(
            'section_style_images',
            [
                'label' => esc_html__('Image', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

	    $this->add_responsive_control(
		    'thumbnail_width',
		    [
			    'label' => esc_html__('Image Width', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'range' => [
				    'px' => ['min' => 10, 'max' => 500 ],
				    '%' => ['min' => 10, 'max' => 100 ],
			    ],
			    'size_units' => ['px', '%', 'custom'],
			    'label_block' => true,
                'default' => ['size' => 100, 'unit' => '%'],
                'selectors' => [
                    '{{WRAPPER}} .case_items .wgl-image-box_img img' => 'width: {{SIZE}}{{UNIT}}; --image-width: {{SIZE}};',
                ],
		    ]
	    );
        $this->add_responsive_control(
            'thumbnail_width_hover',
            [
                'label' => esc_html__( 'Image Width on Hover', 'motto-core' ),
                'description' => esc_html__( 'Important: Use only the <b>Same Size Units</b>', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'custom' ],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 768 ],
                ],
                'condition' => [ 'thumbnail_width[size]!' => '' ],
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .wgl-image-box_img img' => 'transform: scale( calc( {{SIZE}} / var(--image-width) ) );',
                ],
            ]
        );
        $this->add_responsive_control(
            'image_z_index',
            [
                'label' => __( 'Z-Index', 'motto-core' ),
                'type' => Controls_Manager::NUMBER,
			    'dynamic' => [  'active' => true],
                'min' => -5,
                'default' => 1,
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper ' => 'z-index: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'thumbnail_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '37',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'thumbnail_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper img,
                     {{WRAPPER}} .image_wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'thumbnail_icon_show_over_image',
            [
                'label' => esc_html__('Show Icon/Text over Image', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Use', 'motto-core'),
                'label_off' => esc_html__('Hide', 'motto-core'),
			    'separator' => 'before',
                'default' => 'yes',
            ]
        );

        $this->start_controls_tabs('thumbnail_tabs');
        $this->start_controls_tab(
            'thumbnail_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'thumbnail_css_filters_idle',
                'selector' => '{{WRAPPER}} .image_wrapper img',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'thumbnail_shadow_idle',
                'selector' => '{{WRAPPER}} .image_wrapper .wgl-image-box_img',
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'thumbnail_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'thumbnail_css_filters_hover',
                'selector' => '{{WRAPPER}} .case_items:hover .image_wrapper img',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'thumbnail_shadow_hover',
                'selector' => '{{WRAPPER}} .case_items:hover .image_wrapper .wgl-image-box_img',
            ]
        );
        $this->add_control(
            'thumbnail_transition',
            [
                'label' => esc_html__('Transition Duration', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['s'],
                'range' => [
                    's' => ['min' => 0, 'max' => 2, 'step' => 0.1 ],
                ],
                'default' => ['size' => 0.6, 'unit' => 's'],
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper img' => 'transition: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> ICON OVER IMAGE
         */

        $this->start_controls_section(
            'style_icon_over_image',
            [
                'label' => esc_html__('Icon/Text Over Image', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'thumbnail_icon_show_over_image' => 'yes' ],
            ]
        );
        $this->add_responsive_control(
            'text_over_image_width',
            [
                'label' => esc_html__('Wrapper Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px','em','rem'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 100, 'step' => 1 ],
                ],
                'default' => ['size' => 100, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper .wgl-icon' => 'min-width: {{SIZE}}px; min-height: {{SIZE}}px;',
                ],
            ]
        );
        $this->add_control(
            'text_over_image',
            [
                'label' => esc_html__('Text Over Image', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => esc_attr_x( 'MORE', 'WGL Cases', 'motto-core' ),
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'text_over_image_fonts',
                'condition' => [ 'text_over_image!' => '' ],
                'selector' => '{{WRAPPER}} .wgl-text_over_image',
            ]
        );

        $this->add_control(
            'thumbnail_icon',
            [
                'label' => esc_html__('Icon', 'motto-core'),
                'type' => Controls_Manager::ICONS,
                'description' => esc_html__('Select icon from available libraries.', 'motto-core'),
                'label_block' => true,
            ]
        );

        $this->add_responsive_control(
            'thumbnail_icon_size',
            [
                'label' => esc_html__('Icon Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px','em','rem'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 100, 'step' => 1 ],
                ],
                'condition' => [ 'thumbnail_icon[value]!' => '' ],
                'default' => ['size' => 20, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper .wgl-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'thumbnail_icon_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '22',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'unit' => 'px',
                    'isLinked' => true
                ],
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper .wgl-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'thumbnail_icon_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '100',
                    'right' => '100',
                    'bottom' => '100',
                    'left' => '100',
                    'unit' => 'px',
                    'isLinked' => true
                ],
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper .wgl-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('thumbnail_icons');
        $this->start_controls_tab(
            'thumbnail_icon_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'thumbnail_text_color_idle',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => 'transparent',
                'condition' => [ 'text_over_image!' => '' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-text_over_image' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'thumbnail_icon_color_idle',
            [
                'label' => esc_html__('Icon Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => 'transparent',
                'condition' => [ 'thumbnail_icon[value]!' => '' ],
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper .wgl-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'thumbnail_icon_bg_color_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(0),
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper .wgl-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'thumbnail_icon_shadow_idle',
                'selector' => '{{WRAPPER}} .image_wrapper .wgl-icon',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'thumbnail_icon_border_idle',
                'selector' => '{{WRAPPER}} .image_wrapper .wgl-icon',
            ]
        );
        $this->add_control(
            'thumbnail_icon_blur_idle',
            [
                'label' => esc_html__('Blur', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 30, 'step' => 0.5],
                ],
                'default' => ['size' => 0, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .image_wrapper .wgl-icon' => 'backdrop-filter: blur({{SIZE}}px);-webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'thumbnail_icon_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'thumbnail_text_color_hover',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => '#ffffff',
                'condition' => [ 'text_over_image!' => '' ],
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .wgl-text_over_image' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'thumbnail_icon_color_case_button__hover',
            [
                'label' => esc_html__('Icon Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'thumbnail_icon[value]!' => '' ],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .image_wrapper .wgl-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'thumbnail_icon_bg_color_case_button__hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(1),
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .image_wrapper .wgl-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'thumbnail_icon_shadow_case_button__hover',
                'selector' => '{{WRAPPER}} .case_items:hover .image_wrapper .wgl-icon',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'thumbnail_icon_border_case_button__hover',
                'selector' => '{{WRAPPER}} .case_items:hover .image_wrapper .wgl-icon',
            ]
        );
        $this->add_control(
            'thumbnail_icon_blur_case_button__hover',
            [
                'label' => esc_html__('Blur', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 30, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .image_wrapper .wgl-icon' => 'backdrop-filter: blur({{SIZE}}px);-webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> ICON
         */

        $this->start_controls_section(
            'style_icon',
            [
                'label' => esc_html__('Icon', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'icons_size',
            [
                'label' => esc_html__('Font Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => ['min' => 6, 'max' => 300],
                ],
                'default' => ['size' => 53],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icons_rotate',
            [
                'label' => esc_html__('Icon Rotate', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['deg', 'turn'],
                'range' => [
                    'deg' => ['max' => 360],
                    'turn' => ['min' => 0, 'max' => 1, 'step' => 0.1],
                ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );
        $this->add_responsive_control(
            'icons_z_index',
            [
                'label' => __( 'Z-Index', 'motto-core' ),
                'type' => Controls_Manager::NUMBER,
			    'dynamic' => [  'active' => true],
                'min' => -5,
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper ' => 'z-index: {{VALUE}}; position: relative;',
                ],
            ]
        );
        $this->add_control(
            'icons_bubble',
            [
                'label' => esc_html__('Show Bubble for Icon', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon::after' => 'display: block;',
                ],
            ]
        );
        $this->add_responsive_control(
            'icons_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'separator' => 'before',
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '19',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icons_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'icons_border',
                'fields_options' => [
                    'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                    'color' => [ 'type' => Controls_Manager::HIDDEN ],
                ],
                'selector' => '{{WRAPPER}} .icon_wrapper .elementor-icon',
            ]
        );
        $this->add_responsive_control(
            'icons_border_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'tabs_icons',
            ['separator' => 'before']
        );

        $this->start_controls_tab(
            'tab_icons_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'icon_colors_idle',
            [
                'label' => esc_html__('Icon Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(),
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icons_bg_idle',
            [
                'label' => esc_html__('Icon Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icons_border_color_idle',
            [
                'label' => esc_html__('Icon Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'icon_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icons_idle',
                'selector' => '{{WRAPPER}} .icon_wrapper .elementor-icon',
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_icons_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'icons_color_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .icon_wrapper .elementor-icon' => 'fill: {{VALUE}}; color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icons_bg_hover',
            [
                'label' => esc_html__('Icon Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .icon_wrapper .elementor-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icons_border_color_hover',
            [
                'label' => esc_html__('Icon Border Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'icon_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .icon_wrapper .elementor-icon' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icons_hover',
                'selector' => '{{WRAPPER}} .case_items:hover .icon_wrapper .elementor-icon',
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> Bubble
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_bubble',
            [
                'label' => esc_html__('Bubble', 'motto-core'),
                'condition' => [ 'icons_bubble!' => '' ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'bubble_top_offset',
            [
                'label' => esc_html__('Top Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -200, 'max' => 200],
                    'px' => ['min' => -200, 'max' => 1000, 'step' => 1],
                ],
                'default' => ['size' => 61, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon::after' => '--bubble-top: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'bubble_left_offset',
            [
                'label' => esc_html__('Left Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -200, 'max' => 200],
                    'px' => ['min' => -200, 'max' => 1000, 'step' => 1],
                ],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon::after' => '--bubble-left: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'bubble_size',
            [
                'label' => esc_html__('Bubble Diameter', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', 'custom' ],
                'range' => [
                    'px' => ['max' => 700],
                ],
                'default' => ['size' => 230, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'icon_animation',
            [
                'label' => esc_html__('Bubble Animation', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'motto-core'),
                'label_off' => esc_html__('Off', 'motto-core'),
                'return_value' => 'bubble',
                'prefix_class' => 'animation_',
            ]
        );
        $this->add_responsive_control(
            'bubble_animation_top_offset',
            [
                'label' => esc_html__('Top Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 100],
                    'px' => ['min' => -200, 'max' => 1000, 'step' => 1],
                ],
                'condition' => [ 'icon_animation' => 'bubble' ],
                'default' => ['size' => 40, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .icon_wrapper .elementor-icon::after' => '--bubble-top: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'bubble_animation_left_offset',
            [
                'label' => esc_html__('Left Offset', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['%', 'px', 'custom'],
                'range' => [
                    '%' => ['min' => -100, 'max' => 100],
                    'px' => ['min' => -200, 'max' => 1000, 'step' => 1],
                ],
                'condition' => [ 'icon_animation' => 'bubble' ],
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .icon_wrapper .elementor-icon::after' => '--bubble-left: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'bubble_animation_size',
            [
                'label' => esc_html__('Bubble Diameter', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => [ 'px', 'custom' ],
                'range' => [
                    'px' => ['max' => 700],
                ],
                'condition' => [ 'icon_animation' => 'bubble' ],
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .icon_wrapper .elementor-icon::after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->start_controls_tabs( 'tabs_bubble_styles' );
        $this->start_controls_tab(
            'tab_bubble_idle',
            [ 'label' => esc_html__('Idle', 'motto-core') ]
        );
        $this->add_control(
            'bubble_bg_idle',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .icon_wrapper .elementor-icon::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_bubble_hover',
            [ 'label' => esc_html__('Hover', 'motto-core') ]
        );
        $this->add_control(
            'bubble_bg_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .case_items:hover .icon_wrapper .elementor-icon::after' => 'background-color: {{VALUE}};'
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
	     * STYLE -> BUTTON
	     */

	    $this->start_controls_section(
		    'section_style_button',
		    [
			    'label' => esc_html__('Button', 'motto-core'),
			    'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'add_read_more' => 'yes' ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
			    'name' => 'button_custom_fonts',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => ['default' => ['size' => 32]],
                    'text_decoration' => ['default' => 'underline'],
                ],
			    'selector' => '{{WRAPPER}} .wgl-cases__button',
		    ]
	    );
        $this->add_responsive_control(
            'button_decoration_line_size',
            [
                'label' => esc_html__('Decoration Line Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'button_custom_fonts_text_decoration' => ['line-through', 'overline', 'underline'] ],
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 20, 'step' => 1],
                    'em' => ['min' => 0, 'max' => 1, 'step' => 0.05],
                ],
                'default' => ['size' => 0.05, 'unit' => 'em'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button' => 'text-decoration-thickness: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_underline_offset',
            [
                'label' => esc_html__('Underline Offset Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'button_custom_fonts_text_decoration' => 'underline' ],
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => ['min' => -20, 'max' => 20, 'step' => 1],
                    'em' => ['min' => -1, 'max' => 1, 'step' => 0.05],
                ],
                'default' => ['size' => 0.1, 'unit' => 'em'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button' => 'text-underline-offset: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
	    $this->add_responsive_control(
		    'button_margin',
		    [
			    'label' => esc_html__('Margin', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'custom'],
			    'default' => [
				    'top' => '7',
				    'right' => '0',
				    'bottom' => '0',
				    'left' => '0',
				    'unit'  => 'px',
				    'isLinked' => false
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .case_button__wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'button_padding',
		    [
			    'label' => esc_html__('Padding', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%', 'custom'],
			    'selectors' => [
				    '{{WRAPPER}} .case_button__wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'button_inner_padding',
		    [
			    'label' => esc_html__('Inner Padding', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false
                ],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-cases__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'button_radius',
		    [
			    'label' => esc_html__('Border Radius', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => true
                ],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-cases__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_group_control(
		    Group_Control_Border::get_type(),
		    [
			    'name' => 'button_border',
			    'render_type' => 'template',
			    'dynamic' => [  'active' => true],
			    'fields_options' => [
                    'border' => [ 'default' => 'none' ],
				    'color' => ['type' => Controls_Manager::HIDDEN],
			    ],
			    'selector' => '{{WRAPPER}} .wgl-cases__button',
		    ]
	    );

        $this->add_control(
            'read_more_button_width',
            [
                'label' => esc_html__( 'Button Min-Width', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'rem', '%', 'custom'],
                'range' => [
                    'px' => ['max' => 500],
                    '%' => ['max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_alignment',
            [
                'label' => esc_html__('Button Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => true,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__('Justify', 'motto-core'),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'default' => 'justify',
                'prefix_class' => 'button_',
            ]
        );
        $this->add_control(
            'button_width_alignment',
            [
                'label' => esc_html__('Additional Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => true,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__('Justify', 'motto-core'),
                        'icon' => 'eicon-text-align-justify',
                    ],
                    'space-between' => [
                        'title' => esc_html__( 'Space Between', 'motto-core' ),
                        'icon' => 'eicon-justify-space-between-h',
                    ],
                ],
                'default' => 'space-between',
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button' => 'justify-content: {{VALUE}};',
                ],
            ]
        );
        $this->start_controls_tabs( 'tabs_button' );
	    $this->start_controls_tab(
		    'tab_button_idle',
		    ['label' => esc_html__('Idle', 'motto-core')]
	    );
	    $this->add_control(
		    'button_color_idle',
		    [
			    'label' => esc_html__('Text Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_h_font_color(),
			    'selectors' => [
				    '{{WRAPPER}} .wgl-cases__button' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'button_bg_idle',
		    [
			    'label' => esc_html__('Background Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(0),
			    'selectors' => [
				    '{{WRAPPER}} .wgl-cases__button' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );
        $this->add_control(
            'button_decoration_color_idle',
            [
                'label' => esc_html__('Decoration Line Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'button_custom_fonts_text_decoration' => ['line-through', 'overline', 'underline'] ],
                'default' => WGL_Globals::get_h_font_color(0),
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button' => 'text-decoration-color: {{VALUE}};',
                ],
            ]
        );
	    $this->add_control(
		    'button_icon_color_idle',
		    [
			    'label' => esc_html__('Icon Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(),
			    'selectors' => [
				    '{{WRAPPER}} .read-more-icon' => 'color: {{VALUE}}'
			    ],
		    ]
	    );
	    $this->add_control(
		    'button_border_color_idle',
		    [
			    'label' => esc_html__('Border Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => [ 'button_border_border!' => ['', 'none'] ],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-cases__button' => 'border-color: {{VALUE}};',
			    ],
		    ]
	    );
        $this->add_control(
            'button_icon_rotation_idle',
            [
                'label' => esc_html__( 'Icon Rotate', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'deg' => [ 'min' => -360, 'max' => 360 ],
                    'turn' => ['min' => -1, 'max' => 1, 'step' => 0.1],
                ],
                'default' => [ 'size' => -90, 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .read-more-icon' => '--icon-rotate: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
	    $this->end_controls_tab();
	    $this->start_controls_tab(
		    'tab_button_hover',
		    ['label' => esc_html__('Hover', 'motto-core')]
	    );

	    $this->add_control(
		    'button_color_hover',
		    [
			    'label' => esc_html__('Text Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-cases__button:hover,
				     {{WRAPPER}} .wgl-cases__link:hover ~ .case_button__wrapper .wgl-cases__button' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_bg_hover',
		    [
			    'label' => esc_html__('Background Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-cases__button:hover,
                     {{WRAPPER}} .wgl-cases__link:hover ~ .case_button__wrapper .wgl-cases__button' => 'background-color: {{VALUE}}',
			    ],
		    ]
	    );
        $this->add_control(
            'button_decoration_color_hover',
            [
                'label' => esc_html__('Decoration Line Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'button_custom_fonts_text_decoration' => ['line-through', 'overline', 'underline'] ],
                'default' => WGL_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button:hover span,
				     {{WRAPPER}} .wgl-cases__link:hover ~ .case_button__wrapper .wgl-cases__button span' => 'text-decoration-color: {{VALUE}};',
                ],
            ]
        );
	    $this->add_control(
		    'button_icon_color_hover',
		    [
			    'label' => esc_html__('Icon Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'default' => WGL_Globals::get_primary_color(),
			    'selectors' => [
                    '{{WRAPPER}} .read-more-icon' => 'transition: inherit;',
                    '{{WRAPPER}} .wgl-cases__button:hover .read-more-icon,
                     {{WRAPPER}} .wgl-cases__link:hover ~ .case_button__wrapper .read-more-icon' => 'color: {{VALUE}}; fill: {{VALUE}}; transition: inherit;',
			    ],
		    ]
	    );

	    $this->add_control(
		    'button_border_color_hover',
		    [
			    'label' => esc_html__('Border Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'button_border_border!' => ['', 'none'] ],
			    'selectors' => [
				    '{{WRAPPER}} .wgl-cases__button:hover,
				     {{WRAPPER}} .wgl-cases__link:hover ~ .case_button__wrapper .wgl-cases__button' => 'border-color: {{VALUE}}'
			    ],
		    ]
	    );
        $this->add_control(
            'button_icon_rotation_hover',
            [
                'label' => esc_html__( 'Icon Rotate', 'motto-core' ),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'deg' => [ 'min' => -360, 'max' => 360 ],
                    'turn' => ['min' => -1, 'max' => 1, 'step' => 0.1],
                ],
                'default' => ['unit' => 'deg'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-cases__button:hover .read-more-icon,
				     {{WRAPPER}} .wgl-cases__link:hover ~ .case_button__wrapper .read-more-icon' => '--icon-rotate: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
	    $this->end_controls_tab();
	    $this->end_controls_tabs();
	    $this->end_controls_section();
    }

    protected function render()
    {
        $_s = $this->get_settings_for_display();

        $this->add_render_attribute(
            'wrapper',
            [
                'class' => [ 'wgl-cases' ],
                'data-carousel' => $_s['use_carousel']
            ]
        );

        // Render
        echo '<div ', $this->get_render_attribute_string('wrapper'), '>',
            $this->get_cases_html(),
        '</div>';
    }

    protected function get_cases_html()
    {
        $_s = $this->get_settings_for_display();

        // Icon
        $thumb_icon = '';
        if (!empty($_s['thumbnail_icon']['value']) || !empty($_s['text_over_image'])) {
            $thumb_icon = '<div class="media-wrapper icon-wrapper"><div class="wgl-icon">';
            if (!empty($_s['text_over_image'])) {
                $thumb_icon .= '<span class="wgl-text_over_image">' . $_s['text_over_image'] . '</span>';
            }
            if (!empty($_s['thumbnail_icon']['value'])) {
                if ('svg' === $_s['thumbnail_icon']['library']) {
                    $thumb_icon .= '<span class="icon elementor-icon">';
                }

                // Icon migration
                $migrated = isset($atts['__fa4_migrated']['thumbnail_icon']);
                $is_new = Icons_Manager::is_migration_allowed();
                if ($is_new || $migrated) {
                    ob_start();
                    Icons_Manager::render_icon($_s['thumbnail_icon'], ['class' => 'icon elementor-icon', 'aria-hidden' => 'true']);
                    $thumb_icon .= ob_get_clean();
                } else {
                    $thumb_icon .= '<i class="icon elementor-icon ' . esc_attr($_s['thumbnail_icon']['value']) . '"></i>';
                }

                if ('svg' === $_s['thumbnail_icon']['library']) {
                    $thumb_icon .= '</span>';
                }
            }
            $thumb_icon .= '</div></div>';
        }

        $content = $btn_icon = $link = '';
        foreach ($_s['list'] as $index => $item) {

            $has_link = !empty($item['link']['url']);
	        $btn = $this->get_repeater_setting_key('btn', 'list', $index);

	        // Image
	        $image = new WGL_Icons;
            $case_image = $image->build($this, $item, 'image_');

	        // Icon
	        $icon = new WGL_Icons;
            $case_icon = $icon->build($this, $item, 'icon_');

	        if ($has_link) {
                $link = $this->get_repeater_setting_key('link', 'list', $index);
                $this->add_link_attributes($link, $item['link']);
            }

            if ($_s['add_read_more']) {
                if ($_s['read_more_icon_fontawesome']['value']) {
                    $btn_icon = $this->get_repeater_setting_key('btn-icon', 'list', $index);
                    $migrated = isset($atts['__fa4_migrated']['read_more_icon_fontawesome']);
                    $is_new = Icons_Manager::is_migration_allowed();
                    if ($is_new || $migrated) {
                        $this->add_render_attribute(
                            [
                                $btn_icon => [
                                    'class' => [
                                        esc_attr($_s['read_more_icon_fontawesome']['value']),
                                        'read-more-icon',
                                    ],
                                ],
                            ]
                        );
                    }

                    $this->add_render_attribute($btn, 'class',
                        [
                            'wgl-cases__button',
                            $_s['button_type'] ?? '',
                            !$item['read_more_text'] ? 'no_text' : ''
                        ]
                    );
                } else {
                    $this->add_render_attribute([$btn => ['class'=> 'no_media']]);
                }

                $case_button = '<div class="case_button__wrapper">';
                $case_button .= sprintf(
                    '<%s %s %s>',
                    $_s['module_link'] || !$has_link ? 'div' : 'a',
                    $_s['module_link'] || !$has_link ? '' : $this->get_render_attribute_string($link),
                    $this->get_render_attribute_string($btn)
                );
                $case_button .= $btn_icon ? '<i ' . $this->get_render_attribute_string($btn_icon) . '></i>' : '';
                $case_button .= $item['read_more_text'] ? '<span>' . esc_html($item['read_more_text']) . '</span>' : '';
                $case_button .= $_s['module_link'] || !$has_link ? '</div>' : '</a>';
                $case_button .= '</div>';
            }

            // Content
            $title = '';
            if (!empty($item['case_title'])) {
                $title .= '<div class="case_title__wrapper">';
                    $title .= '<' . esc_attr($_s['title_tag']) . ' class="case_title">';
                        $title .= '<span>'.$item['case_title'].'</span>';
                    $title .= '</' . esc_attr($_s['title_tag']) . '>';
                $title .= '</div>';
            }

            $bg_text = '';
            if (!empty($item['case_bg_text'])) {
                $bg_text .= '<div class="case_bg_text">' . $item['case_bg_text'] . '</div>';
            }

            // Content
            $case_content = '';
            if (!empty($item['case_content'])) {
                $case_content .= '<div class="case_content__wrapper">';
                $case_content .= $item['case_content'];
                $case_content .= '</div>';
            }

            ob_start();

            echo '<div class="case_items elementor-repeater-item-'. $item['_id'] . (($_s['use_carousel']) ? ' swiper-slide' : '') .'">';
            echo '<div class="case_items__inner_wrapper">';
                if ($_s['module_link'] && $has_link) {
                    echo '<a class="wgl-cases__link" ' . $this->get_render_attribute_string($link) . '></a>';
                }

                if (!!$case_image || !!$thumb_icon) {
                    echo '<div class="image_wrapper">'
                        .$case_image
                        .$thumb_icon
                    .'</div>';
                }

                if (!!$case_icon) {
                    echo '<div class="icon_wrapper">'
                        .$case_icon
                    .'</div>';
                }

                echo $bg_text ?? '';

                echo $title ?? '';

                echo $case_content ?? '';

	            echo $case_button ?? '';

            echo '</div></div>';

            $content .= ob_get_clean();
        }

        return !$_s['use_carousel'] ? $content : $this->apply_carousel_settings($content);
    }

    protected function apply_carousel_settings($content)
    {
        $_s = $this->get_settings_for_display();

        $options = [
            'slides_per_row' => $_s['item_grid']['size'] ?? 4,
            'autoplay' => $_s['autoplay'],
            'slides_transition' => $_s['slides_transition'],
            'autoplay_speed' => $_s['autoplay_speed'],
            'fade_animation' => $_s['fade_animation'],
            'animation_style' => $_s['animation_style'],
            'animation_triggered_by_mouse' => $_s['animation_triggered_by_mouse'],
            'slider_infinite' => $_s['slider_infinite'],
            'adaptive_height' => $_s['adaptive_height'],
            'slide_per_single'  => $_s['slide_per_single'],
            'center_mode' => $_s['center_mode'],
            // Pagination
            'use_pagination' => $_s['use_pagination'],
            'pagination_type' => $_s['pagination_type'],
            'pagination_dynamic' => $_s['pagination_dynamic'],
            // Navigation
            'use_navigation' => $_s['use_navigation'],
            'navigation_position' => $_s['navigation_position'],
            // Responsive
            'customize_responsive' => $_s['customize_responsive'],
            'widescreen_breakpoint' => $_s['widescreen_breakpoint'],
            'widescreen_slides' => $_s['widescreen_slides'],
            'desktop_breakpoint' => $_s['desktop_breakpoint'],
            'desktop_slides' => $_s['desktop_slides'],
            'tablet_breakpoint' => $_s['tablet_breakpoint'],
            'tablet_slides' => $_s['tablet_slides'],
            'mobile_breakpoint' => $_s['mobile_breakpoint'],
            'mobile_slides' => $_s['mobile_slides'],
        ];

        return WGL_Carousel_Settings::init($options, $content);
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WGL_Extensions\Includes\WGL_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
