<?php
/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/templates/wgl-testimonials.php`.
 */
namespace WGL_Extensions\Templates;

defined('ABSPATH') || exit;

use WGL_Extensions\Includes\WGL_Carousel_Settings;

if (!class_exists('WGL_Testimonials')) {
    /**
     * WGL Elementor Testimonials Template
     *
     *
     * @package motto-core\includes\elementor
     * @author WebGeniusLab <webgeniuslab@gmail.com>
     * @since 1.0.0
     */
    class WGL_Testimonials
    {
        private static $instance;
        private $attributes;

        public static function get_instance()
        {
            if (is_null(self::$instance)) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        public function render($self, $attributes)
        {
            $this->attributes = $attributes;
            extract($this->attributes);

            switch ($posts_per_row) {
                case '1':
                    $col = 12;
                    break;
                case '2':
                    $col = 6;
                    break;
                case '3':
                    $col = 4;
                    break;
                case '4':
                    $col = 3;
                    break;
                case '5':
                    $col = '1/5';
                    break;
            }

            // Wrapper attributes
            $self->add_render_attribute('wrapper', 'class', [
                'wgl-testimonials',
                'type-' . $layout,
            ]);
            if ($hover_animation) {
                $self->add_render_attribute('wrapper', 'class', 'hover_animation');
            }

            // Image styles
            $image_size = $image_size['size'] ?? '';
            $image_url_size = (int)$image_size ? $image_size * 2 : 80;

            // Build structure
            $items_html =  '';

	        if(!$use_carousel){
		        $items_html .= '<div class="row">';
	        }

            foreach ($items as $index=>$item) {

                // Fields validation
                $thumbnail = $item['thumbnail'] ?? '';
                $quote = $item['quote'] ?? '';
                $title = $item['title'] ?? '';
                $author_name = $item['author_name'] ?? '';
                $author_position = $item['author_position'] ?? '';
                $link_author = $item['link_author'] ?? '';
                $name_html = $icon_html = $title_html = '';

                $has_link = !empty($link_author['url']);

                if ($has_link) {
                    $self->add_link_attributes('link-author'.$index, $link_author);
                }

	            $self->add_render_attribute('item_wrapper'.$index, 'class', [
		            'testimonials__wrapper',
		            !$use_carousel ? ' wgl_col-' . $col : ' swiper-slide'
	            ]);

                if (!!$author_name) {
                    $name_html = '<' . esc_attr($name_tag) . ' class="author__name">'
                        . ($has_link ? '<a ' . $self->get_render_attribute_string('link-author' . $index) . '>' : '')
                        . esc_html($author_name)
                        . ($has_link ? '</a>' : '')
                        . '</' . esc_attr($name_tag) . '>';
                }

                if (!!$title_icon_enabled){
                    $icon_html = '<span class="item__icon"></span>';
                }

                if (!!$title){
                    $title_html = '<' . esc_attr($title_tag) . ' class="item__title">';
                        if ('inline' === $title_icon_display){
                            $title_html .= $icon_html;
                            $icon_html = '';
                        }
                        $title_html .= '<span>'.wp_kses($title, self::get_kses_allowed_html()).'</span>';
                    $title_html .= '</' . esc_attr($title_tag ?? '') . '>';
                }

                $quote_html = !empty($quote) ? '<' . esc_attr($quote_tag) . ' class="item__quote">' . wp_kses($quote, self::get_kses_allowed_html()) . '</' . esc_attr($quote_tag) . '>' : '';

                $position_html = $author_position ? '<div class="author__position_wrapper"><' . esc_attr($position_tag) . ' class="author__position">' . esc_html($author_position) . '</' . esc_attr($position_tag) . '></div>' : '';

                $image_html = '';
                $testimonials_image_src = aq_resize($thumbnail['url'], $image_url_size, $image_url_size, true, true, true);
                if (!empty($testimonials_image_src)) {
                    $image_html = '<div class="item__thumbnail"><div class="author__thumbnail">'
                        . ($has_link ? '<a ' . $self->get_render_attribute_string('link-author'.$index) . '>' : '')
                        . '<img src="' . esc_url($testimonials_image_src) . '" alt="' . esc_attr($author_name) . ' photo">'
                        . ($has_link ? '</a>' : '')
                        . '</div></div>';
                }else{
	                $self->add_render_attribute('item_wrapper'.$index, 'class', 'no_image');
                }

                $items_html .= '<div ' . $self->get_render_attribute_string('item_wrapper'.$index) . '>';

                switch ($layout) {
                    case 'top_block':
                        $items_html .= '<div class="testimonial__item">'
                            . $icon_html
                            . '<div class="testimonial__item-inner">'
                                . $image_html
                                . '<div class="item__content">'
                                    . $title_html
                                    . $quote_html
                                . '</div>'
                                . '<div class="item__author">'
                                    . '<div class="author__meta">'
                                        . $name_html
                                        . $position_html
                                    . '</div>'
                                . '</div>'
                            . '</div>'
                        . '</div>';
                        break;

	                case 'bottom_inline':
	                case 'bottom_block':
                        $items_html .= '<div class="testimonial__item">'
                            . $icon_html
                            . '<div class="testimonial__item-inner">'
                                . '<div class="item__content">'
                                    . $title_html
                                    . $quote_html
                                . '</div>'
                                . '<div class="item__author">'
                                    . $image_html
                                    . '<div class="author__meta">'
                                        . $name_html
                                        . $position_html
                                    . '</div>'
                                . '</div>'
                            . '</div>'
                        . '</div>';
                        break;

                    case 'top_inline':
                        $items_html .= '<div class="testimonial__item">'
                            . $icon_html
                            . '<div class="testimonial__item-inner">'
                                . '<div class="item__author">'
                                    . $image_html
                                    . '<div class="author__meta">'
                                        . $name_html
                                        . $position_html
                                    . '</div>'
                                . '</div>'
                                . '<div class="item__content">'
                                    . $title_html
                                    . $quote_html
                                . '</div>'
                            . '</div>'
                        . '</div>';
                        break;

                    case 'left_block':
                        $items_html .= $image_html
                            . '<div class="testimonial__item">'
                                . $icon_html
                                . '<div class="testimonial__item-inner">'
                                    . '<div class="item__content">'
                                        . $title_html
                                        . $quote_html
                                    . '</div>'
                                    . '<div class="item__author">'
                                        . '<div class="author__meta">'
                                            . $name_html
                                            . $position_html
                                        . '</div>'
                                    . '</div>'
                                . '</div>'
                            . '</div>';
                        break;
                }
                $items_html .= '</div>';
            }

	        if(!$use_carousel){
		        $items_html .= '</div>';
	        }

	        echo '<div  ', $self->get_render_attribute_string('wrapper'), '>',
                (!$use_carousel ? $items_html : $this->apply_carousel_settings($items_html)),
            '</div>';
        }

        protected function apply_carousel_settings($testimonials_html)
        {
            $options = [
                // General
                'slides_per_row' => $this->attributes['posts_per_row'],
                'autoplay' => $this->attributes['autoplay'],
                'slides_transition' => $this->attributes['slides_transition'],
                'autoplay_speed' => $this->attributes['autoplay_speed'],
                'fade_animation' => $this->attributes['fade_animation'],
                'animation_style' => $this->attributes['animation_style'],
                'animation_triggered_by_mouse' => $this->attributes['animation_triggered_by_mouse'],
                'slider_infinite' => $this->attributes['slider_infinite'],
                'adaptive_height' => $this->attributes['adaptive_height'],
	            'slide_per_single' => $this->attributes['slide_per_single'],
	            'center_mode' => $this->attributes['center_mode'],
                // Pagination
                'use_pagination' => $this->attributes['use_pagination'],
                'pagination_type' => $this->attributes['pagination_type'],
                'pagination_dynamic' => $this->attributes['pagination_dynamic'],
                // Navigation
                'use_navigation' => $this->attributes['use_navigation'],
                'navigation_position' => $this->attributes['navigation_position'],
                // Responsive
                'customize_responsive' => $this->attributes['customize_responsive'],
                'widescreen_breakpoint' => $this->attributes['widescreen_breakpoint'],
                'widescreen_slides' => $this->attributes['widescreen_slides'],
	            'desktop_breakpoint' => $this->attributes['desktop_breakpoint'],
                'desktop_slides' => $this->attributes['desktop_slides'],
                'tablet_breakpoint' => $this->attributes['tablet_breakpoint'],
                'tablet_slides' => $this->attributes['tablet_slides'],
                'mobile_breakpoint' => $this->attributes['mobile_breakpoint'],
                'mobile_slides' => $this->attributes['mobile_slides'],
            ];

            return WGL_Carousel_Settings::init($options, $testimonials_html);
        }

        protected function get_rating_html(Int $value)
        {
            $max_rating = 5;
            $width = $value / $max_rating * 100;

            return '<div class="item__rating" role="img" aria-label="' . esc_attr__('Rated', 'motto-core') . ' ' . $value . ' out of ' . $max_rating . '">'
                . '<span style="width: ' . $width . '%"></span>'
                . '</div>';
        }

        protected static function get_kses_allowed_html()
        {
            return [
                'a' => [
                    'id' => true, 'class' => true, 'style' => true,
                    'href' => true, 'title' => true,
                    'rel' => true, 'target' => true
                ],
                'br' => ['id' => true, 'class' => true, 'style' => true],
                'em' => ['id' => true, 'class' => true, 'style' => true],
                'strong' => ['id' => true, 'class' => true, 'style' => true],
                'span' => ['id' => true, 'class' => true, 'style' => true],
                'p' => ['id' => true, 'class' => true, 'style' => true],
                'ul' => ['id' => true, 'class' => true, 'style' => true],
                'ol' => ['id' => true, 'class' => true, 'style' => true],
            ];
        }
    }
}
