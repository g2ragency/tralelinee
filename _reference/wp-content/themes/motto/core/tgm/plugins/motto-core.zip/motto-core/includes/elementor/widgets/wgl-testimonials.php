<?php
/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/widgets/wgl-testimonials.php`.
 */
namespace WGL_Extensions\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Utils,
    Repeater,
    Group_Control_Border,
    Group_Control_Box_Shadow,
    Group_Control_Typography,
    Group_Control_Background
};
use WGL_Extensions\{
    WGL_Framework_Global_Variables as WGL_Globals,
    Includes\WGL_Carousel_Settings,
    Templates\WGL_Testimonials as Testimonials_Template
};

class WGL_Testimonials extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-testimonials';
    }

    public function get_title()
    {
        return esc_html__('WGL Testimonials', 'motto-core');
    }

    public function get_icon()
    {
        return 'wgl-testimonials';
    }

    public function get_keywords()
    {
        return [ 'testimonials', 'carousel', 'slider' ];
    }

    public function get_script_depends()
    {
        return ['swiper'];
    }

    public function get_categories()
    {
        return ['wgl-modules'];
    }

    protected function register_controls()
    {
        /**
         * CONTENT -> GENERAL
         */

        $this->start_controls_section(
            'content_general',
            ['label' => esc_html__('General', 'motto-core')]
        );

        $this->add_control(
            'posts_per_row',
            [
                'label' => esc_html__('Grid Columns Amount', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('1 (one)', 'motto-core'),
                    '2' => esc_html__('2 (two)', 'motto-core'),
                    '3' => esc_html__('3 (three)', 'motto-core'),
                    '4' => esc_html__('4 (four)', 'motto-core'),
                    '5' => esc_html__('5 (five)', 'motto-core'),
                ],
                'default' => '3',
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'thumbnail',
            [
                'label' => esc_html__('Image', 'motto-core'),
                'type' => Controls_Manager::MEDIA,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'default' => ['url' => Utils::get_placeholder_image_src()],
            ]
        );

        $repeater->add_control(
            'author_name',
            [
                'label' => esc_html__('Author Name', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'link_author',
            [
                'label' => esc_html__('Link Author', 'motto-core'),
                'type' => Controls_Manager::URL,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'author_position',
            [
                'label' => esc_html__('Author Position', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_html__('Your Title', 'motto-core'),
                'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur.', 'motto-core'),
            ]
        );

        $repeater->add_control(
            'quote',
            [
                'label' => esc_html__('Quote', 'motto-core'),
                'type' => Controls_Manager::WYSIWYG,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_html__('"Lorem ipsum dolor sit amet, consectetur adipisicing elit."', 'motto-core'),

            ]
        );

        $this->add_control(
            'items',
            [
                'label' => esc_html__('Items', 'motto-core'),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [
                        'author_name' => esc_html__('Christina Grant', 'motto-core'),
                        'author_position' => esc_html__('Designer', 'motto-core'),
                    ],
                    [
                        'author_name' => esc_html__('Harry Newman', 'motto-core'),
                        'author_position' => esc_html__('Developer', 'motto-core'),
                    ],
                    [
                        'author_name' => esc_html__('Marry Johnson', 'motto-core'),
                        'author_position' => esc_html__('Designer', 'motto-core'),
                    ],
                    [
                        'author_name' => esc_html__('Tyler Smith', 'motto-core'),
                        'author_position' => esc_html__('Company CFO', 'motto-core'),
                    ],
                ],
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ author_name }}}',
            ]
        );

        $this->add_control(
            'layout',
            [
                'label' => esc_html__('Layout', 'motto-core'),
                'type' => 'wgl-radio-image',
                'options' => [
                    'top_block' => [
                        'title' => esc_html__('Top', 'motto-core'),
                        'image' => WGL_EXTENSIONS_ELEMENTOR_URL . 'assets/img/wgl_elementor_addon/icons/testimonials_1.png',
                    ],
                    'bottom_block' => [
                        'title' => esc_html__('Bottom', 'motto-core'),
                        'image' => WGL_EXTENSIONS_ELEMENTOR_URL . 'assets/img/wgl_elementor_addon/icons/testimonials_4.png',
                    ],
                    'top_inline' => [
                        'title' => esc_html__('Top Inline', 'motto-core'),
                        'image' => WGL_EXTENSIONS_ELEMENTOR_URL . 'assets/img/wgl_elementor_addon/icons/testimonials_2.png',
                    ],
                    'bottom_inline' => [
                        'title' => esc_html__('Bottom Inline', 'motto-core'),
                        'image' => WGL_EXTENSIONS_ELEMENTOR_URL . 'assets/img/wgl_elementor_addon/icons/testimonials_3.png',
                    ],
                    'left_block' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'image' => WGL_EXTENSIONS_ELEMENTOR_URL . 'assets/img/wgl_elementor_addon/icons/testimonials_5.png',
                    ],
                ],
                'default' => 'bottom_inline',
            ]
        );

        $this->add_responsive_control(
            'alignment',
            [
                'label' => esc_html__('Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => false,
	            'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
	            'prefix_class' => 'a%s',
                'default' => 'left',
            ]
        );

        $this->add_control(
            'hover_animation',
            [
                'label' => esc_html__('Enable Hover Animation', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('Lift up the item on hover.', 'motto-core'),
            ]
        );

        $this->end_controls_section();

        /**
         * CONTENT -> CAROUSEL OPTIONS
         */

        WGL_Carousel_Settings::add_controls($this, [
            'use_carousel' => [ 'default' => 'yes' ],
            'use_navigation' => [ 'default' => '' ],
            'use_pagination' => [ 'default' => 'yes' ],
            '3d_animation_options' => 'enabled',
            'animation_style' => [ 'default' => 'default' ],
            'slide_per_single' => [ 'default' => 'yes' ],
            'pagination_margin' => [ 'default' => [
                'top' => '60',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'unit' => 'px',
                'isLinked' => false
            ], ],
            'navigation_position' => [ 'default' => 'nearby' ],
            'navigation_alignment_v' => [ 'default' => 'flex-end' ],
        ]);

        /**
         * STYLE -> ITEM CONTAINER
         */

        $this->start_controls_section(
            'style_item_container',
            [
                'label' => esc_html__('Item Container', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'item_gap',
            [
                'label' => esc_html__('Items Gap', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [ 'px' => ['min' => 0, 'max' => 100] ],
                'size_units' => ['px', 'custom'],
                'default' => ['size' => 60, 'unit' => 'px'],
                'tablet_default' => ['size' => 30, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-testimonials' => '--wgl-gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'custom'],
                'allowed_dimensions' => 'vertical',
                'selectors' => [
                    '{{WRAPPER}} .testimonial__item' => 'margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .testimonial__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'item_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .testimonial__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_bg',
                'fields_options' => [
                    'color' => [ 'label' => esc_html__( 'Background Color', 'motto-core' ) ],
                    'image' => [ 'label' => esc_html__( 'Background Image', 'motto-core' ) ],
                ],
                'selector' => '{{WRAPPER}} .testimonial__item',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_border',
                'fields_options' => [
                    'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                    'color' => [ 'label' => esc_html__( 'Border Color', 'motto-core' ) ],
                ],
                'selector' => '{{WRAPPER}} .testimonial__item',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_shadow',
                'selector' => '{{WRAPPER}} .testimonial__item',
            ]
        );

        $this->add_control(
            'item_blur',
            [
                'label' => esc_html__('Background Blur', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['max' => 30, 'step' => 0.5],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial__item' => 'backdrop-filter: blur({{SIZE}}px);-webkit-backdrop-filter: blur({{SIZE}}px);',
                ],
            ]
        );

	    $this->end_controls_section();

        /**
         * STYLE -> TITLE
         */

        $this->start_controls_section(
            'style_title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_title',
                'selector' => '{{WRAPPER}} .item__title',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('Title tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'span' => esc_html('‹span›'),
                    'div' => esc_html('‹div›'),
                ],
                'default' => 'h3',
            ]
        );

        $this->add_responsive_control(
            'title_width',
            [
                'label' => esc_html__('Title Wrapper Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', '%', 'custom'],
                'range' => [
                    'px' => ['min' => 50, 'max' => 1200 ],
                    '%' => ['min' => 5, 'max' => 100 ],
                ],
                'default' => ['size' => 380, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .item__title' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .item__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '33',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .item__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'title_border',
                'fields_options' => [
                    'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                ],
                'selector' => '{{WRAPPER}} .item__title',
            ]
        );

        $this->add_responsive_control(
            'title_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => ['title_icon_enabled!' => ''],
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .item__title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('Title Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .item__title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_bg_color',
            [
                'label' => esc_html__('Title Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .item__title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * STYLE -> ICON
         */

        $this->start_controls_section(
            'style_title_icon',
            [
                'label' => esc_html__('Icon', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_icon_enabled',
            [
                'label' => esc_html__('Use Icon', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'render_type' => 'template',
                'default' => 'yes',
                'selectors' => [
                    '{{WRAPPER}} .testimonial__item .item__icon' => 'display: inline-flex;'
                ],
            ]
        );
        $this->add_control(
            'title_icon_display',
            [
                'label' => esc_html__( 'Display', 'motto-core' ),
                'type' => Controls_Manager::SELECT,
                'render_type' => 'template',
                'condition' => ['title_icon_enabled!' => ''],
                'options' => [
                    'inline' => esc_html__( 'Inline', 'motto-core' ),
                    'block' => esc_html__( 'Block', 'motto-core' ),
                ],
                'default' => 'inline',
            ]
        );
	    $this->add_responsive_control(
		    'title_icon_size',
		    [
			    'label' => esc_html__('Icon Size', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'condition' => ['title_icon_enabled!' => ''],
			    'range' => [
				    'px' => ['min' => 10, 'max' => 150],
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .testimonial__item .item__icon' => 'font-size: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_responsive_control(
            'icon_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => ['title_icon_enabled!' => ''],
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '1',
                    'right' => '20',
                    'bottom' => '10',
                    'left' => '1',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial__item .item__icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
		    'icon_padding',
		    [
			    'label' => esc_html__('Padding', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'condition' => ['title_icon_enabled!' => ''],
			    'size_units' => ['px', 'em', '%', 'custom'],
			    'selectors' => [
				    '{{WRAPPER}} .testimonial__item .item__icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'icon_radius',
		    [
			    'label' => esc_html__('Border Radius', 'motto-core'),
			    'type' => Controls_Manager::DIMENSIONS,
			    'condition' => ['title_icon_enabled!' => ''],
			    'size_units' => ['px', 'em', '%', 'custom'],
			    'selectors' => [
				    '{{WRAPPER}} .testimonial__item .item__icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'title_icon_color',
		    [
			    'label' => esc_html__('Icon Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => ['title_icon_enabled!' => ''],
			    'default' => WGL_Globals::get_primary_color(),
			    'selectors' => [
				    '{{WRAPPER}} .testimonial__item .item__icon' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'title_icon_bg',
		    [
			    'label' => esc_html__('Background Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => ['title_icon_enabled!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .testimonial__item .item__icon' => 'background-color: {{VALUE}};',
			    ],
		    ]
	    );

        $this->end_controls_section();

        /**
         * STYLE -> QUOTE
         */

        $this->start_controls_section(
            'style_quote',
            [
                'label' => esc_html__('Quote', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_quote',
                'selector' => '{{WRAPPER}} .item__quote',
            ]
        );

        $this->add_control(
            'quote_tag',
            [
                'label' => esc_html__('Quote tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'span' => esc_html('‹span›'),
                    'div' => esc_html('‹div›'),
                ],
                'default' => 'div',
            ]
        );

        $this->add_responsive_control(
            'quote_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '9',
                    'right' => '0',
                    'bottom' => '23',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .item__quote' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'quote_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '29',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .item__quote' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'quote_border',
                'fields_options' => [
                    'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                ],
                'selector' => '{{WRAPPER}} .item__quote',
            ]
        );

        $this->add_responsive_control(
            'quote_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .item__quote' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'quote_color',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .item__quote' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'quote_bg',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .item__quote' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'quote_corner_enabled',
            [
                'label' => esc_html__('Use Corner', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'separator' => 'before',
                'options' => [
                    '' => [
                        'title' => esc_html__('None', 'motto-core'),
                        'icon' => 'eicon-close-circle',
                    ],
                    'top' => [
                        'title' => esc_html__('Top', 'motto-core'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'bottom' => [
                        'title' => esc_html__('Bottom', 'motto-core'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'selectors_dictionary' => [
                    'top' => 'display: block; bottom: 100%; top: auto; border-bottom-width: 0px; --corner-angle: -135deg;',
                    'bottom' => 'display: block; top: 100%; bottom: auto; border-top-width: 0px; --corner-angle: -45deg;',
                ],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .item__quote::before,
                     {{WRAPPER}} .item__quote::after' => '{{VALUE}}',
                ],
            ]
        );


        $this->add_responsive_control(
            'quote_corner_size',
            [
                'label' => esc_html__('Corner Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0, 'max' => 60],
                ],
                'condition' => ['quote_corner_enabled!' => ''],
                'default' => ['size' => 0],
                'selectors' => [
                    '{{WRAPPER}} .item__quote' => '--corner-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'quote_corner_width',
            [
                'label' => esc_html__('Lines Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 1, 'max' => 10],
                ],
                'condition' => ['quote_corner_enabled!' => ''],
                'default' => ['size' => 1],
                'selectors' => [
                    '{{WRAPPER}} .item__quote' => '--corner-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'quote_corner_pos_x',
            [
                'label' => esc_html__('Corner Position by Horizontal', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 0, 'max' => 500],
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'condition' => ['quote_corner_enabled!' => ''],
                'default' => ['size' => 80, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .item__quote' => '--corner-pos-x: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'quote_corner_color',
            [
                'label' => esc_html__('Corner Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['quote_corner_enabled!' => ''],
                'default' => WGL_Globals::get_secondary_color('0.15'),
                'selectors' => [
                    '{{WRAPPER}} .item__quote::before,
                     {{WRAPPER}} .item__quote::after' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * STYLE -> AUTHOR BLOCK
         */

        $this->start_controls_section(
            'style_author',
            [
                'label' => esc_html__('Author Block', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'author_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .item__author' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * STYLE -> AUTHOR THUMBNAIL
         */

        $this->start_controls_section(
            'style_thumnail',
            [
                'label' => esc_html__('Author Thumbnail', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'image_size',
            [
                'label' => esc_html__('Image Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 20, 'max' => 400],
                ],
                'default' => ['size' => 90],
	            'selectors' => [
		            '{{WRAPPER}} .author__thumbnail' => '--image-width: {{SIZE}};',
	            ],
            ]
        );
        $this->add_responsive_control(
            'image_not_active_size',
            [
                'label' => esc_html__('Not Active Image Width', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'range' => [
                    'px' => ['min' => 20, 'max' => 400],
                ],
	            'selectors' => [
		            '{{WRAPPER}} .author__thumbnail' => '--image-not-active-width: {{SIZE}};',
	            ],
            ]
        );

        $this->add_responsive_control(
            'image_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .author__thumbnail' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'default' => [
                    'top' => '50',
                    'right' => '50',
                    'bottom' => '50',
                    'left' => '50',
                    'unit' => '%',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .author__thumbnail,
                     {{WRAPPER}} .author__thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'fields_options' => [
                    'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                    'color' => [ 'type' => Controls_Manager::HIDDEN ],
                ],
                'selector' => '{{WRAPPER}} .author__thumbnail',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'testimonials_image_shadow',
                'selector' => '{{WRAPPER}} .author__thumbnail',
            ]
        );

        $this->add_control(
            'testimonials_triangle_enabled',
            [
                'label' => esc_html__('Use a Decorative Triangle?', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'separator' => 'before',
                'render_type' => 'template',
                'default' => 'yes',
                'selectors' => [
                    '{{WRAPPER}} .author__thumbnail::before' => 'opacity: 1;'
                ],
            ]
        );

        $this->add_responsive_control(
            'testimonials_triangle_distance',
            [
                'label' => esc_html__('Triangle Distance', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'condition' => [ 'testimonials_triangle_enabled!' => '' ],
                'range' => [ 'px' => ['min' => 0, 'max' => 100] ],
                'size_units' => ['px'],
                'default' => ['size' => 5, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .author__thumbnail::before' => '--triangle-distance: {{SIZE}}px;',
                ],
            ]
        );

        $this->start_controls_tabs('image_tabs');

        $this->start_controls_tab(
            'tab_image_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'image_bg_color_idle',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .author__thumbnail' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'image_border_color_idle',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'image_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .author__thumbnail' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'testimonials_triangle_color_idle',
            [
                'label' => esc_html__( 'Triangle Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'testimonials_triangle_enabled!' => '' ],
                'selectors' => [
                    '{{WRAPPER}} .author__thumbnail::before' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_image_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'image_bg_color_hover',
            [
                'label' => esc_html__( 'Background Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__wrapper:hover .author__thumbnail,
                     {{WRAPPER}} .swiper-slide.swiper-slide-active .author__thumbnail' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'image_border_color_hover',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [ 'image_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__wrapper:hover .author__thumbnail,
                     {{WRAPPER}} .swiper-slide.swiper-slide-active .author__thumbnail' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'testimonials_triangle_color_hover',
            [
                'label' => esc_html__( 'Triangle Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'testimonials_triangle_enabled!' => '' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__wrapper:hover .author__thumbnail::before,
                     {{WRAPPER}} .swiper-slide.swiper-slide-active .author__thumbnail::before' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> AUTHOR NAME
         */

        $this->start_controls_section(
            'style_name',
            [
                'label' => esc_html__('Author Name', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'name_tag',
            [
                'label' => esc_html__('HTML tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'div' => esc_html('‹div›'),
                    'span' => esc_html('‹span›'),
                ],
                'default' => 'h3',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_name',
                'selector' => '{{WRAPPER}} .author__name',
            ]
        );

        $this->add_responsive_control(
            'name_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .author__name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('name_colors');

        $this->start_controls_tab(
            'tab_name_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );

        $this->add_control(
            'name_color_idle',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .author__name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_name_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );

        $this->add_control(
            'name_color_hover',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .author__name:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLE -> AUTHOR POSITION
         */

        $this->start_controls_section(
            'style_position',
            [
                'label' => esc_html__('Author Position', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_position',
                'selector' => '{{WRAPPER}} .author__position',
            ]
        );
        $this->add_control(
            'position_tag',
            [
                'label' => esc_html__('HTML tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'span',
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'div' => esc_html('‹div›'),
                    'span' => esc_html('‹span›'),
                ],
            ]
        );
        $this->add_responsive_control(
            'position_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .author__position_wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'position_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '4',
                    'right' => '10',
                    'bottom' => '3',
                    'left' => '10',
                    'unit' => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .author__position' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'position_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .author__position' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'position_border',
                'fields_options' => [
                    'width' => [ 'label' => esc_html__( 'Border Width', 'motto-core' ) ],
                    'color' => [ 'type' => Controls_Manager::HIDDEN ],
                ],
                'selector' => '{{WRAPPER}} .author__position',
            ]
        );

        $this->start_controls_tabs('position_tabs');
        $this->start_controls_tab(
            'position_tab_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'position_color',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .author__position' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'position_bg_color',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .author__position' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'position_border_color_idle',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'position_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .author__position' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'position_tab_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'position_color_hover',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__wrapper:hover .author__position' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'position_bg_color_hover',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__wrapper:hover .author__position' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'position_border_color_hover',
            [
                'label' => esc_html__( 'Border Color', 'motto-core' ),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'position_border_border!' => ['', 'none'] ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__wrapper:hover .author__position' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function render()
    {
        (new Testimonials_Template())->render(
            $this,
            $this->get_settings_for_display()
        );
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WGL_Extensions\Includes\WGL_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
