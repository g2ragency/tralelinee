<?php
/**
 * This template can be overridden by copying it to `motto[-child]/motto-core/elementor/widgets/wgl-double-headings.php`.
 */
namespace WGL_Extensions\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{Group_Control_Background,
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow};
use WGL_Extensions\{
    WGL_Framework_Global_Variables as WGL_Globals,
    Includes\WGL_Cursor
};

class WGL_Double_Heading extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-double-heading';
    }

    public function get_title()
    {
        return esc_html__('WGL Double Heading', 'motto-core');
    }

    public function get_icon()
    {
        return 'wgl-double-heading';
    }

    public function get_keywords()
    {
        return [ 'double', 'dblh', 'heading', 'title', 'text' ];
    }

    public function get_categories()
    {
        return ['wgl-modules'];
    }

    protected function register_controls()
    {
        /**
         * CONTENT -> GENERAL
         */

        $this->start_controls_section(
            'content_general',
            ['label' => esc_html__('General', 'motto-core')]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('Subtitle', 'motto-core'),
                'type' => Controls_Manager::TEXT,
			    'dynamic' => [  'active' => true],
                'label_block' => true,
                'placeholder' => esc_attr__('ex: (About Our Company)', 'motto-core'),
                'default' => esc_html__('(About Our Company)', 'motto-core'),
            ]
        );

        $this->add_control(
            'divider',
            [
                'label' => esc_html__('Add Divider', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'motto-core'),
                'label_off' => esc_html__('No', 'motto-core'),
                'render_type' => 'template',
                'condition' => ['subtitle!' => ''],
                'prefix_class' => 'divider-',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'title_heading',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'title_part-1',
            [
                'label' => esc_html__('1st Part', 'motto-core'),
                'type' => Controls_Manager::TEXTAREA,
			    'dynamic' => [  'active' => true],
                'rows' => 3,
                'placeholder' => esc_attr__('1st part', 'motto-core'),
                'default' => esc_html__('Double Heading Title', 'motto-core'),
            ]
        );

        $this->add_control(
            'title_part-2',
            [
                'label' => esc_html__('2nd Part', 'motto-core'),
                'type' => Controls_Manager::TEXTAREA,
			    'dynamic' => [  'active' => true],
                'rows' => 3,
                'placeholder' => esc_attr__('2nd part', 'motto-core'),
            ]
        );

        $this->add_control(
            'title_part-3',
            [
                'label' => esc_html__('3rd Part', 'motto-core'),
                'type' => Controls_Manager::TEXTAREA,
			    'dynamic' => [  'active' => true],
                'rows' => 3,
                'placeholder' => esc_attr__('3rd part', 'motto-core'),
            ]
        );

        $this->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'motto-core'),
                'type' => Controls_Manager::WYSIWYG,
			    'dynamic' => [  'active' => true],
                'placeholder' => esc_attr__('Description Text', 'motto-core'),
                'label_block' => true,
            ]
        );

        $this->add_responsive_control(
            'alignment',
            [
                'label' => esc_html__('Alignment', 'motto-core'),
                'type' => Controls_Manager::CHOOSE,
                'separator' => 'before',
                'toggle' => false,
	            'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'motto-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'motto-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'motto-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'prefix_class' => 'a%s',
                'default' => 'left',
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => esc_html__('Title Link', 'motto-core'),
                'type' => Controls_Manager::URL,
			    'dynamic' => [  'active' => true],
                'placeholder' => esc_attr__('https://your-link.com', 'motto-core'),
            ]
        );

        $this->end_controls_section();

        /**
         * GENERAL -> CURSOR
         */

        WGL_Cursor::init(
            $this,
            [
                'section' => true,
            ]
        );


        /**
         * STYLES -> TITLE
         */

        $this->start_controls_section(
            'style_title',
            [
                'label' => esc_html__('Title', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_all',
                'fields_options' => [
                    'typography' => [ 'default' => 'yes' ],
                    'font_size' => [
                        'default' => [ 'size' => 80, 'unit' => 'px' ],
                        'tablet_default' => [ 'size' => 56, 'unit' => 'px' ],
                        'mobile_default' => [ 'size' => 36, 'unit' => 'px' ]
                    ],
                ],
                'selector' => '{{WRAPPER}} .dblh__title-wrapper',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML Tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'span' => esc_html('‹span›'),
                    'div' => esc_html('‹div›'),
                ],
                'default' => 'h3',
            ]
        );

	    $this->add_responsive_control(
		    'title_display',
		    [
			    'label' => esc_html__( 'Display', 'motto-core' ),
			    'type' => Controls_Manager::SELECT,
			    'options' => [
				    'inline' => esc_html__( 'Inline', 'motto-core' ),
				    'block' => esc_html__( 'Block', 'motto-core' ),
				    'inline-block' => esc_html__( 'Inline Block', 'motto-core' ),
			    ],
			    'default' => 'inline',
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title' => 'display: {{VALUE}};',
			    ],
		    ]
	    );
        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_1st_heading',
            [
                'label' => esc_html__('1st Part', 'motto-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => ['title_part-1!' => ''],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_first',
                'condition' => ['title_part-1!' => ''],
                'selector' => '{{WRAPPER}} .dblh__title-1',
            ]
        );

	    $this->add_responsive_control(
		    'title_first_stroke_size',
		    [
			    'label' => esc_html__('Stroke Width', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'size_units' => ['px'],
			    'range' => ['px' => ['min' => 0, 'max' => 2, 'step' => 0.1]],
			    'condition' => ['title_part-1!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-1' => '-webkit-text-stroke-width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->start_controls_tabs(
		    'tabs_title_first', [
			    'condition' => ['title_part-1!' => ''],
		    ]
	    );
	    $this->start_controls_tab(
		    'tabs_title_first_idle',
		    ['label' => esc_html__('Idle', 'motto-core')]
	    );
        $this->add_control(
            'title_1st_color_idle',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => ['title_part-1!' => ''],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-1' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_1st_stroke_color_idle',
            [
                'label' => esc_html__('Stroke Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'condition' => [
                	'title_part-1!' => '',
                	'title_first_stroke_size[size]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-1' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
            ]
        );
	    $this->end_controls_tab();
	    $this->start_controls_tab(
		    'tabs_title_first_hover',
		    ['label' => esc_html__('Hover', 'motto-core')]
	    );
	    $this->add_control(
		    'title_1st_color_hover',
		    [
			    'label' => esc_html__('Text Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => ['title_part-1!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-wrapper:hover  .dblh__title-1' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'title_1st_stroke_color_hover',
		    [
			    'label' => esc_html__('Stroke Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => [
				    'title_part-1!' => '',
				    'title_first_stroke_size[size]!' => '',
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-wrapper:hover .dblh__title-1' => '-webkit-text-stroke-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->end_controls_tab();
	    $this->end_controls_tabs();

        $this->add_control(
            'title_2nd_heading',
            [
                'label' => esc_html__('2nd Part', 'motto-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => ['title_part-2!' => ''],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_second',
                'condition' => ['title_part-2!' => ''],
                'selector' => '{{WRAPPER}} .dblh__title-2',
            ]
        );

        $this->add_responsive_control(
            'title_second_padding',
            [
                'label' => esc_html__('Padding for 2nd Part', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'condition' => ['title_part-2!' => ''],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
		    'title_second_stroke_size',
		    [
			    'label' => esc_html__('Stroke Width', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'size_units' => ['px'],
			    'range' => ['px' => ['min' => 0, 'max' => 2, 'step' => 0.1]],
			    'condition' => ['title_part-2!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-2' => '-webkit-text-stroke-width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->start_controls_tabs(
		    'tabs_title_second', [
			    'condition' => ['title_part-2!' => ''],
		    ]
	    );
	    $this->start_controls_tab(
		    'tabs_title_second_idle',
		    ['label' => esc_html__('Idle', 'motto-core')]
	    );
	    $this->add_control(
		    'title_2nd_color_idle',
		    [
			    'label' => esc_html__('Text Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => ['title_part-2!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-2' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'title_2nd_stroke_color_idle',
		    [
			    'label' => esc_html__('Stroke Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => [
				    'title_part-2!' => '',
				    'title_second_stroke_size[size]!' => '',
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-2' => '-webkit-text-stroke-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->end_controls_tab();
	    $this->start_controls_tab(
		    'tabs_title_second_hover',
		    ['label' => esc_html__('Hover', 'motto-core')]
	    );
	    $this->add_control(
		    'title_2nd_color_hover',
		    [
			    'label' => esc_html__('Text Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => ['title_part-2!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-wrapper:hover  .dblh__title-2' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'title_2nd_stroke_color_hover',
		    [
			    'label' => esc_html__('Stroke Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => [
				    'title_part-2!' => '',
				    'title_second_stroke_size[size]!' => '',
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-wrapper:hover .dblh__title-2' => '-webkit-text-stroke-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->end_controls_tab();
	    $this->end_controls_tabs();

        $this->add_control(
            'title_3rd_heading',
            [
                'label' => esc_html__('3rd Part', 'motto-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => ['title_part-3!' => ''],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_third',
                'condition' => ['title_part-3!' => ''],
                'selector' => '{{WRAPPER}} .dblh__title-3',
            ]
        );

        $this->add_responsive_control(
            'title_third_padding',
            [
                'label' => esc_html__('Padding for 3rd Part', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'condition' => ['title_part-3!' => ''],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_responsive_control(
		    'title_third_stroke_size',
		    [
			    'label' => esc_html__('Stroke Width', 'motto-core'),
			    'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
			    'size_units' => ['px'],
			    'range' => ['px' => ['min' => 0, 'max' => 2, 'step' => 0.1]],
			    'condition' => ['title_part-3!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-3' => '-webkit-text-stroke-width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->start_controls_tabs(
		    'tabs_title_third', [
			    'condition' => ['title_part-3!' => ''],
		    ]
	    );
	    $this->start_controls_tab(
		    'tabs_title_third_idle',
		    ['label' => esc_html__('Idle', 'motto-core')]
	    );
	    $this->add_control(
		    'title_3rd_color_idle',
		    [
			    'label' => esc_html__('Text Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => ['title_part-3!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-3' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'title_3rd_stroke_color_idle',
		    [
			    'label' => esc_html__('Stroke Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => [
				    'title_part-3!' => '',
				    'title_third_stroke_size[size]!' => '',
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-3' => '-webkit-text-stroke-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->end_controls_tab();
	    $this->start_controls_tab(
		    'tabs_title_third_hover',
		    ['label' => esc_html__('Hover', 'motto-core')]
	    );
	    $this->add_control(
		    'title_3rd_color_hover',
		    [
			    'label' => esc_html__('Text Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => ['title_part-3!' => ''],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-wrapper:hover  .dblh__title-3' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_control(
		    'title_3rd_stroke_color_hover',
		    [
			    'label' => esc_html__('Stroke Color', 'motto-core'),
			    'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
			    'condition' => [
				    'title_part-3!' => '',
				    'title_third_stroke_size[size]!' => '',
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .dblh__title-wrapper:hover .dblh__title-3' => '-webkit-text-stroke-color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->end_controls_tab();
	    $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLES -> TITLE GRADIENT
         */

        $this->start_controls_section(
            'style_title_gradient',
            [
                'label' => esc_html__('Title Gradient', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'title_gradient',
            [
                'label' => esc_html__('Use Gradient', 'motto-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'motto-core'),
                'label_off' => esc_html__('No', 'motto-core'),
                'prefix_class' => 'title_gradient-',
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => '-webkit-background-clip: text; -webkit-text-fill-color: transparent;',
                ],
            ]
        );

        $this->add_control(
            'title_gradient_color_1',
            [
                'label' => esc_html__('Primary Gradient Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'title_gradient!' => '' ],
                'default' => WGL_Globals::get_tertiary_color(1),
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => '--gradient-color-1: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'title_gradient_color_2',
            [
                'label' => esc_html__('Secondary Gradient Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'condition' => [ 'title_gradient!' => '' ],
                'default' => WGL_Globals::get_primary_color(1),
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => '--gradient-color-2: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_gradient_location_1',
            [
                'label' => esc_html__('First Color Location', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ '%', 'px' ],
                'default' => [ 'unit' => '%', 'size' => 0 ],
                'render_type' => 'ui',
                'condition' => [ 'title_gradient!' => '' ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => '--gradient-location-1: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_gradient_location_2',
            [
                'label' => esc_html__('Second Color Location', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ '%', 'px' ],
                'default' => [ 'unit' => '%', 'size' => 110 ],
                'render_type' => 'ui',
                'condition' => [ 'title_gradient!' => '' ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => '--gradient-location-2: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'title_gradient_type',
            [
                'label' => esc_html__('Type', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'linear' => esc_html__( 'Linear', 'motto-core' ),
                    'radial' => esc_html__( 'Radial', 'motto-core' ),
                ],
                'default' => 'radial',
                'render_type' => 'ui',
                'condition' => [ 'title_gradient!' => '' ],
            ]
        );
        $this->add_responsive_control(
            'title_gradient_angle',
            [
                'label' => esc_html__('Angle', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'deg' ],
                'default' => [ 'unit' => 'deg', 'size' => 180 ],
                'range' => [
                    'deg' => [ 'step' => 10 ],
                ],
                'condition' => [
                    'title_gradient!' => '',
                    'title_gradient_type' => 'linear',
                ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => 'background-color: transparent; background-image: linear-gradient({{SIZE}}{{UNIT}}, var(--gradient-color-1) var(--gradient-location-1), var(--gradient-color-2) var(--gradient-location-2));',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_gradient_position',
            [
                'label' => esc_html__('Position', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'center center' => esc_html__( 'Center Center', 'motto-core' ),
                    'center left' => esc_html__( 'Center Left', 'motto-core' ),
                    'center right' => esc_html__( 'Center Right', 'motto-core' ),
                    'top center' => esc_html__( 'Top Center', 'motto-core' ),
                    'top left' => esc_html__( 'Top Left', 'motto-core' ),
                    'top right' => esc_html__( 'Top Right', 'motto-core' ),
                    'bottom center' => esc_html__( 'Bottom Center', 'motto-core' ),
                    'bottom left' => esc_html__( 'Bottom Left', 'motto-core' ),
                    'bottom right' => esc_html__( 'Bottom Right', 'motto-core' ),
                    'var(--h-pos) var(--v-pos)' => esc_html__( 'Custom', 'motto-core' ),
                ],
                'default' => 'center center',
                'condition' => [
                    'title_gradient!' => '',
                    'title_gradient_type' => 'radial',
                ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => 'background-color: transparent; background-image: radial-gradient(circle at {{VALUE}}, var(--gradient-color-1) var(--gradient-location-1), var(--gradient-color-2) var(--gradient-location-2));',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_gradient_h_position',
            [
                'label' => esc_html__('Horizontal Position', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'vw', 'custom'],
                'range' => [
                    'px' => [ 'min' => -2560, 'max' => 2560 ],
                    '%' => [ 'min' => -100, 'max' => 200 ],
                    'vw' => [ 'min' => -100, 'max' => 100 ],
                ],
                'condition' => [
                    'title_gradient!' => '',
                    'title_gradient_type' => 'radial',
                    'title_gradient_position' => 'var(--h-pos) var(--v-pos)',
                ],
                'default' => [ 'size' => 50, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => '--h-pos: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_gradient_v_position',
            [
                'label' => esc_html__('Vertical Position', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
                'dynamic' => [  'active' => true],
                'size_units' => [ 'px', '%', 'vw', 'custom'],
                'range' => [
                    'px' => [ 'min' => -2560, 'max' => 2560 ],
                    '%' => [ 'min' => -100, 'max' => 200 ],
                    'vw' => [ 'min' => -100, 'max' => 100 ],
                ],
                'condition' => [
                    'title_gradient!' => '',
                    'title_gradient_type' => 'radial',
                    'title_gradient_position' => 'var(--h-pos) var(--v-pos)',
                ],
                'default' => [ 'size' => 100, 'unit' => '%' ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__title-wrapper' => '--v-pos: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        /**
         * STYLE -> CONTENT
         */

        $this->start_controls_section(
            'style_content',
            [
                'label' => esc_html__('Content', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['content!' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_content',
                'selector' => '{{WRAPPER}} .dblh__content',
            ]
        );

        $this->add_responsive_control(
            'content_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'default' => [
                    'top' => '19',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .dblh__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('content_color_tab');
        $this->start_controls_tab(
            'custom_content_color_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .dblh__content' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'custom_content_color_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'content_color_hover',
            [
                'label' => esc_html__('Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .elementor-widget-container:hover .dblh__content' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLES -> DIVIDER
         */

        $this->start_controls_section(
            'style_divider',
            [
                'label' => esc_html__('Divider', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['divider!' => ''],
            ]
        );

        $this->add_responsive_control(
            'divider_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .wgl-double-heading::before' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'divider_size',
            [
                'label' => esc_html__('Divider Size', 'motto-core'),
                'type' => Controls_Manager::SLIDER,
			    'dynamic' => [  'active' => true],
                'size_units' => ['px', 'em', 'custom'],
                'range' => [
                    'px' => [ 'min' => 1, 'max' => 50 ],
                ],
                'default' => ['size' => 28, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .wgl-double-heading::before' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_divider' );
        $this->start_controls_tab(
            'tabs_divider_idle',
            ['label' => esc_html__('Idle', 'motto-core')]
        );
        $this->add_control(
            'divider_color_idle',
            [
                'label' => esc_html__('Divider Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-double-heading::before' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tabs_divider_hover',
            ['label' => esc_html__('Hover', 'motto-core')]
        );
        $this->add_control(
            'divider_color_hover',
            [
                'label' => esc_html__('Divider Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .wgl-double-heading::before' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /**
         * STYLES -> SUBTITLE
         */

        $this->start_controls_section(
            'style_subtitle',
            [
                'label' => esc_html__('Subtitle', 'motto-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['subtitle!' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typo',
                'selector' => '{{WRAPPER}} .dblh__subtitle',
            ]
        );

        $this->add_control(
            'sub_title_tag',
            [
                'label' => esc_html__('HTML Tag', 'motto-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html('‹h1›'),
                    'h2' => esc_html('‹h2›'),
                    'h3' => esc_html('‹h3›'),
                    'h4' => esc_html('‹h4›'),
                    'h5' => esc_html('‹h5›'),
                    'h6' => esc_html('‹h6›'),
                    'span' => esc_html('‹span›'),
                    'div' => esc_html('‹div›'),
                ],
                'default' => 'h5',
            ]
        );

        $this->add_responsive_control(
            'subtitle_margin',
            [
                'label' => esc_html__('Margin', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '15',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'tablet_default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '12',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'mobile_default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '10',
                    'left' => '0',
                    'unit'  => 'px',
                    'isLinked' => false
                ],
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'subtitle_padding',
            [
                'label' => esc_html__('Padding', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .dblh__subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle_border_radius',
            [
                'label' => esc_html__('Border Radius', 'motto-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .dblh__subtitle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle_color',
            [
                'label' => esc_html__('Text Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .dblh__subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle_bg_color',
            [
                'label' => esc_html__('Background Color', 'motto-core'),
                'type' => Controls_Manager::COLOR,
			    'dynamic' => [  'active' => true],
                'selectors' => [
                    '{{WRAPPER}} .dblh__subtitle' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'subtitle_shadow',
                'selector' => '{{WRAPPER}} .dblh__subtitle',
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $_s = $this->get_settings_for_display();

        if (isset($_s['cursor_tooltip']) && '' != $_s['cursor_tooltip']) {
            add_filter( 'wgl/motto_module_cursor', function () { return true; });
        }

        $cursor = new WGL_Cursor;
        $cursor_data = $cursor->build($this, $_s);

        echo '<div class="wgl-double-heading' . ( isset($_s['cursor_tooltip']) && !empty($_s['cursor_tooltip']) ? ' wgl-cursor-text' : '' ) . '"' . $cursor_data . '>';

        if ($_s['subtitle']) {
            echo '<', $_s['sub_title_tag'], ' class="dblh__subtitle">',
                $_s['subtitle'],
            '</', $_s['sub_title_tag'], '>';
        }

        if (
            $_s['title_part-1']
            || $_s['title_part-2']
            || $_s['title_part-3']
        ) {

            if (!empty($_s['link']['url'])) {
                $this->add_render_attribute('link', 'class', 'dblh__link');
                $this->add_link_attributes('link', $_s['link']);

                echo '<a ', $this->get_render_attribute_string('link'), '>';
            }

            echo '<', $_s['title_tag'], ' class="dblh__title-wrapper">',
                $_s['title_part-1'] ? '<span class="dblh__title dblh__title-1">' . $_s['title_part-1'] . '</span>' : '',
                $_s['title_part-2'] ? '<span class="dblh__title dblh__title-2">' . $_s['title_part-2'] . '</span>' : '',
                $_s['title_part-3'] ? '<span class="dblh__title dblh__title-3">' . $_s['title_part-3'] . '</span>' : '',
            '</', $_s['title_tag'], '>';

            if (!empty($_s['link']['url'])) {
                echo '</a>';
            }
        }

        if ($_s['content']) {
            echo '<div class="dblh__content">',
                $_s['content'],
            '</div>';
        }

        echo '</div>';
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WGL_Extensions\Includes\WGL_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
