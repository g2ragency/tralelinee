<?php
/**
 * The header for our theme
 *
 * @package WP_Bootstrap_Starter
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="profile" href="http://gmpg.org/xfn/11">

  <!-- FONT -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300;1,400;1,500&display=swap" rel="stylesheet">

  <!-- SWIPER -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

  <!-- LENIS -->
  <script src="https://cdn.jsdelivr.net/npm/@studio-freight/lenis"></script>

  <!-- GSAP -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>

  <!-- SplitType -->
  <script src="https://unpkg.com/split-type"></script>

  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

  <?php
  if (function_exists('wp_body_open')) {
    wp_body_open();
  } else {
    do_action('wp_body_open');
  }
  ?>

  <div id="page" class="site">
    <header id="masthead" class="site-header" role="banner">
      <nav>
        <div class="container-fluid custom-header">
          <div class="row">
            <div class="col-md-3 col-6 h-logo">
              <!-- Logo scuro per tema chiaro -->
				<div>


<div class="logo-theme logo-dark">
  <span class="logo-letter">|</span>

  <!-- TRA -->
  <span class="hoverable">
    <span class="logo-letter">T</span>
    <span class="logo-reveal">
      <span class="logo-letter">R</span>
      <span class="logo-letter">A</span>
    </span>
  </span>

  <span class="logo-letter">|</span>
	 <span class="hoverable">
	  <span class="logo-letter">L</span>
	 <span class="logo-reveal">
      <span class="logo-letter">E</span>
	</span>
	</span>

  <span class="logo-letter">|</span>

  <!-- LINEE -->
  <span class="hoverable">
    <span class="logo-letter">L</span>
    <span class="logo-reveal">
      <span class="logo-letter">I</span>
      <span class="logo-letter">N</span>
      <span class="logo-letter">E</span>
      <span class="logo-letter">E</span>
    </span>
  </span>

  <span class="logo-letter">|</span>
</div>

<div class="logo-theme logo-light">
  <span class="logo-letter">|</span>

  <!-- TRA -->
  <span class="hoverable">
    <span class="logo-letter">T</span>
    <span class="logo-reveal">
      <span class="logo-letter">R</span>
      <span class="logo-letter">A</span>
    </span>
  </span>

  <span class="logo-letter">|</span>
		 <span class="hoverable">
	  <span class="logo-letter">L</span>
	 <span class="logo-reveal">
      <span class="logo-letter">E</span>
	</span>
	</span>
  <span class="logo-letter">|</span>

  <!-- LINEE -->
  <span class="hoverable">
    <span class="logo-letter">L</span>
    <span class="logo-reveal">
      <span class="logo-letter">I</span>
      <span class="logo-letter">N</span>
      <span class="logo-letter">E</span>
      <span class="logo-letter">E</span>
    </span>
  </span>

  <span class="logo-letter">|</span>
</div>
					
					
				</div>
            </div>
            <div class="col-md-6 col-6 hambergur">
              <div class="d-flex justify-content-end align-items-center">
                <div class="menu-items d-none d-xl-flex">
					<div>
						
					
                  <?php
                  wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class' => 'main-menu',
                    'container' => false,
                  ));
                  ?>
						</div>
                </div>
				    <button id="theme-switcher" class="theme-toggle d-none d-xl-flex">
                Dark
              </button>
				      <div class="right-header d-flex d-xl-none">
				
              <button class="navbar-toggler menu-hamburger" type="button" data-bs-toggle="offcanvas" data-bs-target="#main-nav" aria-controls="offcanvasExample">
                <span class="navbar-toggler-icon"></span>
              </button>
            </div>
              </div>
            </div>
			
          </div>
        </div>
		  
		  	
      </nav>
		
		  <div class="offcanvas offcanvas-start" tabindex="-1" id="main-nav" aria-labelledby="offcanvasExampleLabel">
            <div class="container">
              <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasExampleLabel" style="font-size: 0.95rem;">
        <div class="logo-theme logo-dark">
            <span class="logo-letter">|</span>
            <span class="hoverable">
                <span class="logo-letter">T</span>
                <span class="logo-reveal">
                    <span class="logo-letter">R</span>
                    <span class="logo-letter">A</span>
                </span>
            </span>
            <span class="logo-letter">|</span>
            <span class="hoverable">
                <span class="logo-letter">L</span>
                <span class="logo-reveal">
                    <span class="logo-letter">E</span>
                </span>
            </span>
            <span class="logo-letter">|</span>
            <span class="hoverable">
                <span class="logo-letter">L</span>
                <span class="logo-reveal">
                    <span class="logo-letter">I</span>
                    <span class="logo-letter">N</span>
                    <span class="logo-letter">E</span>
                    <span class="logo-letter">E</span>
                </span>
            </span>
            <span class="logo-letter">|</span>
        </div>

        <div class="logo-theme logo-light">
            <span class="logo-letter">|</span>
            <span class="hoverable">
                <span class="logo-letter">T</span>
                <span class="logo-reveal">
                    <span class="logo-letter">R</span>
                    <span class="logo-letter">A</span>
                </span>
            </span>
            <span class="logo-letter">|</span>
            <span class="hoverable">
                <span class="logo-letter">L</span>
                <span class="logo-reveal">
                    <span class="logo-letter">E</span>
                </span>
            </span>
            <span class="logo-letter">|</span>
            <span class="hoverable">
                <span class="logo-letter">L</span>
                <span class="logo-reveal">
                    <span class="logo-letter">I</span>
                    <span class="logo-letter">N</span>
                    <span class="logo-letter">E</span>
                    <span class="logo-letter">E</span>
                </span>
            </span>
            <span class="logo-letter">|</span>
        </div>
    </h5>
    <button type="button" class="btn-close text-reset" style="color:#333 !important;" data-bs-dismiss="offcanvas" aria-label="Close"></button>
</div>
				<div class="m-main-menu">
					
				
              <?php
              wp_nav_menu(array(
                'theme_location'    => 'primary',
                'menu_id'         => false,
                'menu_class'      => 'navbar-nav flex-column mb-3',
                'depth'           => 3
              
               
              ));
              ?>
					</div>
					<div class="offcanvas-body pt-5">
						<h5 class="offcanvas-title mb-3" id="offcanvasExampleLabel" style="font-size: 0.95rem;"></h5>

						 <div>
							<button id="theme-switcher-mobile" class="theme-toggle">
								Dark
							</button>
						</div>

				</div>
            </div>
          </div>
    </header>
	  
	<div id="cursor"></div>
	<div id="cursor-shadow"></div>  
	  
	  

    <div class="cursor"></div>
    <div id="content" class="site-content">
